
# Prediction, residuals & model comparison {#Prediction,-residuals-and-model-comparison}

::: tip Status — Stable

The post-fit surface a fitted `drm` model exposes: prediction (point + standard error, per parameter, on a grid), quantile residuals, and model-comparison helpers. Mirrors the `predict` / `residuals` / `anova` verbs you reach for after a drmTMB fit.

:::

A fit is the beginning, not the end. Once `drm` returns, you usually want to **predict** at new covariate values, **check** the model with residuals, and **compare** it against a simpler one. This page walks the whole surface on one small location–scale model.

```julia
using DRM, Random, Statistics
Random.seed!(11)

n = 500
x = randn(n)
# mean μ = 1 + 0.5x ; log-scale logσ = -0.2 + 0.6x  (the spread grows with x)
y = 1.0 .+ 0.5 .* x .+ exp.(-0.2 .+ 0.6 .* x) .* randn(n)
dat = (; y, x)

fit = drm(bf(@formula(y ~ 1 + x), @formula(sigma ~ 1 + x)), Gaussian(); data = dat)
coef(fit, :mu), coef(fit, :sigma)
```


```ansi
([0.9978887393861752, 0.5008810755471579], [-0.17403196560326598, 0.5525691658060553])
```


## Predicting the mean at new data {#Predicting-the-mean-at-new-data}

[`predict`](/reference/model-fitting-and-postfit#StatsAPI.predict) evaluates the fitted **mean** at a `newdata` column table. By default it returns the response scale; pass `type = :link` for the linear predictor.

```julia
nd = (; x = [-1.0, 0.0, 1.0])
predict(fit, nd)                 # μ̂ at x = -1, 0, 1  (response scale)
```


```ansi
3-element Vector{Float64}:
 0.4970076638390173
 0.9978887393861752
 1.498769814933333
```


### Standard errors (the delta method) {#Standard-errors-the-delta-method}

Add `se = true` for delta-method standard errors — the glmmTMB/drmTMB `se.fit`. You get back a `NamedTuple` `(; prediction, se)`:

```julia
ps = predict(fit, nd; type = :link, se = true)
ps.se                            # SE of the linear predictor at each new row
```


```ansi
3-element Vector{Float64}:
 0.02823637531425841
 0.04209049180603304
 0.06614441643332723
```


On the response scale the SE is chained through the inverse-link derivative automatically (for the Gaussian identity link the two coincide):

```julia
predict(fit, nd; type = :response, se = true).se
```


```ansi
3-element Vector{Float64}:
 0.02823637531425841
 0.04209049180603304
 0.06614441643332723
```


## Predicting every distributional parameter {#Predicting-every-distributional-parameter}

A distributional model has more than a mean. [`predict_parameters`](/reference/model-fitting-and-postfit#DRM.predict_parameters) returns **each** parameter at the new data — here `μ` _and_ `σ`:

```julia
predict_parameters(fit, nd)      # Dict(:mu => …, :sigma => …), response scale
```


```ansi
Dict{Symbol, Vector{Float64}} with 2 entries:
  :mu    => [0.497008, 0.997889, 1.49877]
  :sigma => [0.48355, 0.84027, 1.46015]
```


With `se = true` each entry becomes a `(; value, se)` pair:

```julia
pp = predict_parameters(fit, nd; se = true)
pp[:sigma].value, pp[:sigma].se  # fitted σ and its SE at x = -1, 0, 1
```


```ansi
([0.4835497221570097, 0.8402700374904782, 1.4601471235568046], [0.022384472882952, 0.02662502613090035, 0.0634432530165215])
```


## Sweeping a predictor: `prediction_grid` {#Sweeping-a-predictor:-prediction_grid}

To trace a parameter across a covariate, build a grid with [`prediction_grid`](/reference/model-fitting-and-postfit#DRM.prediction_grid) — it sweeps the named predictor(s) over a range and holds everything else at a reference value, then composes straight into `predict_parameters`:

```julia
grid = prediction_grid((; x = dat.x), x = range(-2, 2; length = 5))
predict_parameters(fit, grid)[:sigma]   # σ̂ rising across the x sweep
```


```ansi
5-element Vector{Float64}:
 0.2782680845034544
 0.4835497221570097
 0.8402700374904782
 1.4601471235568046
 2.537314824170879
```


## In-sample fitted parameters {#In-sample-fitted-parameters}

For the per-observation fitted parameters at the **training** data there is a cheap accessor that reads straight from the fit (no recomputation) — [`marginal_parameters`](/reference/model-fitting-and-postfit#DRM.marginal_parameters). In-sample it equals `predict_parameters(fit, data)`:

```julia
mp = marginal_parameters(fit)
first(mp[:mu], 3), first(mp[:sigma], 3)
```


```ansi
([0.8137954867780545, 0.6540498515409683, 0.8175584898832858], [0.685831986241213, 0.5750184916306671, 0.6886850146544282])
```


## Residuals: response and quantile {#Residuals:-response-and-quantile}

[`residuals`](/reference/model-fitting-and-postfit#StatsAPI.residuals) defaults to response residuals (`y − μ̂`). For a _distribution-aware_ diagnostic — the DHARMa/glmmTMB **randomized quantile residual** — pass `type = :quantile`. Under a correctly specified model these are standard normal, which makes a QQ-plot or a simple moment check interpretable even for non-Gaussian families:

```julia
rq = residuals(fit; type = :quantile)
(mean = mean(rq), sd = std(rq))         # ≈ (0, 1) when the model fits
```


```ansi
(mean = -0.004829463707716469, sd = 1.0009898288991261)
```


::: tip Why quantile residuals

Raw `y − μ̂` residuals are misleading when the variance changes with the mean (exactly the location–scale case here) or for discrete responses. Quantile residuals fold each observation through its own fitted CDF, so a well-specified model always yields ≈ N(0, 1) — the scale is the same across families. (Implemented for Gaussian and Poisson today; other families are tracked in issue #183.)

:::

## Does the extra structure earn its keep? {#Does-the-extra-structure-earn-its-keep?}

Fit a simpler model with a **constant** scale and compare. [`lrtest`](/reference/model-fitting-and-postfit#DRM.lrtest) (alias [`anova`](/reference/model-fitting-and-postfit#DRM.anova)) runs the nested likelihood-ratio test; it returns a `NamedTuple` `(; statistic, dof, pvalue)`:

```julia
reduced = drm(bf(@formula(y ~ 1 + x), @formula(sigma ~ 1)), Gaussian(); data = dat)
lrtest(reduced, fit)             # is σ ~ x worth the one extra parameter?
```


```ansi
(statistic = 301.74324091067547, dof = 1, pvalue = 1.373983432463021e-67)
```


A small p-value says the moving scale is real signal. The information criteria agree — lower is better, and [`aicc`](/reference/model-fitting-and-postfit#DRM.aicc) is the small-sample-corrected AIC:

```julia
(aic = aic(fit),   bic = bic(fit),   aicc = aicc(fit)),
(aic = aic(reduced), bic = bic(reduced), aicc = aicc(reduced))
```


```ansi
((aic = 1287.7430095377558, bic = 1304.6014419314447, aicc = 1287.823817618564), (aic = 1587.4862504484313, bic = 1600.1300747436978, aicc = 1587.5346375452054))
```


## Refitting: `update` {#Refitting:-update}

[`update`](/reference/model-fitting-and-postfit#DRM.update) re-fits with a new formula, reusing the original family — handy for building a comparison ladder. (A `DrmFit` does not retain its data, so pass `data` again.)

```julia
mean_only = update(fit, bf(@formula(y ~ 1 + x), @formula(sigma ~ 1)); data = dat)
length(coef(mean_only)) == length(coef(reduced))
```


```ansi
true
```


## See also {#See-also}
- [When variance carries signal](../tutorials/location-scale.md) — the model fit here, in depth.
  
- [Rosetta (R ↔ Julia)](../rosetta.md) — the verb-by-verb drmTMB mapping.
  
- [Model fitting & post-fit reference](../reference/model-fitting-and-postfit.md) — every accessor's docstring.
  
