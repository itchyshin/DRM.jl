import { defineConfig } from 'vitepress'
import { tabsMarkdownPlugin } from 'vitepress-plugin-tabs'
import { mathjaxPlugin } from './mathjax-plugin'
import { juliaReplTransformer } from './julia-repl-transformer'
import footnote from "markdown-it-footnote";
import path from 'path'

const mathjax = mathjaxPlugin()

function getBaseRepository(base: string): string {
  if (!base || base === '/') return '/';
  const parts = base.split('/').filter(Boolean);
  return parts.length > 0 ? `/${parts[0]}/` : '/';
}

const baseTemp = {
  base: '/',// TODO: replace this in makedocs!
}

const navTemp = {
  nav: [
{ text: 'Start here', collapsed: false, items: [
{ text: 'Home', link: '/index' },
{ text: 'Getting started', link: '/getting-started' },
{ text: 'Capabilities', link: '/capabilities' },
{ text: 'R ↔ Julia bridge', link: '/r-julia-bridge' },
{ text: 'Rosetta (R ↔ Julia)', link: '/rosetta' }]
 },
{ text: 'Model guides', collapsed: false, items: [
{ text: 'What can I fit today?', link: '/model-guides/model-map' },
{ text: 'Which scale are you modelling?', link: '/model-guides/which-scale' },
{ text: 'Choosing response families', link: '/model-guides/distribution-families' },
{ text: 'Response families', link: '/families' },
{ text: 'Checking and using fitted models', link: '/model-guides/model-workflow' },
{ text: 'Model selection with AIC and BIC', link: '/model-guides/model-selection' },
{ text: 'Improving convergence', link: '/model-guides/convergence' },
{ text: 'Laplace vs variational marginals', link: '/model-guides/marginal-la-vs-va' },
{ text: 'Cross-family dependence: statistical foundations', link: '/model-guides/cross-family-methods' },
{ text: 'Meta-analysis: known sampling variance, and the two correlations', link: '/model-guides/meta-analysis' },
{ text: 'Working with large data', link: '/model-guides/large-data' },
{ text: 'Cross-family bivariate', link: '/cross-family' }]
 },
{ text: 'Tutorials', collapsed: false, items: [
{ text: 'When variance carries signal, Part 1: location–scale', link: '/tutorials/location-scale' },
{ text: 'When variance carries signal, Part 2: location–scale–scale', link: '/tutorials/location-scale-scale' },
{ text: 'Robust continuous responses', link: '/tutorials/robust-student' },
{ text: 'Count abundance and extra zeros', link: '/tutorials/count-nbinom2' },
{ text: 'Proportions and success rates', link: '/tutorials/proportion-beta-binomial' },
{ text: 'Changing residual coupling with rho12', link: '/tutorials/bivariate-coscale' },
{ text: 'Bivariate non-Gaussian models: joint or staged', link: '/tutorials/bivariate-nongaussian' },
{ text: 'Mean effects and residual heterogeneity', link: '/tutorials/meta-analysis' },
{ text: 'Structural dependence overview', link: '/tutorials/structural-dependence' },
{ text: 'Animal models and additive relatedness', link: '/tutorials/animal-models' },
{ text: 'Phylogenetic structured effects', link: '/tutorials/phylogenetic-models' },
{ text: 'Coordinate-spatial structured effects', link: '/tutorials/spatial-models' },
{ text: 'Known-matrix relatedness with relmat', link: '/tutorials/relmat-known-matrices' },
{ text: 'Structural dependence details', link: '/tutorials/phylogenetic-spatial' }]
 },
{ text: 'Diagnostics', collapsed: false, items: [
{ text: 'Figure gallery', link: '/diagnostics-and-validation/figure-gallery' },
{ text: 'Prediction, residuals & model comparison', link: '/diagnostics-and-validation/prediction-and-postfit' },
{ text: 'Profile-likelihood intervals', link: '/diagnostics-and-validation/profile-likelihood' },
{ text: 'Implementation map', link: '/diagnostics-and-validation/implementation-map' },
{ text: 'Exact-Gaussian Diagnostics', link: '/diagnostics-and-validation/exact-gaussian-diagnostics' },
{ text: 'Testing likelihoods', link: '/diagnostics-and-validation/testing-likelihoods' },
{ text: 'Simulation plot grammar', link: '/diagnostics-and-validation/simulation-plot-grammar' },
{ text: 'Small-sample behaviour of phylogenetic covariance estimates', link: '/diagnostics-and-validation/small-sample-behaviour' }]
 },
{ text: 'Reference', collapsed: false, items: [
{ text: 'Package', link: '/reference/package' },
{ text: 'Model specification', link: '/reference/model-specification' },
{ text: 'Structured-effect markers', link: '/reference/structured-effect-markers' },
{ text: 'Deprecated marker internals', link: '/reference/deprecated-marker-internals' },
{ text: 'Model fitting and post-fit tools', link: '/reference/model-fitting-and-postfit' },
{ text: 'Visualization', link: '/reference/visualization' },
{ text: 'Engine internals and advanced constructors', link: '/reference/engine-internals' },
{ text: 'Development', collapsed: false, items: [
{ text: 'Formula grammar', link: '/developer-notes/formula-grammar' },
{ text: 'Adding distribution families', link: '/developer-notes/adding-families' },
{ text: 'Implemented source map', link: '/developer-notes/source-map' },
{ text: 'API stability', link: '/api-stability' },
{ text: 'Changelog', link: '/changelog' }]
 }]
 }
]
,
}

const nav = [
  ...navTemp.nav,
  {
    component: 'VersionPicker'
  }
]

// https://vitepress.dev/reference/site-config
export default defineConfig({
  base: '/',// TODO: replace this in makedocs!
  title: 'DRM.jl',
  description: 'Documentation for DRM.jl',
  lastUpdated: true,
  cleanUrls: true,
  outDir: '../1', // This is required for MarkdownVitepress to work correctly...
  head: [
    
    ['script', {src: `${getBaseRepository(baseTemp.base)}versions.js`}],
    // ['script', {src: '/versions.js'], for custom domains, I guess if deploy_url is available.
    ['script', {src: `${baseTemp.base}siteinfo.js`}]
  ],
  
  markdown: {
    codeTransformers: [juliaReplTransformer()],
    config(md) {
      md.use(tabsMarkdownPlugin);
      md.use(footnote);
      mathjax.markdownConfig(md);
    },
    theme: {
      light: "github-light",
      dark: "github-dark"
    },
  },
  vite: {
    plugins: [
      mathjax.vitePlugin,
    ],
    define: {
      __DEPLOY_ABSPATH__: JSON.stringify('/'),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '../components')
      }
    },
    optimizeDeps: {
      exclude: [ 
        '@nolebase/vitepress-plugin-enhanced-readabilities/client',
        'vitepress',
        '@nolebase/ui',
      ], 
    }, 
    ssr: { 
      noExternal: [ 
        // If there are other packages that need to be processed by Vite, you can add them here.
        '@nolebase/vitepress-plugin-enhanced-readabilities',
        '@nolebase/ui',
      ], 
    },
  },
  themeConfig: {
    outline: 'deep',
    
    search: {
      provider: 'local',
      options: {
        detailedView: true
      }
    },
    nav,
    sidebar: [
{ text: 'Start here', collapsed: false, items: [
{ text: 'Home', link: '/index' },
{ text: 'Getting started', link: '/getting-started' },
{ text: 'Capabilities', link: '/capabilities' },
{ text: 'R ↔ Julia bridge', link: '/r-julia-bridge' },
{ text: 'Rosetta (R ↔ Julia)', link: '/rosetta' }]
 },
{ text: 'Model guides', collapsed: false, items: [
{ text: 'What can I fit today?', link: '/model-guides/model-map' },
{ text: 'Which scale are you modelling?', link: '/model-guides/which-scale' },
{ text: 'Choosing response families', link: '/model-guides/distribution-families' },
{ text: 'Response families', link: '/families' },
{ text: 'Checking and using fitted models', link: '/model-guides/model-workflow' },
{ text: 'Model selection with AIC and BIC', link: '/model-guides/model-selection' },
{ text: 'Improving convergence', link: '/model-guides/convergence' },
{ text: 'Laplace vs variational marginals', link: '/model-guides/marginal-la-vs-va' },
{ text: 'Cross-family dependence: statistical foundations', link: '/model-guides/cross-family-methods' },
{ text: 'Meta-analysis: known sampling variance, and the two correlations', link: '/model-guides/meta-analysis' },
{ text: 'Working with large data', link: '/model-guides/large-data' },
{ text: 'Cross-family bivariate', link: '/cross-family' }]
 },
{ text: 'Tutorials', collapsed: false, items: [
{ text: 'When variance carries signal, Part 1: location–scale', link: '/tutorials/location-scale' },
{ text: 'When variance carries signal, Part 2: location–scale–scale', link: '/tutorials/location-scale-scale' },
{ text: 'Robust continuous responses', link: '/tutorials/robust-student' },
{ text: 'Count abundance and extra zeros', link: '/tutorials/count-nbinom2' },
{ text: 'Proportions and success rates', link: '/tutorials/proportion-beta-binomial' },
{ text: 'Changing residual coupling with rho12', link: '/tutorials/bivariate-coscale' },
{ text: 'Bivariate non-Gaussian models: joint or staged', link: '/tutorials/bivariate-nongaussian' },
{ text: 'Mean effects and residual heterogeneity', link: '/tutorials/meta-analysis' },
{ text: 'Structural dependence overview', link: '/tutorials/structural-dependence' },
{ text: 'Animal models and additive relatedness', link: '/tutorials/animal-models' },
{ text: 'Phylogenetic structured effects', link: '/tutorials/phylogenetic-models' },
{ text: 'Coordinate-spatial structured effects', link: '/tutorials/spatial-models' },
{ text: 'Known-matrix relatedness with relmat', link: '/tutorials/relmat-known-matrices' },
{ text: 'Structural dependence details', link: '/tutorials/phylogenetic-spatial' }]
 },
{ text: 'Diagnostics', collapsed: false, items: [
{ text: 'Figure gallery', link: '/diagnostics-and-validation/figure-gallery' },
{ text: 'Prediction, residuals & model comparison', link: '/diagnostics-and-validation/prediction-and-postfit' },
{ text: 'Profile-likelihood intervals', link: '/diagnostics-and-validation/profile-likelihood' },
{ text: 'Implementation map', link: '/diagnostics-and-validation/implementation-map' },
{ text: 'Exact-Gaussian Diagnostics', link: '/diagnostics-and-validation/exact-gaussian-diagnostics' },
{ text: 'Testing likelihoods', link: '/diagnostics-and-validation/testing-likelihoods' },
{ text: 'Simulation plot grammar', link: '/diagnostics-and-validation/simulation-plot-grammar' },
{ text: 'Small-sample behaviour of phylogenetic covariance estimates', link: '/diagnostics-and-validation/small-sample-behaviour' }]
 },
{ text: 'Reference', collapsed: false, items: [
{ text: 'Package', link: '/reference/package' },
{ text: 'Model specification', link: '/reference/model-specification' },
{ text: 'Structured-effect markers', link: '/reference/structured-effect-markers' },
{ text: 'Deprecated marker internals', link: '/reference/deprecated-marker-internals' },
{ text: 'Model fitting and post-fit tools', link: '/reference/model-fitting-and-postfit' },
{ text: 'Visualization', link: '/reference/visualization' },
{ text: 'Engine internals and advanced constructors', link: '/reference/engine-internals' },
{ text: 'Development', collapsed: false, items: [
{ text: 'Formula grammar', link: '/developer-notes/formula-grammar' },
{ text: 'Adding distribution families', link: '/developer-notes/adding-families' },
{ text: 'Implemented source map', link: '/developer-notes/source-map' },
{ text: 'API stability', link: '/api-stability' },
{ text: 'Changelog', link: '/changelog' }]
 }]
 }
]
,
    sidebarDrawer: false,
    editLink: { pattern: "https://github.com/itchyshin/DRM.jl/edit/main/docs/src/:path" },
    socialLinks: [
      { icon: 'github', link: 'https://github.com/itchyshin/DRM.jl' }
    ],
    footer: {
      message: 'Made with <a href="https://luxdl.github.io/DocumenterVitepress.jl/dev/" target="_blank"><strong>DocumenterVitepress.jl</strong></a><br>',
      copyright: `© Copyright ${new Date().getUTCFullYear()}.`
    }
  }
})
