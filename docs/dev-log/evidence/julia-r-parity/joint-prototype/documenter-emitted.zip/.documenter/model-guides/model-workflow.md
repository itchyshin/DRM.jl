
# Checking and using fitted models {#Checking-and-using-fitted-models}

::: tip Status — Stable (Gaussian post-fit + inference)

Mirrors drmTMB's [Checking and using fitted models](https://itchyshin.github.io/drmTMB/articles/model-workflow.html). **In DRM.jl today:** coefficient extraction, Wald standard errors, Wald **and profile-likelihood** confidence intervals, fitted values, residuals, `predict` (new data), `simulate`, and **parametric bootstrap** intervals (`bootstrap_ci`).

:::

Once you have a fit, pull coefficients and quantify their uncertainty.

```julia
using DRM, Random
Random.seed!(5)
n = 1500
x = randn(n)
y = 0.4 .+ 0.7 .* x .+ exp.(-0.2 .+ 0.3 .* x) .* randn(n)
fit = drm(bf(@formula(y ~ x), @formula(sigma ~ x)), Gaussian(); data = (; y, x))

coef(fit, :mu)        # mean coefficients
stderror(fit)         # Wald standard errors (all coefficients)
```


```ansi
4-element Vector{Float64}:
 0.022261681489163826
 0.01961543589632826
 0.018257479080833975
 0.01840544229392467
```


Wald confidence intervals for every coefficient (drmTMB's default interval method), one row per coefficient:

```julia
confint(fit; level = 0.95)
```


```ansi
4-element Vector{@NamedTuple{param::Symbol, coef::String, estimate::Float64, lower::Float64, upper::Float64}}:
 (param = :mu, coef = "(Intercept)", estimate = 0.3937744170717677, lower = 0.35014232311770455, upper = 0.43740651102583084)
 (param = :mu, coef = "x", estimate = 0.6949906922599547, lower = 0.6565451443620971, upper = 0.7334362401578123)
 (param = :sigma, coef = "(Intercept)", estimate = -0.2074314704654561, lower = -0.2432154719123842, upper = -0.17164746901852798)
 (param = :sigma, coef = "x", estimate = 0.2768531440245958, lower = 0.24077914000897313, upper = 0.31292714804021854)
```


Each row carries its parameter (`:mu` / `:sigma`), coefficient name, point estimate, and interval bounds. Intervals are on each parameter's working scale — `μ` on the response scale, `σ` on `log σ` — so for a residual-SD ratio you exponentiate the `σ` bounds.

For a **profile-likelihood** interval (drmTMB's `method = "profile"`), pass `method = :profile`. It inverts the likelihood-ratio statistic — re-optimising the nuisance parameters at each fixed value — so it is asymmetric and exact under the LR statistic where Wald is only a quadratic approximation. Use Wald for speed; profile when a parameter's likelihood is skewed (a scale or variance term):

```julia
confint(fit; method = :profile)
```


```ansi
4-element Vector{@NamedTuple{param::Symbol, coef::String, estimate::Float64, lower::Float64, upper::Float64}}:
 (param = :mu, coef = "(Intercept)", estimate = 0.3937744170717677, lower = 0.35009495018040954, upper = 0.4374203155154246)
 (param = :mu, coef = "x", estimate = 0.6949906922599547, lower = 0.6565626975840618, upper = 0.7335149151935799)
 (param = :sigma, coef = "(Intercept)", estimate = -0.2074314704654561, lower = -0.24279368054381026, upper = -0.171215494382636)
 (param = :sigma, coef = "x", estimate = 0.2768531440245958, lower = 0.2407854339980086, upper = 0.31293293958439994)
```


::: tip What scale is the interval on?

A `σ` row gives an interval for a `log σ` coefficient. `exp(lower)` and `exp(upper)` give the interval for the multiplicative effect on the residual SD. See [Which scale are you modelling?](which-scale.md).

:::

## Fitted values and residuals {#Fitted-values-and-residuals}

```julia
ŷ = fitted(fit)            # fitted means (Xβ̂)
res = residuals(fit)       # observed − fitted
(n = length(res), sum_resid = round(sum(res), digits = 6))
```


```ansi
(n = 1500, sum_resid = 12.719142)
```


For a bivariate model, `fitted` / `residuals` return one vector per response, keyed `Dict(:mu1 => …, :mu2 => …)`.

Predict the mean on **new** data (population level — random/structured effects integrated out):

```julia
predict(fit, (; x = [-1.0, 0.0, 1.0]))    # μ̂ at three new x values
```


```ansi
3-element Vector{Float64}:
 -0.301216275188187
  0.3937744170717677
  1.0887651093317223
```


## Simulating from a fitted model {#Simulating-from-a-fitted-model}

`simulate` draws a parametric replicate — the building block of a parametric bootstrap:

```julia
y_rep = simulate(fit; rng = MersenneTwister(1))   # one replicate response vector
length(y_rep)
```


```ansi
1500
```


## Bootstrap confidence intervals {#Bootstrap-confidence-intervals}

`bootstrap_ci` automates the parametric bootstrap — simulate `B` replicates, refit each, and take percentile intervals. It takes the same arguments as `drm` (plus `B`), since it refits internally:

```julia
bootstrap_ci(bf(@formula(y ~ x), @formula(sigma ~ x)), Gaussian();
             data = dat, B = 500, level = 0.95)
```


Returns the same `(param, coef, estimate, lower, upper)` rows as `confint`. Use Wald (`confint`) for speed; bootstrap when you want fewer distributional assumptions.

For longer jobs, use `bootstrap_result` to keep the audit trail:

```julia
bres = bootstrap_result(bf(@formula(y ~ x), @formula(sigma ~ x)), Gaussian();
                        data = dat, B = 500, threads = true,
                        failures = :skip)
(bres.attempted, bres.used, bres.failed)
```


## See also {#See-also}
- [Get started](../get-started.md) · [When variance carries signal](../tutorials/location-scale.md)
  
- Profile and bootstrap intervals, `predict`, and `simulate` — see the [roadmap](https://github.com/itchyshin/DRM.jl/blob/main/ROADMAP.md).
  
