
# Model fitting and post-fit tools {#Model-fitting-and-post-fit-tools}

::: tip Status — Reference

Mirrors drmTMB's [Model fitting and post-fit tools](https://itchyshin.github.io/drmTMB/reference/index.html) (23 in drmTMB). The fitting verb is [`drm`](/reference/model-fitting-and-postfit#DRM.drm); the post-fit accessors below cover coefficients, fitted scale / correlation, random-effect estimates, predictions, simulation, inference, and convergence diagnostics.

:::

## Fitting {#Fitting}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.drm' href='#DRM.drm'><span class="jlbinding">DRM.drm</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
drm(formula::DrmFormula, family; data) -> DrmFit
```


Fit a distributional regression model by maximum likelihood. A formula bundle has one linear predictor per distributional parameter:

```julia
fit = drm(bf(y ~ x1, sigma ~ x1), Gaussian(); data = dat)
```


Univariate Gaussian fits support fixed effects plus the structured-effect markers documented under [`phylo`](/reference/structured-effect-markers#DRM.phylo), [`spatial`](/reference/structured-effect-markers#DRM.spatial), [`animal`](/reference/structured-effect-markers#DRM.animal), [`relmat`](/reference/structured-effect-markers#DRM.relmat), and [`meta_V`](/reference/structured-effect-markers#DRM.meta_V).

**`algorithm` and `sparse` — solver selection**

`algorithm` (default `:auto`) and `sparse` choose how the model is fit:
- `:auto` (default) — uses the all-node sparse L-BFGS route for the Gaussian phylogenetic-mean cell (`phylo(1 | g)` on mean with `sigma ~ 1`). For phylogenetic location-scale-scale models (`sd(species, phylogenetic) ~ z`), `:auto` selects the O(p) sparse augmented GMRF engine when G &gt; 500 species and the dense scaled-covariance engine for smaller trees. Other Gaussian cells keep their cell-specific default fitters.
  
- `:gls`, `:lbfgs` — legacy dense leaf-covariance fitters for the Gaussian phylogenetic-mean cell and aliases for the usual default fitters elsewhere.
  
- `:em` — force the all-node sparse conjugate-EM route for the Gaussian phylogenetic-mean cell. It reaches the same MLE as the dense GLS fit (same β, residual σ, and marginal logLik) via closed-form E/M steps with exact O(p) Takahashi traces. Any other model cell raises a clear `ArgumentError`. The EM path has **no coefficient vcov** (the M-steps are closed-form), so `vcov(fit)` is filled with `NaN`s. Refit with `:gls` for dense-fit Wald inference. `re_sd(fit)` reports the EM's Brownian phylo SD `σ_phy` (a different scale from the GLS fit's correlation-matrix `σ_s`).
  
- `:sparse` — force the verified sparse structured-Gaussian route where one is implemented, including the two-structured `phylo + animal/relmat` sparse path and the O(p) sparse phylogenetic location-scale-scale engine.
  
- `:sparse_lbfgs` — force the default all-node sparse L-BFGS route for the Gaussian phylogenetic-mean cell, or the O(p) augmented-state Takahashi selected inverse engine for phylogenetic location-scale-scale models.
  
- `sparse = true` — keyword alias to select sparse solvers (e.g. for whole-tree phylogenetic LSS or two-structured Gaussian models).
  

```julia
fit = drm(bf(y ~ x + phylo(1 | sp), sigma ~ 1), Gaussian();
          data = dat, tree = tree)
```


Bivariate Gaussian fits use [`BivariateDrmFormula`](/reference/model-specification#DRM.BivariateDrmFormula); with no structured marker they fit the residual `rho12` model, and with shared `phylo(1 | group)` markers on `mu1`, `mu2`, `sigma1`, and `sigma2` they route to the verified q=4 phylogenetic engine.

**`method` — ML (default) or REML**

`method` (default `:ML`) selects the estimator. `:REML` is opt-in and is implemented for: (a) the fixed-effect Gaussian location–scale cell, (b) a single Gaussian mean random intercept `(1 | g)` on the Woodbury spine (#439), (c) Location–Scale–Scale (LSS) models (`sd(g) ~ z`, `sd(species, phylogenetic) ~ z`,     and multi-component LSS models; #558), and (d) the bivariate q=4 PLSM Laplace engine (`reml_q4`).

σ-RE, random slopes, and non-Gaussian REML stay rejected. REML likelihoods are not comparable across fixed-effect structures.

**Missing response handling**

Incomplete responses (`missing` or `NaN` in `y`) are supported under the observed-rows pattern (matching `response = "include"` in the R bridge). For Location-Scale-Scale models (#559), the group index and scale design Z_g are parameterised over all G levels, while the likelihood is evaluated on observed rows.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L362-L435" target="_blank" rel="noreferrer">source</a></Badge>



```julia
drm(formula::BivariateDrmFormula, Gaussian(); data, tree = nothing,
    K = nothing, A = nothing, coords = nothing, g_tol = 1e-8,
    q4_g_tol = 1e-3, q4_iterations = 300, q4_n_newton = 40,
    q4_vcov = true, method = :ML) -> DrmFit
```


Fit a bivariate Gaussian distributional regression model.

With no structured-effect marker, this is the residual-correlation model: `mu1`, `mu2`, `sigma1`, `sigma2`, and residual `rho12` each have their own fixed effect formula.

With matching structured markers on `mu1` and `mu2` only, this routes to the q=2 exact-Gaussian point-fit cell, `method = :ML` (default) or `method = :REML` (Patterson–Thompson; marginalises `beta_mu1`/`beta_mu2` only — see `reml_q2.jl`). The q=2 route currently accepts `phylo(1 | group)` with `tree`, `relmat(1 | group)` with `K`, or `animal(1 | group)` with `A`; it requires complete responses, identical mean fixed-effect designs, and intercept-only `sigma1`, `sigma2`, and `rho12`. `spatial(1 | group)` remains outside the formula route here.

With the same `phylo(1 | group)` marker on all four location/scale predictors (`mu1`, `mu2`, `sigma1`, and `sigma2`) and a supplied `tree`, this routes to the verified q=4 phylogenetic location-scale engine. The residual `rho12` formula remains the residual correlation; the group-level 4×4 covariance `Σ_a` is stored as `fit.ranef.Sigma_a`, with axes `(:mu1, :mu2, :sigma1, :sigma2)`. Population parameter prediction skips the internal `:phylocov` coefficient block.

```julia
fit = drm(
    bf(mu1 = @formula(y1 ~ x + phylo(1 | species)),
       mu2 = @formula(y2 ~ x + phylo(1 | species)),
       sigma1 = @formula(sigma1 ~ 1 + phylo(1 | species)),
       sigma2 = @formula(sigma2 ~ 1 + phylo(1 | species)),
       rho12 = @formula(rho12 ~ 1)),
    Gaussian();
    data = dat,
    tree = phy,
)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_bivariate.jl#L98-L138" target="_blank" rel="noreferrer">source</a></Badge>



```julia
drm(f::BivariateDrmFormula, ::Student; data, g_tol = 1e-8, method = :ML)
```


Fit a bivariate **Student-t** scatter-correlation model — drmTMB's `biv_student()`.

`mu1`/`mu2` are locations (identity link), `sigma1`/`sigma2` are **scale** parameters (log link) — not standard deviations; for `ν > 2` the marginal `SD = σ·sqrt(ν/(ν−2))` — `rho12` is the **scatter** correlation (guarded `atanh` link), and `nu` is the shared degrees of freedom on the `logm2` scale `ν = 2 + exp(η)`, so `ν > 2` and the variance is finite.

`nu` is shared across both responses by construction, and **zero `rho12` does not mean independent margins** at finite `ν`.

**Structured markers (`phylo`/`relmat`/`animal`/`spatial`) — NOT implemented**

This route stays residual-only: no random effects, no structured markers, and no REML. This is a deliberate rejection, not a missing port. The bivariate Gaussian structured routes are exact (q=2) or a verified Laplace approximation with a hand-derived, analytically differentiated per-leaf density (q=4); both depend on the conditional response being Gaussian, which a Student-t density is not. A Gaussian group-level random effect under a heavy-tailed, per-row scale-mixture likelihood has no closed-form marginal, and there is no verified non-Gaussian engine in this codebase to reuse for it — building one for this route alone would be inventing a parallel, unverified numerical design rather than mirroring the established one, on exactly the family (correlated structured scale) this project has already gotten a scale convention silently wrong once. drmTMB has the same limit, and that is the load-bearing half of this rejection, so it is written down reproducibly rather than asserted. **Re-verified live 2026-08-25** against the installed drmTMB 0.7.0:

```r
library(drmTMB); library(ape)
tr <- compute.brlen(stree(8, type = "balanced"), method = "Grafen")
tr$tip.label <- paste0("s", 1:8)
d <- data.frame(y1 = rnorm(40), y2 = rnorm(40), x = rnorm(40),
                sp = factor(rep(paste0("s", 1:8), each = 5)))
# fixed effects only -> ACCEPTED
drmTMB(bf(mu1 = y1 ~ x, mu2 = y2 ~ x, sigma1 = ~1, sigma2 = ~1,
          nu = ~1, rho12 = ~1), family = biv_student(), data = d)
# add a structured marker -> REFUSED
drmTMB(bf(mu1 = y1 ~ x + phylo(1 | sp, tree = tr), mu2 = y2 ~ x, ...),
       family = biv_student(), data = d)
#> `biv_student()` currently allows fixed-effect formulas only; random and
#>  structured effects are deferred.
```


So there is no reference implementation on **either** side of the port. For a parity goal that matters more than the numerical argument above: a parity gap cannot be closed against a capability the reference package does not have, and implementing one unilaterally would mean inventing the answer this port exists to mirror.

```julia
f = bf(mu1 = @formula(y1 ~ x), mu2 = @formula(y2 ~ x),
       sigma1 = @formula(sigma1 ~ 1), sigma2 = @formula(sigma2 ~ 1),
       nu = @formula(nu ~ 1), rho12 = @formula(rho12 ~ 1))
fit = drm(f, Student(); data = dat)
2 + exp(coef(fit, :nu)[1])   # estimated shared degrees of freedom
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/bivariate_student.jl#L56-L117" target="_blank" rel="noreferrer">source</a></Badge>



```julia
drm(f::BivariateDrmFormula, ::LogNormal; data, tree = nothing, K = nothing,
    A = nothing, coords = nothing, spatial_range = nothing, g_tol = 1e-8,
    q4_g_tol = 1e-3, q4_iterations = 300, q4_n_newton = 40, q4_vcov = true,
    method = :ML)
```


Fit a bivariate **lognormal** residual-correlation model — drmTMB's `biv_lognormal()`.

Both responses must be strictly positive. `log(y1), log(y2)` are modelled as bivariate normal, so `mu1`/`mu2` are means **on the log scale** (identity link) and `rho12` is the **log-residual** correlation — not the Pearson correlation of the raw responses. `sigma1`/`sigma2` are log-scale SDs (log link).

**Structured markers (`phylo`/`relmat`/`animal`/`spatial`)**

`phylo(1 | group)`, `relmat(1 | group)`, `animal(1 | group)`, and `spatial(1 | group)` markers are supported through the **same delegation** that already gives this family its residual fit: `log(Y)` is exactly bivariate Gaussian, so a structured call here literally runs `drm(f, Gaussian(); data = log.(data), …)` and shifts the reported log-likelihood by the (parameter-free) Jacobian. There is no separate lognormal structured engine to build or verify — the q=2 exact-Gaussian route (matching markers on `mu1`/`mu2` only) and the q=4 sparse-Laplace PLSM route (matching markers on `mu1`, `mu2`, `sigma1`, and `sigma2`) are exactly the ones documented under `drm(::BivariateDrmFormula, ::Gaussian)`, run on logged data. Because the Jacobian does not depend on any parameter, `theta`/`vcov`/`ranef` and the fitted objective's _gradient_ carry over untouched; only the log-likelihood value (and everything derived from it: aic/bic/deviance) shifts.

**Scale of a structured SD.** The group-level covariance (`fit.ranef.Sigma_a` for q=4, the random-intercept variance for q=2) is on the **log-response scale** for the `mu1`/`mu2` axes, and on the **log(SD of log-response) scale** for the `sigma1`/`sigma2` axes — two log transforms deep for the scale axes, mirroring the fixed-effect `sigma1`/`sigma2` convention above. `ranef(fit)` and `vc(fit)` inherit this without change because they are the untouched Gaussian output on `log(y)`.

Matching drmTMB's first slice, `method = :REML` is not implemented for this family: the residual-only cell has no random effects to integrate out, and extending REML to the structured cells is a later slice; use `method = :ML` (the default).

```julia
d = (; y1 = exp.(0.4 .+ randn(200)), y2 = exp.(0.1 .+ randn(200)), x = randn(200))
fit = drm(bf(@formula(y1 ~ x), @formula(y2 ~ x),
             @formula(sigma1 ~ 1), @formula(sigma2 ~ 1), @formula(rho12 ~ 1)),
          LogNormal(); data = d)
coef(fit)      # mu1/mu2 on the log scale
corpairs(fit)  # log-residual rho12
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/bivariate_lognormal.jl#L32-L83" target="_blank" rel="noreferrer">source</a></Badge>



```julia
drm(f::BivariateDrmFormula, fams::Tuple; data, kwargs...)
```


Cross-family bivariate fit — two responses from **different** families coupled by a latent-scale correlation `rho`. The Julia twin of drmTMB's `family = c(gaussian(), poisson())` route.

```julia
fit = drm(bf(mu1 = @formula(y1 ~ x), mu2 = @formula(y2 ~ x),
             sigma1 = @formula(sigma1 ~ 1), sigma2 = @formula(sigma2 ~ 1)),
          (Gaussian(), Poisson()); data = dat)
fit.rho_latent            # the latent-scale correlation
mf_summary(fit)
```


Each axis takes its own `mu` and (where the family has one) `sigma` formula. `sigma` is ignored for dispersionless families (`Poisson`, `Binomial`).

::: warning `rho12` is not a formula here

In the _Gaussian_ bivariate route `rho12 ~ x` models a per-observation residual correlation. In the cross-family route the correlation is a **latent scalar** — the two responses live on different scales, so there is no common residual to correlate per observation. Supplying `rho12` is an error rather than being silently ignored.

:::

Returns the `fit_mixed_family` result; see [`mf_summary`](/cross-family#DRM.mf_summary), [`mf_coef`](/cross-family#DRM.mf_coef). This route is **experimental** — see the `cross_family_latent` capability row.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/mixed_family.jl#L412-L439" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.DrmFit' href='#DRM.DrmFit'><span class="jlbinding">DRM.DrmFit</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
DrmFit
```


A fitted distributional regression model. Accessors: [`coef`](/reference/model-fitting-and-postfit#StatsAPI.coef), `coef(fit, :mu)`, [`vcov`](/reference/model-fitting-and-postfit#StatsAPI.vcov), [`loglik`](/reference/model-fitting-and-postfit#DRM.loglik), [`nobs`](/reference/model-fitting-and-postfit#StatsAPI.nobs), [`fixef`](/reference/model-fitting-and-postfit#DRM.fixef).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L154-L160" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Coefficients and (co)variance {#Coefficients-and-covariance}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.fixef' href='#DRM.fixef'><span class="jlbinding">DRM.fixef</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fixef(fit) -> Vector{Pair}
```


Fixed-effect coefficients per distributional parameter, with their names.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1953-L1957" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.re_sd' href='#DRM.re_sd'><span class="jlbinding">DRM.re_sd</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
re_sd(fit) -> Dict{Symbol,Float64}
```


Estimated random-effect (random-intercept) standard deviations, keyed by grouping factor. A mean-axis random intercept (`y ~ x + (1|g)`) is keyed by the bare group name and is on the response scale. A scale-axis random intercept (`sigma ~ 1 + (1|g)`) is keyed `<group>_logsigma` because that SD lives on the log-σ scale — the two are NOT directly comparable, and the suffix keeps them distinct so a side-by-side read is not silently mixing scales.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1925-L1934" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.vc' href='#DRM.vc'><span class="jlbinding">DRM.vc</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
vc(fit) -> Dict{Symbol,Matrix{Float64}}
```


Random-effect covariance summary per grouping factor.
- Correlated random-effect block (`(1 + x | g)`): a 2×2 covariance matrix — `sqrt.(diag(vc(fit)[:g]))` are the intercept/slope SDs, the off-diagonal their covariance.
  
- Scalar / structured variance components (`(1 | g)`, `relmat`/`animal`/`phylo`): a 1×1 matrix holding that component's variance `σ²`. A fit with two structured components (e.g. `phylo(1|species) + relmat(1|id)`) reports both, keyed by grouping factor.
  


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_ranef.jl#L391-L403" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.coeftable' href='#StatsAPI.coeftable'><span class="jlbinding">StatsAPI.coeftable</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
coeftable(model::StatisticalModel; level::Real=0.95)
```


Return a table with coefficients and related statistics of the model. `level` determines the level for confidence intervals (by default, 95%).

The returned `CoefTable` object implements the [Tables.jl](https://github.com/JuliaData/Tables.jl/) interface, and can be converted e.g. to a `DataFrame` via `using DataFrames; DataFrame(coeftable(model))`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L22-L31" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.coef' href='#StatsAPI.coef'><span class="jlbinding">StatsAPI.coef</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
coef(model::StatisticalModel)
```


Return the coefficients of the model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L8-L12" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.vcov' href='#StatsAPI.vcov'><span class="jlbinding">StatsAPI.vcov</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
vcov(model::StatisticalModel)
```


Return the variance-covariance matrix for the coefficients of the model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L151-L155" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.nobs' href='#StatsAPI.nobs'><span class="jlbinding">StatsAPI.nobs</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
nobs(model::StatisticalModel)
```


Return the number of independent observations on which the model was fitted. Be careful when using this information, as the definition of an independent observation may vary depending on the model, on the format used to pass the data, on the sampling plan (if specified), etc.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L104-L111" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Fitted scale and correlation {#Fitted-scale-and-correlation}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.sigma' href='#DRM.sigma'><span class="jlbinding">DRM.sigma</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
sigma(fit)
```


Fitted scale / dispersion. Returns the per-observation fitted scale(s) computed at the MLE — drmTMB's `sigma()`.
- Univariate location–scale with a single scale (`:sigma`): the `σ_i` vector (`exp.(Xσ·β̂_σ)` on the response scale; for meta-analysis `√(vᵢ + τ²)`).
  
- Bivariate co-scale: `Dict(:sigma1 => …, :sigma2 => …)`.
  
- Families with no separately fitted scale stored (e.g. Poisson, whose variance is fixed by the mean): returns an empty `Dict` — there is no free dispersion.
  

For the population-level scale _coefficients_ (on the working/log scale) use `coef(fit, :sigma)` instead.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1228-L1242" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.corpairs' href='#DRM.corpairs'><span class="jlbinding">DRM.corpairs</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
corpairs(fit)
```


Fitted between-response residual correlation(s) — drmTMB's `corpairs()`. For a bivariate co-scale model this is the per-observation `ρ12 = tanh(Xρ·β̂_ρ)` (constant when `rho12 ~ 1`, varying when `rho12 ~ x`). Univariate models have no between-response correlation and return an empty `Dict`.

For random-effect (within-group) correlations, see [`vc`](/reference/model-fitting-and-postfit#DRM.vc).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1250-L1259" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.rho12' href='#DRM.rho12'><span class="jlbinding">DRM.rho12</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
rho12(fit)
```


Fitted **residual correlation** ρ12 for a bivariate model (`bf(mu1=…, mu2=…, rho12=…)`), on the response scale (ρ12 ∈ (-1, 1)), one value per observation. Mirrors drmTMB's `rho12`. Errors for univariate fits, which have no residual correlation.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/summary.jl#L88-L94" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.coevolution_cor' href='#DRM.coevolution_cor'><span class="jlbinding">DRM.coevolution_cor</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
coevolution_cor(fit) -> NamedTuple
```


Among-axis **correlation** matrix of a q=4 phylogenetic bivariate location–scale ("coevolution") fit: the 4×4 group-level correlation between the four shared-phylogenetic axes `(mu1, mu2, sigma1, sigma2)`,

```
R = D^{-1/2} Σ_a D^{-1/2},   D = Diagonal(Σ_a),
```


back-transformed from the log-Cholesky parameterisation of the stored covariance `fit.ranef.Sigma_a`. The off-diagonals are the coevolutionary correlations — e.g. `R[1, 2] = ρ_a(mu1, mu2)` is the among-species correlation of the two trait means (the "coevolution of means" signal), `R[3, 4] = ρ_a(sigma1, sigma2)` the coevolution of the two log-scales, and the mean↔scale entries the lability couplings.

Returns a `NamedTuple`:
- `cor`  — the `4×4` correlation matrix (symmetric, PD, unit diagonal);
  
- `axes` — the axis labels `(:mu1, :mu2, :sigma1, :sigma2)`, the row/column order.
  

For the residual between-response correlation `ρ12` see [`corpairs`](/reference/model-fitting-and-postfit#DRM.corpairs); for the raw covariance see [`coevolution_vc`](/reference/model-fitting-and-postfit#DRM.coevolution_vc) or [`vc`](/reference/model-fitting-and-postfit#DRM.vc).

**Example**

```julia
fit = drm(bf(mu1 = @formula(y1 ~ x + phylo(1 | species)),
             mu2 = @formula(y2 ~ x + phylo(1 | species)),
             sigma1 = @formula(sigma1 ~ 1 + phylo(1 | species)),
             sigma2 = @formula(sigma2 ~ 1 + phylo(1 | species)),
             rho12 = @formula(rho12 ~ 1)),
          Gaussian(); data, tree = phy)
R = coevolution_cor(fit)
R.cor[1, 2]        # ρ_a(mu1, mu2): coevolution-of-means correlation
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/coevo_accessors.jl#L48-L84" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.coevolution_vc' href='#DRM.coevolution_vc'><span class="jlbinding">DRM.coevolution_vc</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
coevolution_vc(fit) -> NamedTuple
```


Per-axis phylogenetic **variance components** of a q=4 coevolution fit: the diagonal of the group-level covariance `Σ_a` (the among-species variance on each of the four shared-phylogenetic axes) and the matching standard deviations.

Returns a `NamedTuple`:
- `axes`     — the axis labels `(:mu1, :mu2, :sigma1, :sigma2)`;
  
- `variance` — `Dict(:mu1 => σ²_a(mu1), …)`, the per-axis phylo variances (`diag(Σ_a)`);
  
- `sd`       — `Dict(:mu1 => σ_a(mu1), …)`, their square roots;
  
- `cov`      — the full `4×4` covariance `Σ_a` (`== fit.ranef.Sigma_a`).
  

The variances are positive by construction (the log-Cholesky parameterisation keeps `Σ_a` positive-definite). For the correlations see [`coevolution_cor`](/reference/model-fitting-and-postfit#DRM.coevolution_cor); `vc(fit)[group]` returns the same `Σ_a` keyed by grouping factor.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/coevo_accessors.jl#L101-L119" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.coevolution_summary' href='#DRM.coevolution_summary'><span class="jlbinding">DRM.coevolution_summary</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
coevolution_summary(fit) -> NamedTuple
```


Tidy summary of a q=4 coevolution fit's among-axis structure, combining [`coevolution_vc`](/reference/model-fitting-and-postfit#DRM.coevolution_vc) and [`coevolution_cor`](/reference/model-fitting-and-postfit#DRM.coevolution_cor) into long-form vectors convenient for printing or assembling a table.

Returns a `NamedTuple`:
- `axes`        — the axis labels `(:mu1, :mu2, :sigma1, :sigma2)`;
  
- `variance`    — per-axis phylo variances, in `axes` order;
  
- `sd`          — per-axis phylo SDs, in `axes` order;
  
- `pair`        — the 6 unordered axis pairs as `Tuple{Symbol,Symbol}` (upper triangle of the correlation matrix);
  
- `correlation` — the among-axis correlation for each `pair`, in matching order;
  
- `covariance`  — the among-axis covariance for each `pair`, in matching order;
  
- `cor`         — the full `4×4` correlation matrix;
  
- `cov`         — the full `4×4` covariance matrix `Σ_a`.
  


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/coevo_accessors.jl#L128-L146" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Random-effect estimates {#Random-effect-estimates}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.ranef' href='#DRM.ranef'><span class="jlbinding">DRM.ranef</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
ranef(fit) -> Dict{Symbol,...}
```


Per-level conditional random-effect estimates (BLUPs), keyed by grouping factor. These are the posterior means of the random effects at the fitted variance components — drmTMB's `ranef()`.
- Scalar random intercept `(1 | g)`: a `Vector` of length `n_levels(g)`.
  
- Correlated `(1 + x | g)`: an `n_levels × 2` matrix (`[intercept slope]`).
  
- Multiple components `(1 | g) + (1 | h)`: one entry per factor.
  

Currently populated for the Gaussian closed-form RE paths (exact GLS conditional means). Returns an empty `Dict` for models without random effects. Non-Gaussian GLMM posterior modes (GHQ/Laplace) are not yet wired — see issue #73.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_ranef.jl#L368-L382" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Prediction and simulation {#Prediction-and-simulation}
<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.predict' href='#StatsAPI.predict'><span class="jlbinding">StatsAPI.predict</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
predict(model::RegressionModel, [newX])
```


Form the predicted response of `model`. An object with new covariate values `newX` can be supplied, which should have the same type and structure as that used to fit `model`; e.g. for a GLM it would generally be a `DataFrame` with the same variable names as the original predictors.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/regressionmodel.jl#L74-L80" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.predict_parameters' href='#DRM.predict_parameters'><span class="jlbinding">DRM.predict_parameters</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
predict_parameters(fit, newdata; type = :response, se = false)
    -> Dict{Symbol,Vector{Float64}}  (se = false)
    -> Dict{Symbol,NamedTuple}        (se = true)
```


Population-level prediction of **every** distributional parameter at `newdata` (a NamedTuple / column table), random / structured effects integrated out (exactly like [`predict`](/reference/model-fitting-and-postfit#StatsAPI.predict)). The returned `Dict` has one entry per distributional parameter the model carries — always `:mu` and (when the family uses it) `:sigma`, plus any family extras present (`:nu`, `:zi`, `:hu`, `:zoi`, `:coi`).

`type = :response` (default) applies each parameter's inverse link, so in-sample it reproduces [`marginal_parameters`](/reference/model-fitting-and-postfit#DRM.marginal_parameters) (i.e. `fit.means[:mu]`, `fit.scales[...]`). `type = :link` returns the linear predictor `Xβ̂` per parameter (the working scale).

For a univariate fit the parameters are `:mu`, (`:sigma`) plus family extras; for a bivariate fit they are `:mu1, :mu2, :sigma1, :sigma2, :rho12` (each from its own fixed-effects RHS, with the σ links `exp` and the ρ12 link `tanh`).

`se = false` (default) returns `Dict{Symbol,Vector{Float64}}` of point values. `se = true` returns `Dict{Symbol,NamedTuple}` with `p => (; value, se)` per parameter: each `se` is the **delta-method** standard error using that parameter's own coef range `r_p` from `fit.blocks` (`V_p = vcov(fit)[r_p, r_p]`), the response scale multiplying by that parameter's inverse-link derivative at `η̂` (`:sigma`→`exp`, `:rho12`→`1−ρ²`, etc.). `value` matches the `se = false` point prediction.

**Example**

```julia
x = randn(200)
y = 0.5 .- 0.8 .* x .+ exp.(-0.3 .+ 0.4 .* x) .* randn(200)
data = (; y, x)
fit = drm(bf(@formula(y ~ 1 + x), @formula(sigma ~ 1 + x)), Gaussian(); data)

p = predict_parameters(fit, data)              # Dict(:mu => …, :sigma => …)
p[:mu]    ≈ fit.means[:mu]                      # in-sample reproduction
p[:sigma] ≈ fit.scales[:sigma]

predict_parameters(fit, data; type = :link)[:mu]   # == Xβ̂ (predict link scale)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1429-L1470" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.marginal_parameters' href='#DRM.marginal_parameters'><span class="jlbinding">DRM.marginal_parameters</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
marginal_parameters(fit) -> Dict{Symbol,Vector{Float64}}
```


In-sample fitted per-observation distributional parameters, read straight from the stored fit — a cheap accessor with no recomputation. Returns the mean(s) from `fit.means` (`:mu`, or `:mu1`/`:mu2` for a bivariate fit) and every per-observation scale / correlation parameter from `fit.scales` (e.g. `:sigma`, `:nu`, `:zi`, `:hu`, `:zoi`, `:coi`; `:sigma1`/`:sigma2`/`:rho12` for a bivariate fit).

In-sample these equal `predict_parameters(fit, data)` (response scale).

**Example**

```julia
fit = drm(bf(@formula(y ~ 1 + x), @formula(sigma ~ 1 + x)), Gaussian(); data)
m = marginal_parameters(fit)
m[:mu]    == fit.means[:mu]
m[:sigma] == fit.scales[:sigma]
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1587-L1605" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.prediction_grid' href='#DRM.prediction_grid'><span class="jlbinding">DRM.prediction_grid</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
prediction_grid(reference::NamedTuple; n::Int = 50, kwargs...) -> NamedTuple
```


Build a `newdata` column table for [`predict`](/reference/model-fitting-and-postfit#StatsAPI.predict) / [`predict_parameters`](/reference/model-fitting-and-postfit#DRM.predict_parameters) by sweeping one or more predictors over supplied value ranges (their **Cartesian product**) while holding every _other_ predictor fixed at a reference value.

Pure data — no fitted model is needed, so it is trivially testable and composes directly with `predict_parameters(fit, prediction_grid(...))`.

**Arguments**
- `reference::NamedTuple`: the predictor columns to hold constant. Each held value is reduced to a scalar by this rule:
  - if `reference[col]` is an `AbstractArray` of numbers → its `mean`;
    
  - if `reference[col]` is any other `AbstractArray` → its `first` element;
    
  - otherwise → the value itself (already a scalar).
    
  Held columns are broadcast to the product length.
  
- `n::Int = 50`: reserved for future default-range generation; currently unused (every swept predictor supplies its own explicit values via `kwargs`).
  
- `kwargs...`: each `predictor = values` gives a vector/range of values to sweep for that predictor. The output rows enumerate the full Cartesian product of the swept predictors. A swept predictor named in `reference` overrides (replaces) the held value.
  

**Returns**

A `NamedTuple` of equal-length column vectors. With no swept predictors the grid has a single row at the reference; with one swept predictor it is just that range (others held); with several, the full Cartesian product.

The swept columns appear first (in `kwargs` order), then the remaining held columns (in `reference` order).

**Example**

```julia
g = prediction_grid((; x = randn(100)), x = range(-2, 2; length = 25))
length(g.x) == 25                       # a 25-row sweep over x

# Two swept predictors → Cartesian product (5 × 3 = 15 rows), z held at its mean:
g2 = prediction_grid((; x = [0.0], z = [1.0, 2.0, 3.0]), x = -2:1.0:2)
length(g2.x) == 5
all(==(2.0), g2.z)                       # z held at mean([1,2,3])

# Composes with a fit:
preds = predict_parameters(fit, g)       # Dict(:mu => …, :sigma => …) of length 25
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1507-L1552" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.simulate' href='#DRM.simulate'><span class="jlbinding">DRM.simulate</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
simulate(fit; nsim = 1, rng = default_rng())
```


Draw parametric (residual-level) replicate response(s) from the fitted model — the building block of a parametric bootstrap and posterior-predictive checks. Each draw uses the fitted per-observation mean μ̂ and the fitted dispersion / scale parameters for the family; for random-effect models the draw is conditional on the random effects being zero (population level).

Return value (univariate / random-effect / meta models):
- `nsim == 1` → a length-`nobs` response `Vector` (back-compatible).
  
- `nsim  > 1` → a `nobs × nsim` `Matrix`, one independent replicate per column.
  

Bivariate Gaussian models return `Dict(:mu1=>…, :mu2=>…)` for `nsim == 1`, or a length-`nsim` `Vector` of such `Dict`s for `nsim > 1` (a matrix of paired responses is not well defined).

Supported families: Gaussian (univariate & bivariate), Student-t, Poisson (+ zero-inflated / hurdle), NegBinomial2 (+ zero-inflated / hurdle / truncated), Beta, BetaBinomial, Binomial, Gamma, LogNormal, ZeroOneBeta, Tweedie, and CumulativeLogit.

**Example**

```julia
fit = drm(bf(@formula(y ~ x), @formula(sigma ~ x)), Gaussian(); data)
y1  = simulate(fit)               # Vector, length nobs
Y   = simulate(fit; nsim = 100)   # nobs × 100 Matrix
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1618-L1646" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.fitted' href='#StatsAPI.fitted'><span class="jlbinding">StatsAPI.fitted</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fitted(model::RegressionModel)
```


Return the fitted values of the model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/regressionmodel.jl#L8-L12" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.residuals' href='#StatsAPI.residuals'><span class="jlbinding">StatsAPI.residuals</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
residuals(model::RegressionModel)
```


Return the residuals of the model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/regressionmodel.jl#L67-L71" target="_blank" rel="noreferrer">source</a></Badge>

</details>


### Predicting distributional parameters {#Predicting-distributional-parameters}

[`predict`](/reference/model-fitting-and-postfit#StatsAPI.predict) returns the response (mean) prediction, but a distributional regression also models the scale and—bivariately—the correlation. Use [`predict_parameters`](/reference/model-fitting-and-postfit#DRM.predict_parameters) to obtain the population-level value of **every** distributional parameter the model carries (`:mu`, `:sigma`, plus any family extras) at new covariate values, with random / structured effects integrated out. [`marginal_parameters`](/reference/model-fitting-and-postfit#DRM.marginal_parameters) is the cheap in-sample accessor that reads the fitted per-observation parameters straight off the fit. [`prediction_grid`](/reference/model-fitting-and-postfit#DRM.prediction_grid) builds the new-data table to sweep over (varying chosen predictors, holding the rest at a reference value).

```julia
using DRM, Random
Random.seed!(20260603)

x = randn(500)
y = 0.5 .- 0.8 .* x .+ exp.(-0.3 .+ 0.4 .* x) .* randn(500)
data = (; y, x)

# Gaussian location–scale fit: both μ and σ depend on x.
fit = drm(bf(@formula(y ~ 1 + x), @formula(sigma ~ 1 + x)), Gaussian(); data = data)

# Per-distributional-parameter prediction over a covariate sweep.
grid = prediction_grid((; x = data.x), x = range(-2, 2; length = 11))
p = predict_parameters(fit, grid)   # Dict(:mu => …, :sigma => …) on the response scale
p[:mu]                              # predicted mean across the sweep
p[:sigma]                          # predicted scale across the sweep

# Working (link) scale instead: returns Xβ̂ per parameter.
predict_parameters(fit, grid; type = :link)[:mu]

# In-sample fitted parameters, straight off the fit (no recomputation).
marginal_parameters(fit)            # == predict_parameters(fit, data) in-sample
```


## Inference {#Inference}
<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.confint' href='#StatsAPI.confint'><span class="jlbinding">StatsAPI.confint</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
confint(model::StatisticalModel; level::Real=0.95)
```


Compute confidence intervals for coefficients, with confidence level `level` (by default 95%).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L34-L38" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.stderror' href='#StatsAPI.stderror'><span class="jlbinding">StatsAPI.stderror</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
stderror(model::StatisticalModel)
```


Return the standard errors for the coefficients of the model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L144-L148" target="_blank" rel="noreferrer">source</a></Badge>



```julia
stderror(fit) -> Vector{Float64}
```


Wald standard errors (√diag of the covariance), in the fit's coefficient order.

A coefficient's Wald SE is defined only where its estimated variance is finite and positive. At a singular boundary the observed information is not positive-definite, so the stored covariance carries a non-positive (or non-finite) variance for the unidentified direction. Rather than return a silent `NaN` there, that coefficient reports `Inf` — an undefined, infinitely wide standard error — which propagates to an unbounded `(-Inf, Inf)` Wald interval. [`check_drm`](/reference/model-fitting-and-postfit#DRM.check_drm) flags the same situation via `vcov_posdef`; drmTMB returns all-`NaN` from `sdreport` in this case.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/inference.jl#L15-L28" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.profile_result' href='#DRM.profile_result'><span class="jlbinding">DRM.profile_result</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
profile_result(fit; level = 0.95, threads = false, parm = nothing)
```


Auditable profile-likelihood confidence intervals. Returns a `NamedTuple` with:
- `ci` — the same rows returned by `confint(fit; method = :profile)`;
  
- `stats` — per-coefficient endpoint work counts;
  
- `attempted`, `used`, `failed` — coefficient counts;
  
- `threaded`, `worker_threads`, `julia_threads`, `blas_threads`, `blas_oversubscribed`, `elapsed` — CPU context and wall-clock timing;
  
- `autodiff` — profile nuisance-gradient backend (`:stored`, `:forward`, or `:finite`).
  

Set `threads = true` to parallelise independent profile coefficients. When only one coefficient is profiled, the two endpoint arms are run in parallel instead.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/inference.jl#L158-L173" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.bootstrap_ci' href='#DRM.bootstrap_ci'><span class="jlbinding">DRM.bootstrap_ci</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
bootstrap_ci(formula, family; data, B = 300, level = 0.95, rng = default_rng(), threads = false, K =, A =, tree =, algorithm = :auto, g_tol = 1e-8)
bootstrap_ci(fit; data, B = 300, level = 0.95, rng = default_rng(), threads = false, K =, A =, tree =, algorithm = :auto, g_tol = 1e-8)
```


Parametric bootstrap confidence intervals: fit the model, then `simulate` `B` replicate responses, refit each, and take percentile intervals per coefficient. Univariate-response models (fixed / random-effect / meta / structured). Same row shape as [`confint`](/reference/model-fitting-and-postfit#StatsAPI.confint). Set `threads = true` to refit bootstrap replicates in parallel. Pass through the structured-matrix keywords (`K` / `A` / `tree`) and, for Gaussian fits, the solver controls (`algorithm` / `g_tol`) exactly as to [`drm`](/reference/model-fitting-and-postfit#DRM.drm). Use `bootstrap_result` when you need attempted/used/failed counts and per-replicate failure messages. If you already have `fit = drm(...)`, pass the fit directly to avoid refitting the base model before the bootstrap replicates.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/inference.jl#L951-L965" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.bootstrap_summary' href='#DRM.bootstrap_summary'><span class="jlbinding">DRM.bootstrap_summary</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
bootstrap_summary(formula, family; data, B = 300, level = 0.95, rng = default_rng(), threads = false, K =, A =, tree =, algorithm = :auto, g_tol = 1e-8)
bootstrap_summary(fit; data, B = 300, level = 0.95, rng = default_rng(), threads = false, K =, A =, tree =, algorithm = :auto, g_tol = 1e-8)
```


Parametric bootstrap coefficient summaries in one pass: point estimate, bootstrap standard error, and percentile confidence interval. This is the bootstrap analogue of using `stderror(fit)` plus `confint(fit)`, avoiding a second bootstrap run when both SEs and intervals are needed. Row fields are `(param, coef, estimate, std_error, lower, upper)`. By default, any failed replicate errors after all failures are recorded. Set `failures = :skip` to compute summaries from successful replicates; call `bootstrap_result` to inspect the skipped failures.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/inference.jl#L1079-L1091" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.bootstrap_result' href='#DRM.bootstrap_result'><span class="jlbinding">DRM.bootstrap_result</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
bootstrap_result(formula, family; data, B = 300, level = 0.95, rng = default_rng(), threads = false, failures = :error, check_converged = false, K =, A =, tree =, algorithm = :auto, g_tol = 1e-8)
bootstrap_result(fit; data, B = 300, level = 0.95, rng = default_rng(), threads = false, failures = :error, check_converged = false, K =, A =, tree =, algorithm = :auto, g_tol = 1e-8)
```


Auditable parametric bootstrap. Returns a `NamedTuple` with:
- `summary` — the same rows returned by `bootstrap_summary`;
  
- `failures` — rows `(replicate, seed, message)` for failed refits;
  
- `attempted`, `used`, `failed` — replicate counts;
  
- `seeds` — the per-replicate seeds used for reproducibility;
  
- `threaded` — whether threaded refits were actually used.
  
- `worker_threads`, `julia_threads`, `blas_threads`, `blas_oversubscribed`, `elapsed` — CPU context and wall-clock time for the simulated-refit phase.
  

`failures = :error` (default) records failures and then errors if any replicate failed. `failures = :skip` computes summaries from successful replicates and keeps the failure records in the return value. Set `check_converged = true` to treat non-converged refits as failed replicates. Passing an existing `DrmFit` reuses that point estimate as the bootstrap seed fit and starts directly with the `B` simulated refits. Gaussian bootstrap refits pass `algorithm` and `g_tol` through to `drm(...)`; this is useful for large structured models where `:auto` selects a sparse route and the tolerance is part of the benchmarked workflow.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/inference.jl#L1203-L1226" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Information criteria {#Information-criteria}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.loglik' href='#DRM.loglik'><span class="jlbinding">DRM.loglik</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
loglik(fit) -> Float64
```


Maximised log-likelihood of the fitted model.

For a **REML** fit (`drm(...; method = :REML)`) this returns the **restricted** log-likelihood (`reml_loglik(fit)`). REML log-likelihoods are **not comparable across different fixed-effect (mean) structures** — the error-contrast basis differs — so do not use them for model selection across mean structures; the `aic`/`bic`/`lrtest` guard enforces this. Use [`ml_loglik`](/reference/model-fitting-and-postfit#DRM.ml_loglik) (the plain ML log-likelihood at the REML estimate) when an ML-comparable value is needed.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1800-L1811" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.ml_loglik' href='#DRM.ml_loglik'><span class="jlbinding">DRM.ml_loglik</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
ml_loglik(fit) -> Float64
```


The plain (unrestricted) maximum-likelihood log-likelihood. For an ML fit this equals [`loglik`](/reference/model-fitting-and-postfit#DRM.loglik); for a REML fit it is the ML log-likelihood evaluated at the REML parameter estimate — the value to use when an ML-comparable log-likelihood is needed (e.g. across different mean structures).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1854-L1861" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.reml_loglik' href='#DRM.reml_loglik'><span class="jlbinding">DRM.reml_loglik</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
reml_loglik(fit) -> Float64
```


The restricted (REML) log-likelihood. Returns `NaN` for an ML fit (REML was not used). See [`loglik`](/reference/model-fitting-and-postfit#DRM.loglik) for the cross-structure-comparison caveat.

**A convention gap on the bivariate q=2/q=4 routes (#477)**

For the **univariate** fixed-effect Gaussian location–scale REML and the Gaussian mean `(1 | g)` REML, this value is the **normalised** Patterson– Thompson restricted log-likelihood — the same convention lme4, glmmTMB and TMB report, so it is directly comparable to `logLik()` from those packages.

The **bivariate q=2 and q=4 Laplace REML routes** (`src/reml_q2.jl`, `src/reml_q4.jl` — reached via structured/phylo bivariate fits with `method = :REML`) now report the **same normalised scale** (#477, 2026-08-25).

They previously omitted the `(n_β/2)·log(2π)` constant while these univariate routes included it, so `reml_loglik(fit)` meant different things depending on which route produced the fit. For the q=4 phylo layout with `n_β = 6` the gap was `3·log(2π) ≈ 5.51` — large enough to read as a real disagreement between engines rather than a labelling difference, which is exactly how it misled this project once (see the corrected note in `test/parity/q4-reml/biv-q4-phylo-reml/expected.toml`).

Every REML route in DRM.jl now reports the normalised form, matching lme4, glmmTMB, TMB and drmTMB. See `fit_q4_reml`'s docstring in `src/reml_q4.jl` for the derivation and for the evidence: the q=4 parity gate's `atol_loglik` fell from 5.5436 to 0.03 once the constant was no longer being absorbed.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1822-L1851" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.estimation_method' href='#DRM.estimation_method'><span class="jlbinding">DRM.estimation_method</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
estimation_method(fit) -> Symbol
```


The estimator used to fit the model: `:ML` (default) or `:REML` (`drm(...; method = :REML)`).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1814-L1819" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.dof' href='#StatsAPI.dof'><span class="jlbinding">StatsAPI.dof</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
dof(model::StatisticalModel)
```


Return the number of degrees of freedom consumed in the model, including when applicable the intercept and the distribution's dispersion parameter.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L114-L119" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.aic' href='#StatsAPI.aic'><span class="jlbinding">StatsAPI.aic</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
aic(model::StatisticalModel)
```


Akaike's Information Criterion, defined as $-2 \log L + 2k$, with $L$ the likelihood of the model, and `k` its number of consumed degrees of freedom (as returned by [`dof`](/reference/model-fitting-and-postfit#StatsAPI.dof)).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L182-L188" target="_blank" rel="noreferrer">source</a></Badge>



```julia
aic(fit) -> Float64
```


Akaike information criterion, `-2·loglik + 2·dof`. Lower is better; compares models fit by **ML** (not REML) on the same data.

On a **REML** fit this uses the restricted log-likelihood and is only valid for comparing models that differ in **variance structure only** (same mean structure); a one-time warning is emitted. Use ML for cross-mean-structure selection.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1895-L1904" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.bic' href='#StatsAPI.bic'><span class="jlbinding">StatsAPI.bic</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
bic(model::StatisticalModel)
```


Bayesian Information Criterion, defined as $-2 \log L + k \log n$, with $L$ the likelihood of the model,  $k$ its number of consumed degrees of freedom (as returned by [`dof`](/reference/model-fitting-and-postfit#StatsAPI.dof)), and $n$ the number of observations (as returned by [`nobs`](/reference/model-fitting-and-postfit#StatsAPI.nobs)).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L205-L212" target="_blank" rel="noreferrer">source</a></Badge>



```julia
bic(fit) -> Float64
```


Bayesian (Schwarz) information criterion, `-2·loglik + dof·log(nobs)`.

On a **REML** fit this carries the same variance-only-comparison caveat as [`aic`](/reference/model-fitting-and-postfit#StatsAPI.aic) and emits a one-time warning.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_core.jl#L1911-L1918" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.aicc' href='#DRM.aicc'><span class="jlbinding">DRM.aicc</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
aicc(fit::DrmFit) -> Float64
```


Corrected Akaike information criterion (AICc) — the small-sample, second-order correction to [`aic`](/reference/model-fitting-and-postfit#StatsAPI.aic):

```
AICc = AIC + 2k(k + 1) / (n − k − 1)
```


with `k = dof(fit)` estimated parameters and `n = nobs(fit)` observations. The correction is always positive, so `aicc(fit) ≥ aic(fit)`, and it converges to `aic(fit)` as `n → ∞`. Prefer AICc over AIC when `n / k` is small (a common rule of thumb is `n / k < 40`). Like AIC, AICc compares models fit by **ML** on the same data; lower is better.

If `n - k - 1 <= 0` (too few observations for the correction to be defined), returns `Inf`. On a **VA** fit this errors before that short-circuit: `loglik` carries an ELBO, not a marginal log-likelihood (#136).

**Example**

```julia
fit = drm(bf(@formula(y ~ 1 + x), @formula(sigma ~ 1 + x)), Gaussian(); data)
aicc(fit) > aic(fit)        # the correction is strictly positive
isfinite(aicc(fit))         # finite whenever n - k - 1 > 0
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/comparison.jl#L184-L208" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Model comparison {#Model-comparison}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.lrtest' href='#DRM.lrtest'><span class="jlbinding">DRM.lrtest</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
lrtest(reduced::DrmFit, full::DrmFit) -> NamedTuple
```


Likelihood-ratio test for two **nested**, **ML**-fitted models, mirroring drmTMB's `anova(reduced, full)`. `reduced` must be a special case of `full` (fewer parameters); both must be fit by maximum likelihood (DRM.jl's default — REML likelihoods are not comparable across fixed-effect structures).

Returns a `NamedTuple` `(; statistic, dof, pvalue)`:
- `statistic = 2 * (loglik(full) - loglik(reduced))` — the LR statistic, which is asymptotically `χ²` with `dof` degrees of freedom under the null that the reduced model is adequate.
  
- `dof = dof(full) - dof(reduced)` — the number of extra parameters in `full`.
  
- `pvalue = ccdf(Chisq(dof), max(statistic, 0))` — the upper-tail χ² p-value.
  

`dof` must be positive (`full` must have more parameters than `reduced`), otherwise an `ArgumentError` is thrown. A negative `statistic` (the reduced model fits _better_ — a sign the models are not actually nested, or one did not converge) is still returned as-is, but the p-value clamps the statistic at zero (so `pvalue` stays in `[0, 1]`); inspect `statistic` directly in that case.

::: warning Variance components are a boundary null

The `χ²(dof)` reference is only valid when the extra parameters in `full` are interior (regular). When `full` adds a **variance component** that `reduced` lacks (a random-effect SD, `:resd`/`:resid`; a Cholesky covariance entry, `:recov`; a group-level covariance, `:phylocov`), the tested null (variance =
1. sits on the **boundary** of the parameter space and the statistic follows a
  

chi-bar-square mixture, not `χ²(dof)` (Self & Liang 1987; Stram & Lee 1994). The naive `χ²` p-value is then **conservative** (too large — the test loses power). `lrtest` detects this case and emits a one-time warning; use `lrt_boundary` (or a parametric bootstrap) for a boundary-correct p-value.

:::

**Example**

```julia
x = randn(400)
y = 0.5 .- 0.8 .* x .+ exp.(-0.3 .+ 0.4 .* x) .* randn(400)
data = (; y, x)

full    = drm(bf(@formula(y ~ 1 + x), @formula(sigma ~ 1 + x)), Gaussian(); data)
reduced = drm(bf(@formula(y ~ 1),     @formula(sigma ~ 1)),     Gaussian(); data)

t = lrtest(reduced, full)
t.statistic    # 2·(logLik_full − logLik_reduced), > 0 when x helps
t.dof          # 2 extra parameters (x in μ and in log σ)
t.pvalue       # < 0.05 when x is truly predictive
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/comparison.jl#L17-L64" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.anova' href='#DRM.anova'><span class="jlbinding">DRM.anova</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
anova(reduced::DrmFit, full::DrmFit) -> NamedTuple
```


Alias for [`lrtest`](/reference/model-fitting-and-postfit#DRM.lrtest), matching drmTMB's `anova(reduced, full)` spelling for a nested likelihood-ratio test. Returns the same `(; statistic, dof, pvalue)` NamedTuple.

**Example**

```julia
anova(reduced, full) == lrtest(reduced, full)   # true
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/comparison.jl#L170-L181" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.weights' href='#StatsAPI.weights'><span class="jlbinding">StatsAPI.weights</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
weights(model::StatisticalModel)
```


Return the weights used in the model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L158-L162" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.update' href='#DRM.update'><span class="jlbinding">DRM.update</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
update(fit::DrmFit, formula; data, kwargs...) -> DrmFit
```


Refit `fit`'s model with a new `formula` (a [`bf`](/reference/model-specification#DRM.bf) bundle), reusing the **fitted family** — the convenience refit verb, mirroring R's `update`. Equivalent to `drm(formula, family(fit); data = data, kwargs...)`.

`data` must be supplied: a `DrmFit` does **not** retain its data, so `update` cannot reuse the original observations. Any extra keyword arguments (`K`, `A`, `tree`, `coords`, `g_tol`, …) are forwarded to [`drm`](/reference/model-fitting-and-postfit#DRM.drm).

**Example**

```julia
full    = drm(bf(@formula(y ~ 1 + x), @formula(sigma ~ 1 + x)), Gaussian(); data)
# Drop x everywhere, keeping the same Gaussian family:
reduced = update(full, bf(@formula(y ~ 1), @formula(sigma ~ 1)); data = data)
length(coef(reduced)) < length(coef(full))   # fewer parameters
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/comparison.jl#L233-L251" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Diagnostics and accessors {#Diagnostics-and-accessors}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.check_drm' href='#DRM.check_drm'><span class="jlbinding">DRM.check_drm</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
check_drm(fit) -> NamedTuple
```


Post-fit convergence / identifiability diagnostics — drmTMB's `check_drm()`. Returns a `NamedTuple` and logs a short report:
- `converged` — the optimiser's convergence flag.
  
- `max_abs_grad` — `max|∇nll|` at the optimum (≈ 0 at a clean interior optimum; `NaN` if the objective was not stored on the fit).
  
- `vcov_complete` — whether the stored covariance is finite throughout. Some routes report a **partial** covariance by design: the sparse phylo fitter computes the fixed-effect block and leaves the variance-component block `NaN`. When this is `false` the three fields below cannot be computed and are reported as `false` / `NaN` / `Inf` rather than raising.
  
- `vcov_posdef` — whether the stored covariance is positive-definite (drmTMB's `sdreport` is all-`NaN` exactly when this fails).
  
- `min_eigval` / `cond` — smallest eigenvalue and condition number of the covariance; a near-zero `min_eigval` flags a singular / weakly identified direction (e.g. a variance pinned at the boundary).
  
- `penalized_map` — whether this is a penalized (MAP) fit (`penalty = drm_phylo_penalty(...)`). Such a fit reports standard errors from the _penalized_ curvature, which are credible-interval-shaped rather than frequentist, and `loglik` is the _unpenalized_ data log-likelihood.
  
- `ok` — `true` when converged, the gradient is small, and the covariance is PD. On a penalized fit the gradient criterion is **dropped**: the stored objective is unpenalized, so its gradient is non-zero at the MAP optimum by construction and scoring it would report a correct fit as broken.
  

A non-`ok` result is informative, not an error: a model sitting on a variance boundary (Watanabe-singular) can be the data's MLE, with valid Wald SEs on the remaining directions — see [`confint`](/reference/model-fitting-and-postfit#StatsAPI.confint).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/inference.jl#L1712-L1743" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.family' href='#DRM.family'><span class="jlbinding">DRM.family</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
family(fit::DrmFit)
```


Return the response family object the model was fitted with, e.g. `Gaussian()`, `Poisson()`, `Student()`. This is the post-fit accessor for the `family` slot passed to [`drm`](/reference/model-fitting-and-postfit#DRM.drm); `family(fit) === fit.family`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/summary.jl#L79-L85" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.is_converged' href='#DRM.is_converged'><span class="jlbinding">DRM.is_converged</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
is_converged(fit::DrmFit) -> Bool
```


Whether this fit may be trusted: the optimiser reported convergence **and** the optimum is not degenerate. A `false` here means the reported estimates / standard errors should not be trusted.

This is deliberately STRICTER than the raw `fit.converged` flag. The Gaussian log-likelihood is unbounded as the residual scale goes to zero: with one row per group a structured random effect can interpolate the data, so `sigma` collapses and the objective runs away to `+Inf`. `Optim.converged` only asks whether the gradient test was met, and at such a point it returns `true`.

Measured 2026-08-24 on a one-row-per-species phylo fit (#461): `sd_phylo = 22980`, `sigma = 7.5e-15`, `loglik = 6.8e13`, `converged = true` — and 25% of parametric-bootstrap replicates landed on such a point. Downstream that is WORSE than an outright failure, because every consumer treats the fit as usable and a percentile interval silently inherits the nonsense.

Checked here, at the single public accessor, rather than at the ~30 `DrmFit` construction sites across 20 family files — one place that every consumer already goes through. `fit.converged` still exposes the raw optimiser flag for anyone who wants it.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/summary.jl#L101-L124" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.deviance' href='#StatsAPI.deviance'><span class="jlbinding">StatsAPI.deviance</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
deviance(model::StatisticalModel)
```


Return the deviance of the model relative to a reference, which is usually when applicable the saturated model. It is equal, _up to a constant_, to $-2 \log L$, with $L$ the likelihood of the model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/statisticalmodel.jl#L41-L47" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='StatsAPI.dof_residual' href='#StatsAPI.dof_residual'><span class="jlbinding">StatsAPI.dof_residual</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
dof_residual(model::RegressionModel)
```


Return the residual degrees of freedom of the model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/JuliaStats/StatsAPI.jl/blob/v1.8.0/src/regressionmodel.jl#L90-L94" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Phylogenetic penalty (MAP) {#Phylogenetic-penalty-MAP}

[`drm_phylo_penalty`](/reference/model-fitting-and-postfit#DRM.drm_phylo_penalty) is the Julia twin of drmTMB's `drm_phylo_penalty()`: pass `penalty = drm_phylo_penalty(...)` to [`drm`](/reference/model-fitting-and-postfit#DRM.drm) to turn a phylogenetic variance-component fit into a **MAP** estimate. [`drm_phylo_penalty_sweep`](/reference/model-fitting-and-postfit#DRM.drm_phylo_penalty_sweep) refits across a grid of correlation-penalty scales so you can see whether a conclusion moves with the prior. [`PhyloCorPenaltyNeedsTwoSD`](/reference/model-fitting-and-postfit#DRM.PhyloCorPenaltyNeedsTwoSD) is the typed refusal when `cor_sd` is asked of a model that has no phylogenetic correlation to penalize.
<details class='jldocstring custom-block' open>
<summary><a id='DRM.drm_phylo_penalty' href='#DRM.drm_phylo_penalty'><span class="jlbinding">DRM.drm_phylo_penalty</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
drm_phylo_penalty(; sd_u = 1.0, sd_alpha = 0.05, cor_sd = nothing)
```


A PC-prior-style penalty on phylogenetic variance components — the Julia twin of drmTMB's `drm_phylo_penalty()`. Passing it to [`drm`](/reference/model-fitting-and-postfit#DRM.drm) as `penalty = …` turns the fit into a **MAP** estimate.
- `sd_u`, `sd_alpha`: an exponential prior on each phylogenetic SD, calibrated so that a priori `P(sd > sd_u) = sd_alpha`. Smaller `sd_u` shrinks harder.
  
- `cor_sd`: optional SD of a mean-zero normal prior on the _unconstrained_ (Fisher-z) phylogenetic correlation. Only meaningful for a route that actually estimates a correlation — the coupled mean↔σ block. Requesting it elsewhere raises [`PhyloCorPenaltyNeedsTwoSD`](/reference/model-fitting-and-postfit#DRM.PhyloCorPenaltyNeedsTwoSD) rather than silently doing nothing.
  

The penalized fit reports an **unpenalized** `loglik`; the penalty value is on `fit.phylo_penalty`. Standard errors come from the penalized curvature and are credible-interval-shaped — do not read them as frequentist, and do not compare penalized fits with `aic` / `lrtest` (both refuse).

::: warning `sd_u` is measured on YOUR tree's scale

`sd_u` is a threshold on the phylogenetic SD, and that SD is only meaningful relative to the tree's scale. DRM.jl builds its phylogenetic covariance from the **branch lengths as supplied**, so a tree of height `h` has tip variance `h` and the fitted SD carries a factor `sqrt(h)`. drmTMB instead standardises via `ape::vcv(tree, corr = TRUE)`, whose tips always have variance 1.

So the same `sd_u` is the **same prior on both sides only when the tree has unit height**. Copying `sd_u = 1` from an R script onto a raw tree of height 2 gives a prior roughly `sqrt(2)` tighter than intended. Rescale first:

```julia
# ape: tree$edge.length <- tree$edge.length / max(diag(vcv(tree)))
```


Measured: on an `ape::rcoal` tree of height 1.5285 the two SDs differed by exactly `sqrt(1.5285) = 1.2363` while the log-likelihoods agreed to five decimals — the same fit, two scales. See `tools/parity_phylo_penalty.R`.

:::

**Example**

```julia
pen = drm_phylo_penalty(sd_u = 0.5, sd_alpha = 0.05)
fit = drm(bf(mu = @formula(y ~ x + phylo(1 | species)), sigma = @formula(~1)),
          Gaussian(); data = dat, tree = tree, penalty = pen)
fit.phylo_penalty        # the penalty at the optimum
loglik(fit)              # UNPENALIZED data log-likelihood
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/phylo_penalty.jl#L68-L115" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.drm_phylo_penalty_sweep' href='#DRM.drm_phylo_penalty_sweep'><span class="jlbinding">DRM.drm_phylo_penalty_sweep</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
drm_phylo_penalty_sweep(f, fam; data, cor_sd = [0.25, 0.5, 1.0],
                        sd_u = 1.0, sd_alpha = 0.05,
                        phylo_coupled = true, kwargs...)
```


Prior-sensitivity sweep over the phylogenetic-correlation penalty — the Julia twin of drmTMB's `drm_phylo_penalty_sweep()`. Refits the model once per `cor_sd` value and reports whether the conclusion moves as the prior tightens.

Returns `(; summary, fits)`. `summary` is a `Vector{NamedTuple}` with fields `cor_sd`, `converged`, `vcov_posdef`, `loglik`, `cor`, and `error` — a failed fit contributes a row of `NaN`/`missing` plus its message rather than aborting the sweep. `fits` is a `Dict` keyed `"cor_sd=<value>"`.

`phylo_coupled = true` is the default because only the coupled mean↔σ block estimates a phylogenetic correlation at all; sweeping `cor_sd` over any other block would produce identical rows and _look_ like a sensitivity check while being a no-op. That case raises [`PhyloCorPenaltyNeedsTwoSD`](/reference/model-fitting-and-postfit#DRM.PhyloCorPenaltyNeedsTwoSD) from a probe fit before any of the sweep runs, so the no-op is reported rather than sold.

Extra `kwargs...` are forwarded to [`drm`](/reference/model-fitting-and-postfit#DRM.drm) (`tree`, `g_tol`, …).

**Example**

```julia
sw = drm_phylo_penalty_sweep(
        bf(mu = @formula(y ~ x + phylo(1 | species)),
           sigma = @formula(~ 1 + phylo(1 | species))),
        Gaussian(); data = dat, tree = tree, cor_sd = [0.25, 0.5, 1.0])
sw.summary          # one row per cor_sd
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/phylo_penalty.jl#L235-L265" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.PhyloPenalty' href='#DRM.PhyloPenalty'><span class="jlbinding">DRM.PhyloPenalty</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
PhyloPenalty
```


A penalty specification for phylogenetic variance components — drmTMB's `drm_phylo_penalty()` object. Fields `sd_u`, `sd_alpha`, `rate`, `cor_sd`.

`rate` is derived, not supplied: `rate = -log(sd_alpha) / sd_u`, so that a priori `P(sd > sd_u) = sd_alpha`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/phylo_penalty.jl#L36-L44" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.PhyloCorPenaltyNeedsTwoSD' href='#DRM.PhyloCorPenaltyNeedsTwoSD'><span class="jlbinding">DRM.PhyloCorPenaltyNeedsTwoSD</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
PhyloCorPenaltyNeedsTwoSD(msg)
```


Raised when `cor_sd` is requested on a model that has no phylogenetic correlation parameter to penalize. It is a distinct type, not a bare `ArgumentError`, because [`drm_phylo_penalty_sweep`](/reference/model-fitting-and-postfit#DRM.drm_phylo_penalty_sweep) must catch precisely this condition — a `cor_sd` sweep over a model with no correlation would return identical rows and look like a prior-sensitivity check while being a no-op.

Mirrors drmTMB's classed condition `drm_phylo_cor_penalty_needs_two_sd`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/phylo_penalty.jl#L52-L62" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Staged pair association {#Staged-pair-association}

[`associate_pairs`](/reference/model-fitting-and-postfit#DRM.associate_pairs) estimates a latent-normal association between two already-fitted univariate models (drmTMB's staged, frozen-margin route). The kernel must be given explicitly as [`latent_normal`](/reference/model-fitting-and-postfit#DRM.latent_normal); [`association`](/reference/model-fitting-and-postfit#DRM.association) is the post-fit summary.
<details class='jldocstring custom-block' open>
<summary><a id='DRM.associate_pairs' href='#DRM.associate_pairs'><span class="jlbinding">DRM.associate_pairs</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
associate_pairs(fit_1, fit_2; kernel, association = nothing, marginal = :LA)
```


Estimate a staged latent-normal association between two **already-fitted** univariate models — drmTMB's `associate_pairs()`.

`kernel` must be given explicitly as [`latent_normal()`](/reference/model-fitting-and-postfit#DRM.latent_normal). `association` defaults to an intercept (`~ 1`); only the intercept-only form is implemented in this slice, matching drmTMB's boundary for every pair class except its one Bernoulli × NB2 exception.

The margins are **frozen**: `fit_1` and `fit_2` are used as fitted and are never re-estimated. Reported uncertainty is therefore conditional on them.

Implemented pair class: **gaussian × binomial** (`gaussian_bernoulli`). The other four reviewed classes need a rectangle probability and are not implemented yet; they error rather than silently approximating.

```julia
fg = drm(bf(@formula(y ~ x), @formula(sigma ~ 1)), Gaussian(); data = d)
fb = drm(bf(@formula(z ~ x)), Binomial(); data = d)
a  = associate_pairs(fg, fb; kernel = latent_normal())
a.eta
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/associate_pairs.jl#L76-L100" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.latent_normal' href='#DRM.latent_normal'><span class="jlbinding">DRM.latent_normal</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
latent_normal()
```


The latent-normal association kernel. Must be passed explicitly: like drmTMB, there is no implicit association model.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/associate_pairs.jl#L36-L41" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.association' href='#DRM.association'><span class="jlbinding">DRM.association</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
association(a::PairAssociation)
```


Association summary for a staged fit — drmTMB's `association()`.

Returns a `NamedTuple` with `eta` (the latent correlation), `alpha` (the association-scale coefficient), `score`/`curvature` diagnostics, `near_boundary`, and `multistart_disagreement`.

**The uncertainty is conditional on the frozen margins** — it ignores margin estimation error, so it is not a joint standard error. Matching drmTMB, no simultaneous `eta` bands or profile intervals are offered.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/associate_pairs.jl#L527-L539" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Heritability, ICC, and derived quantities {#Heritability,-ICC,-and-derived-quantities}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.heritability' href='#DRM.heritability'><span class="jlbinding">DRM.heritability</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
heritability(fit; component = nothing, level = 0.95, method = :delta) -> NamedTuple
```


Phylogenetic heritability / signal (a.k.a. `λ` / `H²`) of a structured-Gaussian fit: the share of the total variance carried by one structured component,

```
h² = σ²_component / ( Σ_k σ²_k + σ²_resid ),
```


where the sum runs over **all** structured variance components plus the residual. This is the comparative-biology "phylogenetic signal" — for a single `phylo(1 | species)` component it is Pagel/Lynch's phylogenetic heritability; with a second structured component (e.g. `+ animal(1 | id)`) the denominator includes it too.

`component` selects which grouping factor is the numerator (a `Symbol`, e.g. `:species`); if omitted and the fit has exactly one structured component, that one is used. `method` is `:delta` (epsilon-method / generalized-delta via [`bias_correct`](/reference/model-fitting-and-postfit#DRM.bias_correct), the default) or `:profile` (a **true** profile-likelihood CI on the ratio: at each fixed ratio the likelihood is re-maximised over ALL nuisance parameters — the other variance components, residual, and mean coefficients — so the co-components can absorb variance and the profiled deviance rises at the correct rate; it is NOT a substitution/ELR profile that freezes the nuisance variances at the MLE). For the dense phylogenetic correlation-scale parameterisation, fit with `algorithm = :gls` before using delta-method Wald intervals; the default sparse all-node phylogenetic route stores only partial covariance information in this slice, so profile intervals are the safer uncertainty path there.

Returns a `NamedTuple`:
- `estimate`  — the plug-in ratio `g(θ̂)` (exactly in `[0, 1]`);
  
- `corrected` — the bias-corrected estimate `g(θ̂) + ½·tr(H_g·V)` (delta only);
  
- `se`        — the delta-method standard error (delta only);
  
- `ci`        — the `(lower, upper)` CI, **clamped to `[0, 1]`**;
  
- `level`     — the confidence level;
  
- `method`    — the method used.
  

The gradient and Hessian of the ratio are threaded EXACTLY through the log σ → variance map by automatic differentiation. At a variance boundary (`σ_component → 0` ⇒ `h² ≈ 0`, or `σ_resid → 0` ⇒ `h² ≈ 1`) the Wald SE can be degenerate; the profile method gives a more honest (possibly one-sided) interval there.

**Example**

```julia
fit = drm(bf(@formula(y ~ x + phylo(1 | species)), @formula(sigma ~ 1)),
          Gaussian(); data, tree, algorithm = :gls)
h = heritability(fit)             # single component ⇒ no `component` needed
h.estimate, h.ci
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/heritability.jl#L238-L288" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.icc' href='#DRM.icc'><span class="jlbinding">DRM.icc</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
icc(fit; component = nothing, level = 0.95, method = :delta) -> NamedTuple
```


Intraclass correlation / repeatability for one grouping factor,

```
ICC = σ²_component / ( σ²_component + σ²_resid ),
```


the share of variance at the grouping level relative to that component plus the residual (the classic two-component repeatability). When the fit has more than one structured component this is the **focal-vs-residual** repeatability for the chosen `component`; use [`heritability`](/reference/model-fitting-and-postfit#DRM.heritability) for the full-variance share that also nets out the other components. Same return shape and `method` options as [`heritability`](/reference/model-fitting-and-postfit#DRM.heritability); the CI is clamped to `[0, 1]`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/heritability.jl#L295-L308" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.bias_correct' href='#DRM.bias_correct'><span class="jlbinding">DRM.bias_correct</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
bias_correct(fit, g::Function; level = 0.95) -> NamedTuple
```


Epsilon-method (generalized-delta) bias correction for a smooth scalar derived quantity `g(θ)` of a fitted model, à la TMB `sdreport(..., bias.correct = TRUE)` (Thorson & Kristensen 2016).

`g` receives the full coefficient vector `θ = coef(fit)` (working scale: μ on the response scale, σ on `log σ`, ρ12 on `atanh ρ12`, random-effect SDs on `log σ_b`) and returns a real scalar.

Returns a `NamedTuple` with
- `estimate`  — the raw plug-in value `g(θ̂)`;
  
- `corrected` — the bias-corrected value `g(θ̂) + ½·tr(H_g·V)`;
  
- `bias`      — the correction itself, `½·tr(H_g·V)` (so `corrected = estimate + bias`);
  
- `se`        — the delta-method standard error `√(∇gᵀ V ∇g)` using the EXACT               gradient and the stored covariance `V = vcov(fit)`;
  
- `ci`        — the `(lower, upper)` Wald interval `corrected ± z·se` at `level`;
  
- `level`     — the confidence level used.
  

**Method**

With `θ̂ ≈ N(θ, V)`, a second-order Taylor expansion of `g` about `θ̂` gives the expectation `E[g(θ̂)] ≈ g(θ̂) + ½·tr(H_g(θ̂)·V)`, and the first-order delta method gives the variance `∇g(θ̂)ᵀ V ∇g(θ̂)`. The gradient `∇g` and Hessian `H_g` are obtained by automatic differentiation of `g`, so they are exact for any smooth `g`.

**Anchors / what to trust**
- **Linear `g` (identity anchor):** for `g(θ) = θ_k` (or any affine map) `H_g = 0`, so `corrected == estimate` and `se`, `ci` equal the plug-in Wald values exactly.
  
- **Curved `g` (curvature anchor):** for `g = exp` on a coordinate with Wald mean `m` and variance `v`, `corrected = exp(m)(1 + v/2)`, the second-order expansion of the analytic `E[exp(θ_k)] = exp(m + v/2)` (they agree to `O(v²)`).
  

**Caveats**

This is a _second-order_ correction under the asymptotic premise `θ̂ ≈ N(θ, V)`; it does not fix non-normality of `θ̂` or a non-PD `V` at a variance boundary (there, prefer `bootstrap_ci` / profile `confint`). It is kept distinct from the raw plug-in accessors on purpose.

**Example**

```julia
fit = drm(bf(@formula(y ~ x), @formula(sigma ~ x)), Gaussian(); data = (; y, x))
k   = only(findall(==(:sigma), first.(fit.blocks)))   # σ block
ki  = fit.blocks[k].second[1]                          # log σ intercept index
bc  = bias_correct(fit, θ -> exp(θ[ki]))               # back-transformed σ
bc.estimate, bc.corrected, bc.se, bc.ci
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/bias_correct.jl#L43-L96" target="_blank" rel="noreferrer">source</a></Badge>



```julia
bias_correct(θ̂::AbstractVector, V::AbstractMatrix, g::Function; level = 0.95)
```


Lower-level form operating directly on a point estimate `θ̂` and its covariance `V` (e.g. for testing against closed forms, or for derived quantities not tied to a `DrmFit`). Same return shape as the `DrmFit` method.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/bias_correct.jl#L103-L109" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Boundary inference {#Boundary-inference}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.chibar_pvalue' href='#DRM.chibar_pvalue'><span class="jlbinding">DRM.chibar_pvalue</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
chibar_pvalue(stat::Real, q::Integer = 1) -> Float64
```


Chi-bar-square (χ̄²) boundary-corrected upper-tail p-value for a likelihood-ratio statistic `stat = 2·(ℓ_full − ℓ_reduced)` that tests `q` **variance components = 0**. Because a variance is constrained to be non-negative, testing it at zero is a **boundary** problem and the naive `χ²(q)` reference distribution is wrong (and conservative); the correct null is a mixture of `χ²` distributions (Self & Liang 1987; Stram & Lee 1994).

Supported `q`:
- `q = 1` (one boundary parameter): null is `0.5·χ²(0) + 0.5·χ²(1)`, so
  
  ```
  p = 0.5 · P(χ²₁ > stat).
  ```
  
  At `stat = 0` this returns `0.5`; for `stat > 0` it is exactly half the naive `χ²(1)` p-value.
  
- `q = 2` (two **independent** boundary parameters): null is `0.25·χ²(0) + 0.5·χ²(1) + 0.25·χ²(2)`, so
  
  ```
  p = 0.5 · P(χ²₁ > stat) + 0.25 · P(χ²₂ > stat).
  ```
  
  At `stat = 0` this returns `0.75`.
  

**Assumptions**
- The `q` tested parameters are variances tested at the boundary `0`.
  
- For `q = 2`, the two components are **independent** (uncorrelated information); otherwise the 0.25/0.5/0.25 weights are only approximate.
  
- All other parameters are interior (regularity away from the boundary).
  
- ML fits (as with [`lrtest`](/reference/model-fitting-and-postfit#DRM.lrtest); REML likelihoods are not cross-comparable).
  

A negative `stat` (the reduced model fit _better_ — non-nesting or non-convergence) is clamped to `0`, returning the boundary value (`0.5` for `q = 1`, `0.75` for `q = 2`); inspect `stat` directly in that case. Only `q ∈ (1, 2)` are supported; other values throw an `ArgumentError`.

**Example**

```julia
stat = 3.5
chibar_pvalue(stat, 1)              # 0.5 * P(χ²₁ > 3.5)
chibar_pvalue(stat, 1) ≈ 0.5 * ccdf(Distributions.Chisq(1), stat)   # true
chibar_pvalue(0.0, 1) == 0.5        # boundary point mass
chibar_pvalue(0.0, 2) == 0.75
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/chibar.jl#L36-L82" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Cross-family post-fit {#Cross-family-post-fit}

Accessors for a `fit_mixed_family` result. [`mf_coef`](/cross-family#DRM.mf_coef) is the tidy coefficient table; the other `mf_*` helpers live beside it in the module.

## Engine constructors (q=4 and coevolution) {#Engine-constructors-q4-and-coevolution}

`AugProblem`, `make_problem`, and `fit_q4_sparse_tmb` are low-level exported interfaces behind the q=4 PLSM path. Use `drm(...)` for ordinary model fitting; these bindings serve scripts that prepare engine inputs directly.
- `AugProblem` holds the augmented-phylogeny data and q=4 design matrices used by the sparse engine.
  
- `make_problem(phy, y1, y2, X1, X2, Xs1, Xs2, Xr; species = 1:phy.n_leaves)` builds that problem and its root-conditioned precision from a phylogeny.
  
- `fit_q4_sparse_tmb(prob, Q_cond; θ0 = ..., ...)` runs the sparse q=4 optimisation on that prepared problem. Starting values must be supplied as either `θ0` (the full parameter vector) or `β0` (the mean coefficients).
  

The documented q=4 marginal evaluator and general-q coevolution bindings are listed below.
<details class='jldocstring custom-block' open>
<summary><a id='DRM.marginal_nll' href='#DRM.marginal_nll'><span class="jlbinding">DRM.marginal_nll</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
marginal_nll(prob, Q_cond, θ; u0, n_newton) -> (nll, û, ch_H, P)
```


Fresh inner Newton mode + the TRUE sparse Laplace NLL `L(θ)`. `u0` warm-starts the Newton (the optimiser reuses the previous mode). Returns the CHOLMOD factor `ch_H` and the sparse prior `P` so callers can reuse them for the gradient.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/fit_q4_sparse_tmb.jl#L242-L248" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.CoevoProblem' href='#DRM.CoevoProblem'><span class="jlbinding">DRM.CoevoProblem</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
CoevoProblem
```


A general-q coevolution dataset bound to a tree. `Y[i, :]` is the q-trait vector for data row `i`; `X` is the shared `n × k` fixed-effect design (same β columns per trait — the common comparative-biology setup); `leaf_node[i]` maps row `i` to its column in the root-conditioned augmented node set.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/coevolution_q.jl#L86-L93" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.lc_to_cov' href='#DRM.lc_to_cov'><span class="jlbinding">DRM.lc_to_cov</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
lc_to_cov(v, q) -> Matrix
```


Map a length-`q(q+1)/2` log-Cholesky vector to a q×q SPD covariance `Λ = L L'`, diagonal of `L` exponentiated. Column-major lower-triangle order (j outer, i≥j inner) — identical to `lc_to_Λ` at q=4. Eltype follows `v` (AD-friendly).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/coevolution_q.jl#L48-L54" target="_blank" rel="noreferrer">source</a></Badge>

</details>

