
# Structured-effect markers {#Structured-effect-markers}

::: tip Status — Reference

Mirrors drmTMB's [Structured-effect markers](https://itchyshin.github.io/drmTMB/reference/index.html) (6 in drmTMB). These markers wrap a random-effect term inside a [`bf`](/reference/model-specification#DRM.bf) formula to give it a known correlation structure (phylogeny, space, pedigree, an arbitrary relatedness matrix) or a known sampling-variance (meta-analysis).

:::

## Correlation-structured random effects {#Correlation-structured-random-effects}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.phylo' href='#DRM.phylo'><span class="jlbinding">DRM.phylo</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
phylo(1 | species)
```


Phylogenetic structured random intercept on the Gaussian **mean**: pass the tree via `drm(...; tree = tree)` (an `AugmentedPhy` from `random_balanced_tree` / `augmented_phy`, or a Newick string). The phylogenetic correlation is built from the tree (`sigma_phy_dense`) and the marginal is fit in closed form. (The q=4 phylogenetic _location-scale_ model — a structured effect on `log σ` too — uses the verified sparse-Laplace engine instead; see `HANDOVER.md`.)


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_structured.jl#L39-L48" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.spatial' href='#DRM.spatial'><span class="jlbinding">DRM.spatial</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
spatial(1 | site)
```


Coordinate-spatial structured random intercept on the Gaussian mean. Pass site coordinates via `drm(...; coords = coords)` (a `G×2` matrix, one row per `site` level in first-seen order). The spatial correlation `K(ρ) = exp(-d / ρ)` is built from pairwise distances and the range `ρ` is estimated jointly. Closed-form Gaussian marginal (K is rebuilt each evaluation since it depends on `ρ`).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_structured.jl#L59-L67" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.animal' href='#DRM.animal'><span class="jlbinding">DRM.animal</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
animal(1 | id)
```


Animal-model structured random intercept. Supply the additive-relatedness matrix over the levels of `id` via `drm(...; A = A)`. Reuses the closed-form structured-Gaussian engine (same as [`relmat`](/reference/structured-effect-markers#DRM.relmat)).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_structured.jl#L30-L36" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.relmat' href='#DRM.relmat'><span class="jlbinding">DRM.relmat</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
relmat(1 | id)
```


Structured random-intercept marker with a user-supplied relatedness matrix:

```julia
drm(bf(y ~ x + relmat(1 | id), sigma ~ 1), Gaussian(); data, K = K)
```


`K` is the correlation/relatedness matrix over the levels of `id`, ordered as they first appear in `data`. The marginal stays Gaussian (closed-form).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_structured.jl#L16-L27" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Known sampling variance (meta-analysis) {#Known-sampling-variance-meta-analysis}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.meta_V' href='#DRM.meta_V'><span class="jlbinding">DRM.meta_V</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
meta_V(v)
```


Formula marker for Gaussian meta-analysis: `v` is the data column of **known** sampling variances. Use inside a `μ` formula, e.g. `bf(y ~ x + meta_V(v), sigma ~ 1)`. The residual (between-study) heterogeneity SD is the `σ` parameter (the between-study τ of classical meta-analysis). (Diagonal known variances; dense/bivariate sampling covariance is planned.)


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_meta.jl#L9-L17" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.meta_vcov_bivariate' href='#DRM.meta_vcov_bivariate'><span class="jlbinding">DRM.meta_vcov_bivariate</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
meta_vcov_bivariate(v1, v2; cov12 = nothing, cor12 = nothing) -> MetaVcovBivariate
```


Build the known row-paired sampling covariance for a bivariate meta-analysis — drmTMB's `meta_vcov_bivariate()`. One entry per study: sampling variances `v1`, `v2` and either sampling covariances `cov12` or sampling correlations `cor12` (scalar or vector; at most one of the two, default independence).

Consumed by the bivariate Gaussian route as a fit-call keyword:

```julia
V = meta_vcov_bivariate(v1, v2; cor12 = 0.6)
fit = drm(bf(mu1 = @formula(y1 ~ x), mu2 = @formula(y2 ~ x),
             sigma1 = @formula(sigma1 ~ 1), sigma2 = @formula(sigma2 ~ 1),
             rho12 = @formula(rho12 ~ 1)),
          Gaussian(); data = dat, V = V)
```


The fitted `sigma1` / `sigma2` are the **between-study heterogeneity** SDs and `rho12` the **residual (heterogeneity) correlation** — the known sampling covariance is added on top per row, never absorbed into them. (This mirrors the univariate `meta_V` contract: `sigma` is heterogeneity alone, `V` separate.)

::: tip drmTMB spelling

drmTMB writes `bf(mu1 = y1 ~ x + meta_V(V = V), …)`. A keyword argument inside a formula is not representable in StatsModels' `@formula`, so DRM.jl takes the object via the `V =` keyword instead — the same place `tree` / `K` / `A` live. Writing `meta_V(...)` inside a bivariate formula errors with a pointer to this keyword.

:::


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/meta_vcov_bivariate.jl#L48-L77" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.MetaVcovBivariate' href='#DRM.MetaVcovBivariate'><span class="jlbinding">DRM.MetaVcovBivariate</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
MetaVcovBivariate
```


Known row-paired sampling covariance for bivariate meta-analysis — the object [`meta_vcov_bivariate`](/reference/structured-effect-markers#DRM.meta_vcov_bivariate) builds and `drm(...; V = …)` consumes. Fields `v1`, `v2`, `cov12`, one entry per study.

`Matrix(V)` materialises drmTMB's dense `2n × 2n` block-diagonal form (stacking order `y1[1], y2[1], y1[2], …`); the constructor also accepts such a matrix back, refusing any cross-study (off-block) entry.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/meta_vcov_bivariate.jl#L31-L41" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Location–scale–scale submodel markers {#Location–scale–scale-submodel-markers}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.sd' href='#DRM.sd'><span class="jlbinding">DRM.sd</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
sd(group)
```


Formula marker for a location–scale–scale model. Used only on the left-hand side of a `bf` component formula,

```julia
bf(y ~ x + (1 | g),              sigma ~ x, sd(g) ~ z)                  # iid RE SD
bf(y ~ x + phylo(1 | species),   sigma ~ x, sd(species, phylogenetic) ~ z)  # phylo SD
```


to put a linear predictor on the **log standard deviation of a random effect**. Plain `sd(g)` targets the iid `(1 | g)` intercept (`log σ_b,k = Z_k' α`, one row per group level); `sd(group, phylogenetic)` targets the per-species phylogenetic SD (drmTMB: `sd(group, level = "phylogenetic")`; `@formula` cannot parse keyword arguments, so the level is a bare symbol). Predictors must be constant within each group level. Univariate Gaussian only; coefficients appear as the `:sd` (iid) or `:sd_phylo` (phylogenetic) block.

**Capabilities**
- **Estimators**: supports both Maximum Likelihood (`method = :ML`, default) and Restricted Maximum Likelihood (`method = :REML`).
  
- **Missing response**: incomplete responses (`missing` or `NaN` in `y`) are fit via the observed-rows pattern (`response = "include"` in R bridge), preserving group and phylogenetic structures across all G levels.
  
- **Sparse scaling**: phylogenetic LSS models scale to large trees in O(p) time via `sparse = true` (or `algorithm = :sparse_lbfgs`), automatically selected when G &gt; 500 species.
  
- **Multi-component models**: combines multiple grouping factors or iid + phylogenetic random-effect SD models.
  


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_lss.jl#L13-L45" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.sd_phylo' href='#DRM.sd_phylo'><span class="jlbinding">DRM.sd_phylo</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
sd_phylo(group)
```


DEPRECATED legacy spelling for the phylogenetic SD submodel — use `sd(group, phylogenetic) ~ …` (drmTMB: `sd(group, level = "phylogenetic")`). Both put a linear predictor on the **log per-species SD of the phylogenetic random effect**: `a ~ MVN(0, D_a K D_a)` with `D_a = Diagonal(exp.(Z * α))` and `K` the Brownian-motion phylogenetic correlation from `tree`. Kept working, exactly as the twin keeps its legacy spelling, and canonicalised to the same `:sd_phylo` block; new code should write the `sd(group, …)` form.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/d7b49c4f18659da521d541fa7ffcfbebb70b253d/src/gaussian_lss.jl#L277-L287" target="_blank" rel="noreferrer">source</a></Badge>

</details>

