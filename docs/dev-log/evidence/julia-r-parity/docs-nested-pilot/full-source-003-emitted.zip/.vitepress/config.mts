import { defineConfig } from 'vitepress'
import { tabsMarkdownPlugin } from 'vitepress-plugin-tabs'
import { mathjaxPlugin } from './mathjax-plugin'
import { juliaReplTransformer } from './julia-repl-transformer'
import footnote from "markdown-it-footnote";
import path from 'path'

const mathjax = mathjaxPlugin()

function getBaseRepository(base: string): string {
  if (!base || base === '/') return '/';
  const parts = base.split('/').filter(Boolean);
  return parts.length > 0 ? `/${parts[0]}/` : '/';
}

const baseTemp = {
  base: '/',// TODO: replace this in makedocs!
}

const navTemp = {
  nav: [
{ text: 'api-stability', link: '/api-stability' },
{ text: 'capabilities', link: '/capabilities' },
{ text: 'changelog', link: '/changelog' },
{ text: 'cross-family', link: '/cross-family' },
{ text: 'adding-families', link: '/developer-notes/adding-families' },
{ text: 'formula-grammar', link: '/developer-notes/formula-grammar' },
{ text: 'source-map', link: '/developer-notes/source-map' },
{ text: 'exact-gaussian-diagnostics', link: '/diagnostics-and-validation/exact-gaussian-diagnostics' },
{ text: 'figure-gallery', link: '/diagnostics-and-validation/figure-gallery' },
{ text: 'implementation-map', link: '/diagnostics-and-validation/implementation-map' },
{ text: 'prediction-and-postfit', link: '/diagnostics-and-validation/prediction-and-postfit' },
{ text: 'profile-likelihood', link: '/diagnostics-and-validation/profile-likelihood' },
{ text: 'simulation-plot-grammar', link: '/diagnostics-and-validation/simulation-plot-grammar' },
{ text: 'small-sample-behaviour', link: '/diagnostics-and-validation/small-sample-behaviour' },
{ text: 'testing-likelihoods', link: '/diagnostics-and-validation/testing-likelihoods' },
{ text: 'families', link: '/families' },
{ text: 'get-started', link: '/get-started' },
{ text: 'getting-started', link: '/getting-started' },
{ text: 'index', link: '/index' },
{ text: 'convergence', link: '/model-guides/convergence' },
{ text: 'cross-family-methods', link: '/model-guides/cross-family-methods' },
{ text: 'distribution-families', link: '/model-guides/distribution-families' },
{ text: 'large-data', link: '/model-guides/large-data' },
{ text: 'marginal-la-vs-va', link: '/model-guides/marginal-la-vs-va' },
{ text: 'meta-analysis', link: '/model-guides/meta-analysis' },
{ text: 'model-map', link: '/model-guides/model-map' },
{ text: 'model-selection', link: '/model-guides/model-selection' },
{ text: 'model-workflow', link: '/model-guides/model-workflow' },
{ text: 'which-scale', link: '/model-guides/which-scale' },
{ text: 'r-julia-bridge', link: '/r-julia-bridge' },
{ text: 'deprecated-marker-internals', link: '/reference/deprecated-marker-internals' },
{ text: 'model-fitting-and-postfit', link: '/reference/model-fitting-and-postfit' },
{ text: 'model-specification', link: '/reference/model-specification' },
{ text: 'package', link: '/reference/package' },
{ text: 'structured-effect-markers', link: '/reference/structured-effect-markers' },
{ text: 'visualization', link: '/reference/visualization' },
{ text: 'rosetta', link: '/rosetta' },
{ text: 'animal-models', link: '/tutorials/animal-models' },
{ text: 'bivariate-coscale', link: '/tutorials/bivariate-coscale' },
{ text: 'bivariate-nongaussian', link: '/tutorials/bivariate-nongaussian' },
{ text: 'count-nbinom2', link: '/tutorials/count-nbinom2' },
{ text: 'location-scale-scale', link: '/tutorials/location-scale-scale' },
{ text: 'location-scale', link: '/tutorials/location-scale' },
{ text: 'meta-analysis', link: '/tutorials/meta-analysis' },
{ text: 'phylogenetic-models', link: '/tutorials/phylogenetic-models' },
{ text: 'phylogenetic-spatial', link: '/tutorials/phylogenetic-spatial' },
{ text: 'proportion-beta-binomial', link: '/tutorials/proportion-beta-binomial' },
{ text: 'relmat-known-matrices', link: '/tutorials/relmat-known-matrices' },
{ text: 'robust-student', link: '/tutorials/robust-student' },
{ text: 'spatial-models', link: '/tutorials/spatial-models' },
{ text: 'structural-dependence', link: '/tutorials/structural-dependence' }
]
,
}

const nav = [
  ...navTemp.nav,
  {
    component: 'VersionPicker'
  }
]

// https://vitepress.dev/reference/site-config
export default defineConfig({
  base: '/',// TODO: replace this in makedocs!
  title: 'DRM.jl',
  description: 'Documentation for DRM.jl',
  lastUpdated: true,
  cleanUrls: true,
  outDir: '../1', // This is required for MarkdownVitepress to work correctly...
  head: [
    
    ['script', {src: `${getBaseRepository(baseTemp.base)}versions.js`}],
    // ['script', {src: '/versions.js'], for custom domains, I guess if deploy_url is available.
    ['script', {src: `${baseTemp.base}siteinfo.js`}]
  ],
  
  markdown: {
    codeTransformers: [juliaReplTransformer()],
    config(md) {
      md.use(tabsMarkdownPlugin);
      md.use(footnote);
      mathjax.markdownConfig(md);
    },
    theme: {
      light: "github-light",
      dark: "github-dark"
    },
  },
  vite: {
    plugins: [
      mathjax.vitePlugin,
    ],
    define: {
      __DEPLOY_ABSPATH__: JSON.stringify('/'),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '../components')
      }
    },
    optimizeDeps: {
      exclude: [ 
        '@nolebase/vitepress-plugin-enhanced-readabilities/client',
        'vitepress',
        '@nolebase/ui',
      ], 
    }, 
    ssr: { 
      noExternal: [ 
        // If there are other packages that need to be processed by Vite, you can add them here.
        '@nolebase/vitepress-plugin-enhanced-readabilities',
        '@nolebase/ui',
      ], 
    },
  },
  themeConfig: {
    outline: 'deep',
    
    search: {
      provider: 'local',
      options: {
        detailedView: true
      }
    },
    nav,
    sidebar: [
{ text: 'api-stability', link: '/api-stability' },
{ text: 'capabilities', link: '/capabilities' },
{ text: 'changelog', link: '/changelog' },
{ text: 'cross-family', link: '/cross-family' },
{ text: 'adding-families', link: '/developer-notes/adding-families' },
{ text: 'formula-grammar', link: '/developer-notes/formula-grammar' },
{ text: 'source-map', link: '/developer-notes/source-map' },
{ text: 'exact-gaussian-diagnostics', link: '/diagnostics-and-validation/exact-gaussian-diagnostics' },
{ text: 'figure-gallery', link: '/diagnostics-and-validation/figure-gallery' },
{ text: 'implementation-map', link: '/diagnostics-and-validation/implementation-map' },
{ text: 'prediction-and-postfit', link: '/diagnostics-and-validation/prediction-and-postfit' },
{ text: 'profile-likelihood', link: '/diagnostics-and-validation/profile-likelihood' },
{ text: 'simulation-plot-grammar', link: '/diagnostics-and-validation/simulation-plot-grammar' },
{ text: 'small-sample-behaviour', link: '/diagnostics-and-validation/small-sample-behaviour' },
{ text: 'testing-likelihoods', link: '/diagnostics-and-validation/testing-likelihoods' },
{ text: 'families', link: '/families' },
{ text: 'get-started', link: '/get-started' },
{ text: 'getting-started', link: '/getting-started' },
{ text: 'index', link: '/index' },
{ text: 'convergence', link: '/model-guides/convergence' },
{ text: 'cross-family-methods', link: '/model-guides/cross-family-methods' },
{ text: 'distribution-families', link: '/model-guides/distribution-families' },
{ text: 'large-data', link: '/model-guides/large-data' },
{ text: 'marginal-la-vs-va', link: '/model-guides/marginal-la-vs-va' },
{ text: 'meta-analysis', link: '/model-guides/meta-analysis' },
{ text: 'model-map', link: '/model-guides/model-map' },
{ text: 'model-selection', link: '/model-guides/model-selection' },
{ text: 'model-workflow', link: '/model-guides/model-workflow' },
{ text: 'which-scale', link: '/model-guides/which-scale' },
{ text: 'r-julia-bridge', link: '/r-julia-bridge' },
{ text: 'deprecated-marker-internals', link: '/reference/deprecated-marker-internals' },
{ text: 'model-fitting-and-postfit', link: '/reference/model-fitting-and-postfit' },
{ text: 'model-specification', link: '/reference/model-specification' },
{ text: 'package', link: '/reference/package' },
{ text: 'structured-effect-markers', link: '/reference/structured-effect-markers' },
{ text: 'visualization', link: '/reference/visualization' },
{ text: 'rosetta', link: '/rosetta' },
{ text: 'animal-models', link: '/tutorials/animal-models' },
{ text: 'bivariate-coscale', link: '/tutorials/bivariate-coscale' },
{ text: 'bivariate-nongaussian', link: '/tutorials/bivariate-nongaussian' },
{ text: 'count-nbinom2', link: '/tutorials/count-nbinom2' },
{ text: 'location-scale-scale', link: '/tutorials/location-scale-scale' },
{ text: 'location-scale', link: '/tutorials/location-scale' },
{ text: 'meta-analysis', link: '/tutorials/meta-analysis' },
{ text: 'phylogenetic-models', link: '/tutorials/phylogenetic-models' },
{ text: 'phylogenetic-spatial', link: '/tutorials/phylogenetic-spatial' },
{ text: 'proportion-beta-binomial', link: '/tutorials/proportion-beta-binomial' },
{ text: 'relmat-known-matrices', link: '/tutorials/relmat-known-matrices' },
{ text: 'robust-student', link: '/tutorials/robust-student' },
{ text: 'spatial-models', link: '/tutorials/spatial-models' },
{ text: 'structural-dependence', link: '/tutorials/structural-dependence' }
]
,
    sidebarDrawer: false,
    editLink: { pattern: "https://github.com/itchyshin/DRM.jl/edit/main/docs/src/:path" },
    socialLinks: [
      { icon: 'github', link: 'https://github.com/itchyshin/DRM.jl' }
    ],
    footer: {
      message: 'Made with <a href="https://luxdl.github.io/DocumenterVitepress.jl/dev/" target="_blank"><strong>DocumenterVitepress.jl</strong></a><br>',
      copyright: `© Copyright ${new Date().getUTCFullYear()}.`
    }
  }
})
