
# Engine internals and advanced constructors {#Engine-internals-and-advanced-constructors}

::: warning Developer reference

This appendix records docstrings for the sparse, coevolution, bridge, and marginal-likelihood implementation surface. Names beginning with `_` are nonpublic implementation helpers. Exported advanced constructors are included for source coverage, not as a claim that every combination is a supported `drm(...)` route. Start with the model guides and capability matrix for ordinary fitting.

:::

## Marginal-method and association internals {#Marginal-method-and-association-internals}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.AGHQ' href='#DRM.AGHQ'><span class="jlbinding">DRM.AGHQ</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
AGHQ <: MarginalMethod
```


1-D Liu–Pierce adaptive Gauss–Hermite quadrature (#448). Opt-in via `marginal = :AGHQ` on Poisson `(1 | g)` only (`nAGQ=5` default). This is plumbing — k=1 ≡ 1-point Laplace; k≈5 nll agrees with GHQ-32. Not a recovery headline, not a capability-chip flip, not tensor AGHQ on phylo Laplace. `:REML` is not wired to `:AGHQ` this slice.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/variational.jl#L33-L40" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Laplace' href='#DRM.Laplace'><span class="jlbinding">DRM.Laplace</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Laplace <: MarginalMethod
```


Laplace marginal: Gaussian approximation at the posterior mode. The default. On Poisson `(1 | g)` the public `:LA` path is **non-adaptive GHQ-32**, not 1-point Laplace and not AGHQ.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/variational.jl#L17-L22" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Variational' href='#DRM.Variational'><span class="jlbinding">DRM.Variational</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Variational <: MarginalMethod
```


Gaussian-variational (VA/ELBO) marginal — opt-in alternative to `Laplace` for bias-sensitive random-effect models (#136). Public `drm` path (Experimental): Poisson / Binomial / NegBinomial2 / Gamma / Beta random intercept `(1 | g)` via `marginal = :VA` (scale families need `sigma ~ 1`). Phylo, crossed, correlated slopes, ZI/hu, and 136e stay unwired; #136 stays open.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/variational.jl#L24-L31" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.MarginalMethod' href='#DRM.MarginalMethod'><span class="jlbinding">DRM.MarginalMethod</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
MarginalMethod
```


How a model's random-effect integral is approximated. Subtypes: `Laplace` (mode + curvature; the default, what drmTMB/TMB use), `Variational` (maximize an ELBO over a Gaussian q; opt-in, steadier on dispersion/shape — #136), and `AGHQ` (1-D Liu–Pierce adaptive Gauss–Hermite; opt-in Poisson `(1 | g)` only — #448).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/variational.jl#L7-L14" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.LatentNormal' href='#DRM.LatentNormal'><span class="jlbinding">DRM.LatentNormal</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
LatentNormal
```


Association kernel for [`associate_pairs`](/reference/model-fitting-and-postfit#DRM.associate_pairs) — drmTMB's `latent_normal()`. The two margins are coupled through a bivariate standard normal latent with correlation `eta`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/associate_pairs.jl#L27-L33" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._aghq_1d_logint' href='#DRM._aghq_1d_logint'><span class="jlbinding">DRM._aghq_1d_logint</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_aghq_1d_logint(logf, mode, hess; k=5)
_aghq_1d_logint(logf, mode, hess, z, w)
```


Log of `∫ exp(logf(x)) dx` by Liu–Pierce (1994) adaptive Gauss–Hermite quadrature, wrapping `_gauss_hermite`.

`mode` maximises `logf`; `hess = logf''(mode)` must be negative. Nodes and weights `(z, w)` are the physicists' rule `∫ h(x) e^{-x²} dx ≈ Σ wₖ h(zₖ)`. The adaptive map is `x = mode + √2 σ z` with `σ = 1/√(−hess)`, so

```
∫ exp(logf) ≈ √2 σ Σₖ wₖ exp(logf(xₖ) + zₖ²).
```


`k=1` (node 0, weight `√π`) is exactly the 1-point Laplace approximation `logf(mode) + ½ log(2π) − ½ log(−hess)`. That is a plumbing identity, not a quadrature or recovery claim.

A non-scalar `mode` fails loud (`dim ≠ 1`). Multi-d / tensor AGHQ is out of scope for #448.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/aghq_1d.jl#L24-L44" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._aghq_require_1d' href='#DRM._aghq_require_1d'><span class="jlbinding">DRM._aghq_require_1d</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_aghq_require_1d(dim)
```


Throw `ArgumentError` unless `dim == 1`. 1-D Liu–Pierce AGHQ only (#448).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/aghq_1d.jl#L12-L16" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._assoc_logdiffexp' href='#DRM._assoc_logdiffexp'><span class="jlbinding">DRM._assoc_logdiffexp</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_assoc_logdiffexp(a, b)
```


`log(exp(a) − exp(b))` for `a ≥ b`, computed without forming either exponential. Returns `-Inf` when the two are indistinguishable rather than a negative argument to `log`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/associate_pairs.jl#L216-L222" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._poisson_group_aghq_logint' href='#DRM._poisson_group_aghq_logint'><span class="jlbinding">DRM._poisson_group_aghq_logint</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_poisson_group_aghq_logint(y, η0, lf, idx, σb, k)
```


Log `∫ L(y_g | b) φ(b; 0, σb²) db` for one Poisson `(1 | g)` group via 1-D Liu–Pierce AGHQ.

The group posterior is strictly concave. The inner mode is a **fixed** 12-step Newton unroll (same discipline as the VA inner solve) so the outer nll stays ForwardDiff-smooth. `k=1` recovers 1-point Laplace of this integrand — plumbing, not a recovery claim.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/aghq_1d.jl#L78-L88" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Augmented phylogeny and sparse linear algebra {#Augmented-phylogeny-and-sparse-linear-algebra}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.AugmentedPhy' href='#DRM.AugmentedPhy'><span class="jlbinding">DRM.AugmentedPhy</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
AugmentedPhy{T}
```


Augmented-state sparse phylogenetic precision for a binary tree.

**Fields**
- `n_leaves::Int`               – number of tip species (p).
  
- `n_total::Int`                – 2p − 1, leaves + internal ancestor nodes.
  
- `Q_topology::SparseMatrixCSC` – (n_total × n_total) topology contribution to the sparse precision. The actual phylogenetic precision is `Q_topology / σ²_phy`. About 8p non-zeros.
  
- `leaf_indices::Vector{Int}`   – maps a leaf k ∈ 1:p to its row/col in the augmented state. Ordering matches the order leaves were encountered in the Newick string (left-to-right).
  
- `leaf_names::Vector{String}`  – species names parsed from the Newick.
  
- `branch_lengths::Vector{T}`   – the 2p − 2 branch lengths in the order the parser walked the tree.
  
- `root_index::Int`             – which augmented row is the root.
  

`Q_topology` is positive **semi**-definite (rank 2p − 2). The all-ones vector is its sole zero eigenvector — fixing the root removes the degeneracy. The sparse log-likelihood path adds a positive contribution to the leaf diagonals (proportional to `λ_phy² / d_total`) which renders the active solve matrix positive definite without any explicit ridge.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_phy.jl#L39-L64" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Vinv_mul' href='#DRM.Vinv_mul'><span class="jlbinding">DRM.Vinv_mul</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



V^{-1} z via Woodbury: (z - S (M^{-1} (1/σ²) S' z)) / σ² 


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/location_only.jl#L199" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.build_M' href='#DRM.build_M'><span class="jlbinding">DRM.build_M</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Build M = P + (1/σ²) S'S.  Return (P, M, chM, chP). chP = chol(P + ridge) for logdet P; chM = chol(M) for the Woodbury solves.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/location_only.jl#L179-L182" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.exact_traces' href='#DRM.exact_traces'><span class="jlbinding">DRM.exact_traces</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



EXACT Tr(Q_cond M^{-1}) and Tr(S M^{-1} S') via Takahashi selected inverse. Returns (tr_QM, tr_SMS).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/location_only.jl#L3163-L3166" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.logdetV_val' href='#DRM.logdetV_val'><span class="jlbinding">DRM.logdetV_val</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



logdet V = n log σ² + logdet M − logdet P 


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/location_only.jl#L205" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.make_phy' href='#DRM.make_phy'><span class="jlbinding">DRM.make_phy</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
make_phy(edges::AbstractVector{<:Tuple}, n_leaves::Integer;
         root_index::Integer = -1) :: AugmentedPhy{Float64}
```


Convenience constructor: build an `AugmentedPhy` from a list of edges `(parent_id, child_id, branch_length)` with integer node ids 1..n_total (leaves first, internals last is the recommended convention but not required).

If `root_index < 0` it is auto-detected as the unique node that is not a child in any edge.

This bypasses the Newick parser — useful for tests and for trees that arrive from another tool already as edge lists.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_phy.jl#L302-L316" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.make_problem_from_Q' href='#DRM.make_problem_from_Q'><span class="jlbinding">DRM.make_problem_from_Q</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
make_problem_from_Q(Q_cond, y1, y2, X1, X2, Xs1, Xs2, Xr; group) -> (prob, Q)
```


Build an [`AugProblem`](/reference/model-fitting-and-postfit#AugProblem) from a known G×G group-level precision (relmat / animal / fixed-range spatial) rather than from an augmented phylogeny. `group[i]` maps data row `i` to a 1-based level in `1:G`. Returns `(prob, sparse(Q_cond))` for [`fit_q4_sparse_tmb`](/reference/model-fitting-and-postfit#fit_q4_sparse_tmb).

This is the #189 level-indexed entry point; the phylo path keeps [`make_problem`](/reference/model-fitting-and-postfit#make_problem).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_em_fit.jl#L47-L56" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.q4_marginal_diagnostic' href='#DRM.q4_marginal_diagnostic'><span class="jlbinding">DRM.q4_marginal_diagnostic</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
q4_marginal_diagnostic(prob, Q_cond, theta; u0=nothing, n_newton=40,
                       gradient=false)
```


Developer diagnostic for the q=4 ML Laplace objective. It evaluates the same pieces used by [`marginal_nll`](/reference/model-fitting-and-postfit#DRM.marginal_nll) in order and returns a NamedTuple with `ok`, `first_nonfinite`, `stages`, and (when finite) `nll`.

This is intentionally diagnostic-only: the optimizer keeps its usual `Inf` barrier, while hard large-data failures can call this helper to see whether the first non-finite component is the parameter vector, among-axis covariance, sparse prior precision, inner mode, Laplace components, or exact-gradient assembly.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fit_q4_sparse_tmb.jl#L107-L119" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.takahashi_diag' href='#DRM.takahashi_diag'><span class="jlbinding">DRM.takahashi_diag</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
takahashi_diag(ch::SparseArrays.CHOLMOD.Factor) -> Vector{Float64}
```


Convenience: return ONLY `diag(Q⁻¹)` (a length-n vector, in the ORIGINAL ordering) via the Takahashi recursion. Same cost as `takahashi_selinv` but without materialising the full sparse output (a small allocation win when only the diagonal is needed, as in the EM E-step's per-trait variance).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/takahashi_selinv.jl#L191-L198" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.takahashi_selinv' href='#DRM.takahashi_selinv'><span class="jlbinding">DRM.takahashi_selinv</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
takahashi_selinv(ch::SparseArrays.CHOLMOD.Factor) -> SparseMatrixCSC
```


Compute the Takahashi selected inverse of the matrix `Q` whose sparse Cholesky factor is `ch` (`P · Q · Pᵀ = L · Lᵀ` with `P = I[ch.p, :]`). Returns a `SparseMatrixCSC` holding `Q⁻¹` (in the ORIGINAL un-permuted ordering) at the union sparsity of `Pᵀ (L + Lᵀ) P`. Entries outside that pattern are NOT computed (and are NOT zero in general).

Cost: `O(nnz(L))` arithmetic + O(nnz(L)·log(max_col_nnz)) for the symmetric lookups (with constant `max_col_nnz` on a tree this is `O(nnz(L))` overall).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/takahashi_selinv.jl#L91-L102" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.theta_len' href='#DRM.theta_len'><span class="jlbinding">DRM.theta_len</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Total θ length = sum(beta widths) + 10 (log-Cholesky Λ).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fit_q4_sparse_tmb.jl#L42" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.unpack_theta' href='#DRM.unpack_theta'><span class="jlbinding">DRM.unpack_theta</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Slice θ into a β NamedTuple and the 10-vector lc (eltype follows θ).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fit_q4_sparse_tmb.jl#L48" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.pack_theta' href='#DRM.pack_theta'><span class="jlbinding">DRM.pack_theta</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Build a Float64 θ from a β NamedTuple and a Λ matrix.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fit_q4_sparse_tmb.jl#L58" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## q=4 and Fisher-z evaluators {#q4-and-Fisher-z-evaluators}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.beta_widths' href='#DRM.beta_widths'><span class="jlbinding">DRM.beta_widths</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Column widths (k1,k2,ks1,ks2,kr) of the five design matrices.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fit_q4_sparse_tmb.jl#L38" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fit_q4_reml' href='#DRM.fit_q4_reml'><span class="jlbinding">DRM.fit_q4_reml</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fit_q4_reml(prob, Q_cond; beta0, Lambda0, [phi0], g_tol, ...) -> NamedTuple
```


Fit REML objective over phi = (beta_rho, lc). beta_mu AND beta_sigma (the location and scale fixed effects) are profiled out internally; only beta_rho stays outer.

Returns NamedTuple: (phi, beta, Lambda, reml_loglik, ml_loglik, converged,                      iterations, g_residual, f_calls, u_hat)

**Automatic warm restart (#484)**

On some cells the REML LBFGS's first line-search step from the ML warm start fails outright (zero accepted steps — a starting-value problem, not slow convergence, so a bigger `iterations` or looser `g_tol` cannot fix it). That exact stall (`!converged` with the minimizer still sitting at `phi0`) is detected automatically and retried by re-deriving a coarser ML warm start and continuing from there — judged at the SAME `g_tol` the caller passed, never a loosened one. A REML fit whose first attempt already moves at all — converged or not — is completely unaffected; see the block above `phi_hat` for the mechanism. Needs `beta0`/`Lambda0` to fire (skipped if the caller supplied `phi0` directly, since there is then nothing to re-derive a coarser start from).

**Normalisation convention (#477)**

`reml_loglik` reports the **normalised** Patterson–Thompson restricted log-likelihood: the raw objective `ℓ_ML(θ, β̂) − ½ logdet(S)` plus `(n_β/2)·log(2π)`, the constant from integrating the flat prior over the `n_β` marginalised fixed effects (`n_β` = the combined width of the `beta_mu1`, `beta_mu2`, `beta_s1`, `beta_s2` designs — exactly the Schur complement's dimension; `beta_rho` is never marginalised, so it does not count). That matches lme4, glmmTMB and TMB, so `reml_loglik` is directly comparable across engines.

**Changed 2026-08-25 (#477).** It previously reported the unnormalised form, while DRM.jl's own univariate REML routes — `_fit_fixed_gaussian_reml` (`gaussian_core.jl`), the Gaussian mean `(1 | g)` route (`gaussian_ranef.jl`) and `location_only.jl` — already added the constant. So one package reported two different scales under one name, and `reml_loglik(fit)` meant different things depending on which route produced the fit. That was an inconsistency rather than a convention choice: the convention had already been made on the univariate side and the bivariate routes simply had not followed it.

The evidence is the q=4 parity gate. Its `atol_loglik` was **5.5436**, of which **5.513631** was this constant — a tolerance that existed almost entirely to absorb the offset, and therefore tested almost nothing. It is now **0.03**, the cross-optimum spread alone: a 185× tightening, verified 33/33. A constant cannot move the argmax, so the optimisation is untouched; only the reported value moved.

`reml_q2.jl` carries the same change and the same derivation, but has no parity fixture of its own — it is verified only by sharing this one's arithmetic.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/reml_q4.jl#L305-L355" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fit_q4_sparse_fisherz' href='#DRM.fit_q4_sparse_fisherz'><span class="jlbinding">DRM.fit_q4_sparse_fisherz</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fit_q4_sparse_fisherz(prob, Q_cond; β0, Σa0 / Λ0, ...) -> NamedTuple
```


Fit the q=4 PLSM in the Fisher-z D·R·D OUTER parameterization. The inner engine is the UNTOUCHED `marginal_and_exact_grad`. Returns Σ_a (= D R D) and the 6 among-axis correlations directly, alongside the usual fit diagnostics.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L215-L221" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_DRD' href='#DRM.fz_DRD'><span class="jlbinding">DRM.fz_DRD</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Σ_a = D R D (4×4 PD) from φ_a = [d (4 log-SDs); θ_R (6 angle-reals)].


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L77" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_R' href='#DRM.fz_R'><span class="jlbinding">DRM.fz_R</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



4×4 correlation matrix R = C Cᵀ from the 6 angle-reals θ_R (always PD, unit diag).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L71" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_R_chol' href='#DRM.fz_R_chol'><span class="jlbinding">DRM.fz_R_chol</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Lower-tri correlation-Cholesky C (4×4) from the 6 angle-reals θ_R (R = C Cᵀ).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L51" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_init_from_Sigma' href='#DRM.fz_init_from_Sigma'><span class="jlbinding">DRM.fz_init_from_Sigma</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Initial φ_a = [d; θ_R] reproducing a starting Σ_a (used to seed the optimiser).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L120" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_marginal_and_grad' href='#DRM.fz_marginal_and_grad'><span class="jlbinding">DRM.fz_marginal_and_grad</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fz_marginal_and_grad(prob, Q_cond, ψ; u0, n_newton) -> (nll, g_ψ, û, chH)
```


TRUE sparse Laplace NLL and its EXACT gradient in the Fisher-z OUTER parameters ψ = [β; φ_a]. Calls the UNTOUCHED `marginal_and_exact_grad` on θ = [β; lc(φ_a)], then chain-rules the Σ_a block: g_φ = Jᵀ g_lc with J = ∂lc/∂φ_a. β passes through.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L179-L185" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_marginal_nll' href='#DRM.fz_marginal_nll'><span class="jlbinding">DRM.fz_marginal_nll</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Fisher-z marginal NLL only (for FD verification / line search).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L204" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_psi_len' href='#DRM.fz_psi_len'><span class="jlbinding">DRM.fz_psi_len</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Length of ψ = nβ + 10 (the Fisher-z outer parameter vector).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L164" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_psi_to_theta' href='#DRM.fz_psi_to_theta'><span class="jlbinding">DRM.fz_psi_to_theta</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



ψ (Fisher-z) → engine θ (β + lc). Pure reparameterization of the Σ_a block.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L173" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fz_unpack_psi' href='#DRM.fz_unpack_psi'><span class="jlbinding">DRM.fz_unpack_psi</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Split ψ into the β-block (Float-passthrough) and φ_a (10).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fisherz_q4.jl#L167" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.marginal_and_exact_grad' href='#DRM.marginal_and_exact_grad'><span class="jlbinding">DRM.marginal_and_exact_grad</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
marginal_and_exact_grad(prob, Q_cond, θ; u0, n_newton) -> (nll, grad, û, ch_H)
```


TRUE sparse Laplace NLL and its EXACT 17-dim gradient (cheap + implicit), with the inner mode `û` FROZEN. All CHOLMOD-blocked logdet θ-derivatives use the Takahashi selected inverse of H (O(p)); all other pieces are single-level AD. Returns `û` and the factor so the caller can warm-start the next evaluation.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/fit_q4_sparse_tmb.jl#L280-L287" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Coevolution and phylogenetic interaction kernels {#Coevolution-and-phylogenetic-interaction-kernels}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.coevo_marginal_cov' href='#DRM.coevo_marginal_cov'><span class="jlbinding">DRM.coevo_marginal_cov</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
coevo_marginal(prob, Q_cond, β, Λ, σ_res) -> (ℓ, û, ch_H, P)
```


EXACT Laplace (= Gaussian) marginal log-likelihood at the given parameters, plus the inner mode `û`, the CHOLMOD factor of `H_uu`, and the sparse prior `P`. `β` is `k × q` (trait-major columns), `Λ` is q×q SPD, `σ_res` a length-q vector of residual SDs.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L216-L223" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.coevo_pack' href='#DRM.coevo_pack'><span class="jlbinding">DRM.coevo_pack</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Pack (β::k×q, Λ::q×q, σ_res::q) → θ (Float64).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L300" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.coevo_unpack' href='#DRM.coevo_unpack'><span class="jlbinding">DRM.coevo_unpack</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Unpack θ → (β::k×q, Λ::q×q, σ_res::q). Eltype follows θ.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L290" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.cov_to_lc' href='#DRM.cov_to_lc'><span class="jlbinding">DRM.cov_to_lc</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
cov_to_lc(Λ) -> Vector{Float64}
```


Inverse of [`lc_to_cov`](/reference/model-fitting-and-postfit#DRM.lc_to_cov): log-Cholesky vector of a SPD `Λ` (q inferred from `size`). Column-major lower-triangle order.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L66-L71" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fit_coevolution' href='#DRM.fit_coevolution'><span class="jlbinding">DRM.fit_coevolution</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fit_coevolution(prob, Q_cond; β0, Λ0, σ0, g_tol, iterations) -> NamedTuple
```


Fit the general-q coevolution model by maximising the EXACT (conjugate-Gaussian) Laplace marginal over (β, log-Cholesky Λ, log σ_res). Uses `LBFGS` with a central finite-difference gradient: the marginal is a single sparse solve, so FD is cheap, and a quasi-Newton method converges far faster than a simplex on the `k·q + q(q+1)/2 + q`-dimensional θ. ForwardDiff cannot flow through the CHOLMOD factor (the same constraint the q=4 engine hits), hence FD rather than AD here. Returns `(; β, Λ, σ_res, loglik, converged, iterations, θ)`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L304-L314" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fit_coevolution_q2_reml' href='#DRM.fit_coevolution_q2_reml'><span class="jlbinding">DRM.fit_coevolution_q2_reml</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fit_coevolution_q2_reml(prob, Q_cond; β0, Λ0, σ0, rho0, g_tol, iterations) -> NamedTuple
```


REML (Patterson–Thompson) fit for the bivariate q=2 structured residual- correlation coevolution model — the REML counterpart of [`fit_coevolution_q2_residual`](/reference/engine-internals#DRM.fit_coevolution_q2_residual). Marginalises `beta_mu1` and `beta_mu2` (the two axes carrying the structured random effect Λ); `beta_sigma1`, `beta_sigma2`, and `beta_rho12` stay outer parameters, since sigma1/sigma2/ rho12 are intercept-only fixed effects with no random-effect axis to integrate against. See this file's header for why exactly those axes (and not, e.g., all of them as in the q=4 engine).

Because mu1/mu2 enter the leaf residual linearly and (Λ, D) are held fixed while profiling beta, the profile step is an EXACT single Newton step (not an iterative/alternating scheme) — see `_q2_profile_and_schur`.

Returns `(; β, Λ, residual_cov, σ_res, rho12, reml_loglik, ml_loglik, loglik, converged, iterations, u_hat)`, mirroring `fit_coevolution_q2_residual`'s field names (`loglik` is set to `reml_loglik`, matching the q=4 REML fitter's convention in `_fit_bivariate_q4_structured`).

**Normalisation convention (#477)**

Like `reml_q4.jl`'s `fit_q4_reml`, `reml_loglik` here reports the **normalised** Patterson–Thompson restricted log-likelihood: the raw objective `ml_ll - 0.5*logdet(S)` plus the `(n_β/2)·log(2π)` that lme4/glmmTMB/TMB add when integrating the flat prior over the marginalised fixed effects. Here `n_β = length(β̂)` (`beta_mu1` + `beta_mu2`; `beta_sigma1`/`beta_sigma2`/ `beta_rho12` stay outer and are never marginalised, and `rho12` comes from `D̂` rather than from `β̂`, so it is correctly not counted).

**Changed 2026-08-25 (#477)**, together with the q=4 route — see `fit_q4_reml`'s docstring for the derivation and the evidence. Note this route has **no parity fixture of its own**: it is verified only by sharing the q=4 route's arithmetic, which the q=4 gate confirmed by tightening from 5.5436 to 0.03. A q=2 REML parity fixture would be the way to check it directly.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/reml_q2.jl#L216-L252" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fit_coevolution_q2_residual' href='#DRM.fit_coevolution_q2_residual'><span class="jlbinding">DRM.fit_coevolution_q2_residual</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fit_coevolution_q2_residual(prob, Q_cond; ...) -> NamedTuple
```


Fit the q=2 phylogenetic coevolution model with a bivariate residual covariance. This is the same target as drmTMB's bivariate Gaussian q2 location route: two phylogenetic random-effect axes (`mu1`, `mu2`) plus residual `rho12`. It is ML-only and complete-response only at the caller level.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L397-L404" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fit_phylo_interaction' href='#DRM.fit_phylo_interaction'><span class="jlbinding">DRM.fit_phylo_interaction</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fit_phylo_interaction(y, X, C_A, C_B; pμ = size(X, 2),
                      munames = ["(Intercept)"], group = :interaction,
                      g_tol = 1e-8) -> DrmFit
```


Fit the Gaussian bipartite two-tree interaction model by maximum likelihood. `C_A` (n_A×n_A) and `C_B` (n_B×n_B) are the host/parasite phylo correlation matrices; observations are in Kronecker order (cell `(a, b)` at row `(a−1)·n_B + b`), so `length(y) == n_A·n_B`. Returns a [`DrmFit`](/reference/model-fitting-and-postfit#DRM.DrmFit) whose `loglik` is the marginal log-likelihood; the interaction SD σ and the residual SD σ_e are recovered via `re_sd(fit)[group]`and`exp(coef(fit, :sigma)[1])`.

A dense n×n covariance is assembled and factored each evaluation — O(n³), intended for modest n.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/phylo_interaction.jl#L64-L78" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.lc_len' href='#DRM.lc_len'><span class="jlbinding">DRM.lc_len</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Number of free log-Cholesky parameters for a q×q covariance: q(q+1)/2.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L45" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.lc_metric' href='#DRM.lc_metric'><span class="jlbinding">DRM.lc_metric</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
lc_metric(prob, Q_cond, θ, u0; h=1e-5) -> Matrix{Float64}
```


Observed-information (Fisher-scoring) metric on the 10 log-Cholesky parameters of the q=4 among-axis covariance Λ.

Builds a 10×10 Hessian of the marginal NLL w.r.t. `θ[8:17]` by central finite-differences of the exact lc-gradient from `marginal_and_exact_grad`, symmetrises, and ridge-projects to SPD so the metric is usable as a preconditioner / natural-gradient operator (AI-REML / Fisher scoring).

**Notes**
- Infrastructure for REML / non-Gaussian RE gradient work (#11 / #165) — **not** a public ML solver. The natural-gradient EM that used this metric failed the #13 MLE-parity gate against `fit_q4_sparse_tmb` (see `docs/dev-log/plans/2026-08-01-natgrad-decision-gate.md`).
  
- Cost: 20 exact-gradient evaluations per call (warm-started from `u0`).
  


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/lc_metric.jl#L15-L32" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.make_coevo_problem' href='#DRM.make_coevo_problem'><span class="jlbinding">DRM.make_coevo_problem</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
make_coevo_problem(phy, Y, X; species) -> (prob::CoevoProblem, Q_cond)
```


Build a [`CoevoProblem`](/reference/model-fitting-and-postfit#DRM.CoevoProblem) and the root-conditioned sparse tree precision `Q_cond` (q-agnostic; the SAME object the q=4 engine consumes). `species[i]` maps data row `i` to a tip `1:phy.n_leaves`; default one row per tip.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L104-L110" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.make_coevo_problem_from_covariance' href='#DRM.make_coevo_problem_from_covariance'><span class="jlbinding">DRM.make_coevo_problem_from_covariance</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
make_coevo_problem_from_covariance(K, Y, X; group) -> (prob, Q)
```


Build a [`CoevoProblem`](/reference/model-fitting-and-postfit#DRM.CoevoProblem) from a known structured covariance/relatedness matrix over observed levels. The returned precision is `K^-1`, kept sparse for the shared exact-Gaussian coevolution fitter.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L149-L155" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.make_coevo_problem_from_precision' href='#DRM.make_coevo_problem_from_precision'><span class="jlbinding">DRM.make_coevo_problem_from_precision</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
make_coevo_problem_from_precision(Q, Y, X; group) -> (prob, Q)
```


Build a [`CoevoProblem`](/reference/model-fitting-and-postfit#DRM.CoevoProblem) from a known structured precision matrix over observed levels rather than from an augmented phylogeny. `group[i]` maps row `i` to a 1-based level in `Q`. This is the direct exact-Gaussian q2/q route for known relatedness/covariance fixtures such as relmat and animal matrices.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L123-L130" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.phylo_interaction_nll' href='#DRM.phylo_interaction_nll'><span class="jlbinding">DRM.phylo_interaction_nll</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
phylo_interaction_nll(θ, y, X, CAB; pμ) -> Real
```


Marginal negative log-likelihood of the bipartite two-tree interaction model at parameters `θ = [βμ(pμ); log σ_e; log σ]`, with `CAB = C_A ⊗ C_B` (the dense n×n interaction correlation) precomputed. The marginal is exactly Gaussian: `V = σ²·CAB + σ_e²·I`. A non-PD step returns a large finite penalty (so a line-search probe never throws / returns Inf). AD-safe (`eltype(θ)` generic).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/phylo_interaction.jl#L36-L44" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.simulate_coevolution' href='#DRM.simulate_coevolution'><span class="jlbinding">DRM.simulate_coevolution</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
simulate_coevolution(phy, β, Λ, σ_res; nrep, rng) -> (; Y, X, species)
```


Simulate `nrep` observations per tip from the general-q coevolution model on `phy`: tip random effects `vec(B) ~ N(0, Q_cond⁻¹ ⊗ Λ)` drawn via the sparse Cholesky, plus `Xβ` and `N(0, diag(σ_res²))` residuals. `β` is `k × q`. `X = [1  x]` with a single standard-normal covariate (k = 2).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/coevolution_q.jl#L482-L489" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Bridge and mixed-family payload helpers {#Bridge-and-mixed-family-payload-helpers}
<details class='jldocstring custom-block' open>
<summary><a id='DRM._bridge_dpars' href='#DRM._bridge_dpars'><span class="jlbinding">DRM._bridge_dpars</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_bridge_dpars(fit)
```


Per-observation distributional parameters on the **response** scale, keyed by drmTMB dpar name (`"mu"`, `"sigma"`, …).

This is what drmTMB's post-fit surface actually consumes. `fitted_distribution()` — the hub for `qq_plot()`, `worm_plot()`, `centile_chart()` and `exceedance()` — builds its `d`/`p`/`q` closures from `fitted_distribution_params()`, which calls `predict_parameters(object, dpar = <all dpars>, type = "response")` and needs one column per dpar. The R side supplies the density machinery from its own family tables; the only thing it cannot derive is the fitted parameter values.

Covers the in-sample case (R's `newdata = NULL`). Fresh-data prediction goes through `predict_parameters(fit, newdata)`, which is a separate payload.

**A dpar is not `fitted()`.** For a mixture family the two differ, and feeding the wrong one produces a wrong density _silently_ because both are in range. drmTMB's `mu` dpar for `zero_one_beta` is the **interior beta component** mean `plogis(eta_mu)`, which it feeds to `drm_beta_shapes(mu, sigma)`; DRM.jl stores that as `beta_mu` and puts the _unconditional_ mean `(1 - zoi) * mu + zoi * coi` — the right answer for `fitted()` — in `means[:mu]`. The override below repairs that one family.

Checked against drmTMB's full dpar table (`R/family-dpq.R`): every other family DRM.jl implements already agrees, including truncated NB2, whose `means[:mu]` is the **untruncated** mean and so is already the correct dpar. DRM.jl has no zi/hurdle families, the other place this trap lives.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/bridge.jl#L1069-L1097" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._bridge_dpars_newdata' href='#DRM._bridge_dpars_newdata'><span class="jlbinding">DRM._bridge_dpars_newdata</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_bridge_dpars_newdata(fit, newdata)
```


Distributional parameters on the **response** scale for fresh rows.

R's `predict_parameters(object, newdata = ..., type = "response")` is what `fitted_distribution(object, newdata = ...)` calls, and the `julia-engine` vignette records the gap this closes: _fresh-data Julia prediction is currently limited to location parameters_.

Unlike the in-sample block this reads the FORMULA rather than the stored `means`/`scales`, so each parameter comes back as its own linear predictor pushed through its link — which is already the dpar drmTMB wants (for `zero_one_beta`, `mu` here is `plogis(eta_mu)`, the interior beta mean, with no override needed).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/bridge.jl#L1175-L1190" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._bridge_meta_parts' href='#DRM._bridge_meta_parts'><span class="jlbinding">DRM._bridge_meta_parts</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_bridge_meta_parts(fit)
```


For a meta-analysis fit (`meta_V(v)` on `mu`), the between-study heterogeneity `tau` and the known sampling variances `V_known`; `nothing` otherwise.

**Why this is a recovery rather than a stored field.** `gaussian_meta.jl` stores `scales[:sigma] = sqrt(V + tau^2)` — the TOTAL per-study SD, which is what `simulate()` needs. But drmTMB's meta `sigma` dpar is the heterogeneity ALONE, with `V_known` supplied separately and the density forming `sqrt(V_known + sigma^2)` itself. Emitting the total as `sigma` _and_ a `V_known` would double-count the sampling variance.

Both are recoverable exactly from what the fit already holds — `tau` from the sigma coefficient (already the right dpar) and `V = total^2 - tau^2`, verified to 1.1e-16 — so no field, no struct change, and no change to `sigma()`'s public contract is required.

Returns `nothing` when the sigma block carries predictors, because per-row `tau` then needs the design matrix and `DrmFit` does not retain the data. That is a declared boundary, not a silent approximation.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/bridge.jl#L1130-L1151" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._bridge_trials' href='#DRM._bridge_trials'><span class="jlbinding">DRM._bridge_trials</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_bridge_trials(fit)
```


Per-row binomial denominator, or `nothing` when the family has none.

`fitted_distribution_params()` attaches `params$trials` for the `binomial` and `beta_binomial` model types; without it the R side cannot evaluate those densities on a Julia fit.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/bridge.jl#L1118-L1126" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.drm_bridge_q2_known_precision' href='#DRM.drm_bridge_q2_known_precision'><span class="jlbinding">DRM.drm_bridge_q2_known_precision</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
drm_bridge_q2_known_precision(; Y, X, group, Q,
                              structured_type = "relmat",
                              precision_source = nothing,
                              options = Dict())
```


Private diagnostic boundary for a restricted q2 known-precision provider payload. This consumes `Q` as a precision matrix directly through `make_coevo_problem_from_precision`; it does not invert or relabel `Q` as a covariance matrix, and it does not imply formula, slope, REML, or interval support. Provider identity is deliberately narrow: `structured_type = "relmat"` records `precision_source = "Q"`, while `structured_type = "animal"` records `precision_source = "Ainv"`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/bridge.jl#L95-L108" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.drm_bridge_q2_phylo' href='#DRM.drm_bridge_q2_phylo'><span class="jlbinding">DRM.drm_bridge_q2_phylo</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
drm_bridge_q2_phylo(; Y, X, species, tree, options = Dict())
```


Private diagnostic boundary for the restricted q2 phylogenetic coevolution point export. This intentionally bypasses the public formula bridge because the general-q coevolution model is diagonal-residual Gaussian evidence, not the full bivariate `rho12` q2 route. The return payload is the same primitive dictionary shape consumed by the row-contract tests.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/bridge.jl#L60-L68" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.fit_mixed_family' href='#DRM.fit_mixed_family'><span class="jlbinding">DRM.fit_mixed_family</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
fit_mixed_family(; y1, X1, fam1, y2, X2, fam2,
                   trials1=ones(n), trials2=ones(n),
                   Xsigma1=ones(n,1), Xsigma2=ones(n,1), K=32, g_tol=1e-6)
```


Fit the cross-family bivariate model (shared per-observation latent) and return a `NamedTuple` with fixed effects `β1`/`β2`, loadings `λ1`/`λ2`, per-axis scale `σ1`/`σ2` (`NaN` for dispersionless axes), dispersion sub-model coefficients `βσ1`/`βσ2` (`log σ` scale, empty for dispersionless axes), link-scale variances `v1`/`v2`, the latent-scale correlation `rho_latent`, `loglik`, `converged`, `iterations`, and the two family instances `fam1`/`fam2` (carried so the post-fit accessors in `mixed_family_postfit.jl` can recover each axis's inverse link).

`fam1`/`fam2` are DRM family instances. Supported: `Gaussian`, `Poisson`, `Binomial`, `NegBinomial2`, `Beta`, `Gamma`. Dispersion-carrying families (Gaussian/Beta/Gamma/NB2) all carry the scale `σ` in a per-observation `log σ` SUB-MODEL `log σ_{k,i} = (Xσ_k · β_σk)_i` with `size(Xσ_k, 2)` coefficients; `Poisson`/`Binomial` are dispersionless. Each family maps σ to its own dispersion (Beta φ = 1/σ², Gamma α = 1/σ², NB2 size θ = 1/σ²), matching the univariate fitters and `drmTMB` (#315/#316). `Xsigma1`/`Xsigma2` default to a single intercept column (`ones(n,1)`), reproducing the intercept-only scalar dispersion. For dispersion-carrying families `σ1`/`σ2` returns a representative scale `exp(mean_i log σ_{k,i})` (recover the NB2 size as `θ = 1/σ1²`); the full sub-model is in `βσ1`/`βσ2`. `trials*` are Binomial denominators (ignored otherwise).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/mixed_family.jl#L149-L173" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._mf_nparams' href='#DRM._mf_nparams'><span class="jlbinding">DRM._mf_nparams</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_mf_nparams(fit) -> Int
```


Number of free parameters in a `fit_mixed_family` fit: the two fixed-effect blocks `β1`/`β2`, the two latent loadings `λ1`/`λ2`, and the two dispersion sub-model blocks `βσ1`/`βσ2` (empty for dispersionless axes). This equals the length of the internal `θ` vector the optimiser minimised.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/mixed_family_postfit.jl#L10-L17" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Location-scale and structured-fit kernels {#Location-scale-and-structured-fit-kernels}
<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_bivariate_q4_structured' href='#DRM._fit_bivariate_q4_structured'><span class="jlbinding">DRM._fit_bivariate_q4_structured</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_bivariate_q4_structured(...)
```


q=4 PLSM front end for level-indexed structured providers (`relmat` / `animal` / `spatial`) — issue #189. Reuses [`fit_q4_sparse_tmb`](/reference/model-fitting-and-postfit#fit_q4_sparse_tmb) via [`make_problem_from_Q`](/reference/engine-internals#DRM.make_problem_from_Q); does not rewrite the verified Laplace engine.

Spatial uses a fixed range (`spatial_range`, default = mean pairwise distance). Non-tree `bootstrap_sigma_a` is deliberately unsupported.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_bivariate.jl#L669-L678" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_corr_locscale' href='#DRM._fit_corr_locscale'><span class="jlbinding">DRM._fit_corr_locscale</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_corr_locscale(fam, kind, rk, y, Xμ, Xψ, xs, gidx, G, nmμ, nmσ, grp;
                   link, se, g_tol, respobs, trials, Q)
```


Fit a correlated (`rk == :corr`) or independent (`rk == :slope`) random intercept/slope on the mean of a non-Gaussian family through the unified q2 location–scale Laplace core, and wrap it as a `DrmFit` with the GHQ `:recov` block. `Xψ` is the scale fixed-effect design (`zeros(n,0)` for the mean-only Poisson). `link` is the mean inverse link (`:log`/`:logit`/`:identity`). `Q` is the G×G group-level precision; default `sparse(I,G,G)` (i.i.d. groups, cluster 1 byte-identical behaviour). A structured Q (from `_general_cov_setup` or `_locscale_phylo_setup`) routes the kron(Q,Λ⁻¹) prior through the same spine (cluster 3: structured non-Gaussian random slopes).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/locscale_corr.jl#L87-L100" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_fixed_gaussian_reml' href='#DRM._fit_fixed_gaussian_reml'><span class="jlbinding">DRM._fit_fixed_gaussian_reml</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_fixed_gaussian_reml(fam, y, Xμ, Xσ, nmμ, nmσ, g_tol) -> DrmFit
```


REML fit of the fixed-effect Gaussian location–scale model. Profiles out β_μ by weighted least squares and optimises the restricted log-likelihood over β_σ; β̂_μ is recovered as the final WLS estimate. The returned `DrmFit` carries `estim_method = :REML`,`reml_loglik`, and`ml_loglik`(the plain ML log-lik at the REML parameters, for reference). Internal — reached via`drm(...; method = :REML)`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_core.jl#L1066-L1074" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_gaussian_locscale_phylo' href='#DRM._fit_gaussian_locscale_phylo'><span class="jlbinding">DRM._fit_gaussian_locscale_phylo</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_gaussian_locscale_phylo(fam, y, Xμ, Xψ, gidx, G, Q, nmμ, nmσ, grp;
                              coupled, asymmetric, se, g_tol) -> DrmFit
```


Fit a UNIVARIATE Gaussian location-scale model with a phylogenetic random effect on BOTH axes (by default SEPARATE / uncorrelated) or on the σ axis only (asymmetric).

Modes controlled by kwargs:
- `coupled = false` (default): SEPARATE block Λ = diag(L11², L22²), L21 ≡ 0. Returns DrmFit with `:mu`, `:sigma`, `:resd_mu` (logL11), `:resd_sigma` (logL22).
  
- `coupled = true`: FREE L21, full 2×2 Λ with mean↔σ correlation. Returns DrmFit with `:mu`, `:sigma`, `:recov` (logL11, logL22, L21).
  
- `asymmetric = true`: σ-phylo only (mean fixed effects, no mean phylo RE). Returns DrmFit with `:mu`, `:sigma`, `:resd_sigma` (logL22).
  

The kernel is `Val(:gaussian_mean)`: η = mean, ψ = log σ, integrating the Gaussian location-scale likelihood through the q=2 augmented-state Laplace spine.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_locscale_phylo.jl#L579-L597" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_locscale' href='#DRM._fit_locscale'><span class="jlbinding">DRM._fit_locscale</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_locscale(kind, y, Xμ, Xψ, gidx, G, Q; ...)
```


Fit the q=2 non-Gaussian location–scale model. Returns a named tuple with the packed estimate `θ`, the fixed effects `beta_mu` / `beta_psi`, the 2×2 group-level covariance `Lambda`, the marginal `nll`, and a `converged` flag.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/locscale_fit.jl#L75-L81" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_ranef_gaussian' href='#DRM._fit_ranef_gaussian'><span class="jlbinding">DRM._fit_ranef_gaussian</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_ranef_gaussian(..., reml=false) -> DrmFit
```


Gaussian location–scale with one mean random intercept `(1 | g)` on the Woodbury spine. `reml=false` (default) is ML, byte-for-byte with the historical nll. `reml=true` (#439) adds `½ logdet(Xμ′ V⁻¹ Xμ) − ½ pμ log(2π)` to that nll (Patterson–Thompson). Reached via `drm(...; method = :REML)` for a single intercept only — σ-RE, slopes, and multi-ranef stay rejected. Worked example: `test/test_reml_ordinary_ranef.jl` (not in the default suite yet).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_ranef.jl#L103-L112" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_sigma_axis_re' href='#DRM._fit_sigma_axis_re'><span class="jlbinding">DRM._fit_sigma_axis_re</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_sigma_axis_re(fam, kind, y, Xμ, Xψ, gidx, G, nmμ, nmσ, grp; link, se, g_tol,
                   obs_prop, trials)
```


Fit a standalone σ-axis random intercept `sigma ~ 1 + (1|g)` via the q=2 location–scale Laplace core. Mean is fixed-effects only (no mean RE). The latent is placed on the scale axis: `Zη = 0`, `Zψ[:,1] = 1`. Only `logL11` (= log τ) is optimized; the unused latent axis-2 is pinned to a fixed tiny variance ε = 1e-6. Returns a `DrmFit` with a `:resd` block (log τ), so `re_sd(fit)[:g_logsigma]` = τ (the `_logsigma` suffix marks this SD as living on the log-σ scale axis).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/locscale_sigma.jl#L115-L125" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._general_cov_setup' href='#DRM._general_cov_setup'><span class="jlbinding">DRM._general_cov_setup</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_general_cov_setup(C, labels) -> (Q, leaf_node)
```


Resolve a user-supplied per-group covariance/relatedness matrix `C` (G×G, SPD) to the `(precision Q, leaf_node)` pair the sparse-Laplace spine consumes. `C` is first rescaled to a unit-diagonal correlation `R` (so the recovered `:resd` block is the random-effect SD `σ_b`, with prior `b ~ N(0, σ_b² R)`, matching the phylo convention), then `Q = R⁻¹`. `leaf_node` maps each observation to its group level via [`_group_index`](/reference/engine-internals#_group_index) — the relatedness/animal-model/spatial analogue of the tree's leaf-to-node map. Mathematically identical to the phylo path with the tree precision swapped for an arbitrary PD precision.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L476-L487" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._ls_components' href='#DRM._ls_components'><span class="jlbinding">DRM._ls_components</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_ls_components(Λ) -> NamedTuple
```


Named group-level summaries of the 2×2 covariance Λ: the mean-axis SD, the scale-axis SD, and the mean↔scale correlation ρ_a.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/locscale_infer.jl#L47-L52" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._ls_marginal_grad' href='#DRM._ls_marginal_grad'><span class="jlbinding">DRM._ls_marginal_grad</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_ls_marginal_grad(kind, y, Xμ, Xψ, gidx, G, Q, θ) -> Vector
```


Exact gradient of `_ls_fit_nll` at the packed θ = [βμ; βψ; λ(3)]. Returns an all-`NaN` vector if the inner Laplace mode fails to converge (rare; this is the infeasibility signal that pairs with the `_ls_fit_nll` value sentinel — a gradient-based optimiser rejects a NaN step rather than mistaking a zero gradient for stationarity, see #314). O(p) in the number of groups.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/locscale_grad.jl#L34-L42" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._ls_marginal_nll' href='#DRM._ls_marginal_nll'><span class="jlbinding">DRM._ls_marginal_nll</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_ls_marginal_nll(kind, y, η0, ψ0, gidx, G, P; a0=nothing)
```


Laplace-approximate marginal negative log-likelihood for the q=2 location–scale model. Returns `(nll, â, ok)`: the marginal NLL, the inner mode, and a success flag (the inner Newton solve can fail at extreme parameters).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/locscale_marginal.jl#L21-L27" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._ls_obs_information' href='#DRM._ls_obs_information'><span class="jlbinding">DRM._ls_obs_information</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_ls_obs_information(kind, y, Xμ, Xψ, gidx, G, Q, θ; h=1e-5) -> Symmetric
```


Observed information ∂²M/∂θ² of the Laplace marginal at θ, as the symmetrised central finite-difference Jacobian of the exact gradient `_ls_marginal_grad`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/locscale_infer.jl#L10-L15" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._ls_profile_ci' href='#DRM._ls_profile_ci'><span class="jlbinding">DRM._ls_profile_ci</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_ls_profile_ci(kind, y, Xμ, Xψ, gidx, G, Q, θ̂; idx, level=0.95, nll_min=nothing,
               se=nothing) -> (lower, upper)
```


Profile-likelihood CI for packed parameter `idx`, inverting `2(ℓ̂ − ℓ_profile) = χ²₁(level)` by a Venzon–Moolgavkar-style guarded-Newton root-find (the profile deviance and its envelope-theorem slope, bracket-safeguarded). Endpoints are `±Inf` when the profile does not cross the χ²₁ threshold (an unbounded direction) or when the constrained solve becomes infeasible before a crossing (a variance/ correlation boundary). `se` (a Wald SE for `idx`) seeds the bracket width; if omitted it is derived from the observed information.

`Zη`/`Zψ` are the mean/scale latent loadings and MUST match the model that was fit: the profiler reconstructs the marginal from `(kind, y, Xμ, Xψ, gidx, G, Q)` plus these loadings, so passing the wrong loadings profiles a different model (#325.4). They default to the canonical loadings (`Zη=[1 0]`, `Zψ=[0 1]`) — the only case wired through `LocScaleObjective` today; a non-canonical (slope-axis) fit must pass its own `Zη`/`Zψ` here for the CI to be correct.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/locscale_profile.jl#L131-L149" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._phylo_mean_laplace_hetero_fg' href='#DRM._phylo_mean_laplace_hetero_fg'><span class="jlbinding">DRM._phylo_mean_laplace_hetero_fg</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_phylo_mean_laplace_hetero_fg(kind, aux_from, n, Xμ, Xσ, leaf_node, Q, logdetQ, θ; …)
```


Heteroscedastic generalisation of `_phylo_mean_laplace_nuisance_fg` (#164): the single scalar dispersion nuisance θσ is replaced by a per-observation log-dispersion linear predictor `ησ = Xσ·βσ`, so θ = `[βμ(pμ); βσ(pσ); logσ]`. `aux_from(ησ::Vector)` returns a per-observation aux whose dispersion is `exp.(ησ)` (a vector kind, e.g. `Val(:nb2_hetero)`).

The σ-axis kernel derivatives (`nval, nr, nw`) are taken w.r.t. each observation's `log r_i`, so the βσ gradient is the Xσ-chained version of the scalar nuisance gradient: where the scalar code accumulates one `gnuis`, this accumulates a `pσ`-vector `gν` with each per-observation contribution weighted by `Xσ[i, k]`, and the implicit cross-term `crossν` becomes a `q × pσ` matrix — structurally identical to how the mean axis already chains `r/w` through `Xμ`. A one-column constant `Xσ` reproduces `_phylo_mean_laplace_nuisance_fg` exactly.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L884-L900" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._phylo_mean_leaf_index' href='#DRM._phylo_mean_leaf_index'><span class="jlbinding">DRM._phylo_mean_leaf_index</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_phylo_mean_leaf_index(phy::AugmentedPhy, labels) -> Vector{Int}
```


Map per-row group `labels` to the tree's raw leaf index (`1:phy.n_leaves`) — the convention `make_loc_problem`'s `species=` keyword expects. Mirrors the three-tier match `_poisson_phylo_setup` already uses for the Laplace phylo routes, most to least specific:
1. leaf NAME (`phy.leaf_names`) — subset-tolerant: `labels` may name only SOME of the tree's leaves (e.g. after a caller drops missing-response rows upstream — #482). A leaf that never appears in `labels` simply gets no observation and stays in the phylo PRIOR only, exactly like the σ-phylo route's documented "species whose every row is missing stays in the prior with no likelihood term" (`gaussian_core.jl`, the σ-phylo missing-response block).
  
2. integer tip index `1:phy.n_leaves`.
  
3. positional (`_group_index`, first-seen order) — the only tier with no name information to anchor to, so it requires `labels` to visit every tip exactly once (`G == phy.n_leaves`); this is the pre-#482 behaviour, kept as a last-resort fallback.
  

Throws an `ArgumentError` naming the mismatch if none of the three tiers apply (e.g. group labels that are neither tree tip names nor valid integer indices, and do not even form a complete one-level-per-tip bijection).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/location_only.jl#L113-L137" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._reml_normalise' href='#DRM._reml_normalise'><span class="jlbinding">DRM._reml_normalise</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_reml_normalise(reml_ll, n_beta)
```


Add the `(n_beta/2)·log(2π)` normalising constant to an unnormalised Patterson–Thompson restricted log-likelihood, so DRM.jl's bivariate REML routes report on the same scale as lme4, glmmTMB, TMB — and as DRM.jl's own univariate REML routes, which have always added it (#477).

`n_beta` counts only the **marginalised** fixed effects. Non-finite input passes through unchanged so `-Inf` barriers and `NaN` sentinels keep their meaning.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/reml_q4.jl#L291-L301" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._vcov_from_hessian' href='#DRM._vcov_from_hessian'><span class="jlbinding">DRM._vcov_from_hessian</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_vcov_from_hessian(H; context = "")
```


Covariance matrix from an observed-information (Hessian) matrix, guarded against boundary degeneracy.

Symmetrises `H`, then inverts it — unless it is numerically singular, in which case it falls back to the Moore–Penrose pseudo-inverse **and warns**, naming the parameter coordinates that are flat. The decision is made from the eigenvalues rather than from whether `inv` happens to throw, so the result does not depend on the LAPACK build or CPU.

The pseudo-inverse keeps a fit usable, but standard errors for the flagged coordinates are not trustworthy: at a variance boundary the sampling distribution is not the usual normal approximation. Use `method = :profile` or the bootstrap entry points for those targets (see `src/inference.jl`), or the χ̄² boundary machinery in `src/chibar.jl`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/vcov_guard.jl#L57-L74" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.q2_reml_phi_len' href='#DRM.q2_reml_phi_len'><span class="jlbinding">DRM.q2_reml_phi_len</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



Length of the q=2 REML outer parameter vector `phi = (lc(Λ), logσ1, logσ2, ηρ)`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/reml_q2.jl#L60" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Non-Gaussian sparse-Laplace kernels {#Non-Gaussian-sparse-Laplace-kernels}
<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_beta_relmat_laplace' href='#DRM._fit_beta_relmat_laplace'><span class="jlbinding">DRM._fit_beta_relmat_laplace</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_beta_relmat_laplace(fam, y, Xμ, Xσ, C, labels, nmμ, nmσ, grp, g_tol; se)
```


Beta sparse-Laplace fit with a general user-supplied PD covariance `C` on the mean (logit) random intercept (`relmat`/`animal`/`spatial(1 | grp)`), with the precision `φ` (via the `sigma` slot, σ = 1/√φ) a fixed nuisance parameter. Reuses the verified phylo nuisance spine via [`_general_cov_setup`](/reference/engine-internals#DRM._general_cov_setup); only the prior precision differs (`C⁻¹` vs the tree topology). Exact O(p) gradient carries over (#167).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L1454-L1462" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_betabinomial_crossed_laplace' href='#DRM._fit_betabinomial_crossed_laplace'><span class="jlbinding">DRM._fit_betabinomial_crossed_laplace</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_betabinomial_crossed_laplace(fam, s, ntr, Xμ, comps, nmμ, nmσ, g_tol; se)
```


Beta-binomial sparse-Laplace fit with two crossed random intercepts on the logit mean, e.g. `(1 | g) + (1 | h)`, constant-σ (overdispersion) only. Reuses the verified Beta-family crossed nuisance Laplace spine ([`_fit_crossed_mean_laplace_nuisance`](/reference/engine-internals#_fit_crossed_mean_laplace_nuisance)) with the `:betabinomial_fixed` kernel (#166; see `docs/dev-log/plans/2026-08-02-166-betabinomial-kernel-design.md`).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L3145-L3154" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_betabinomial_phylo_laplace' href='#DRM._fit_betabinomial_phylo_laplace'><span class="jlbinding">DRM._fit_betabinomial_phylo_laplace</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_betabinomial_phylo_laplace(fam, s, ntr, Xμ, labels, tree, nmμ, nmσ, grp, g_tol; se)
```


Beta-binomial sparse-Laplace fit with a phylogenetic random intercept `phylo(1 | grp)` on the logit mean, constant-σ (overdispersion) only. Reuses the verified Beta-family nuisance Laplace spine ([`_fit_phylo_mean_laplace_nuisance`](/reference/engine-internals#_fit_phylo_mean_laplace_nuisance)) with the `:betabinomial_fixed` kernel — shifted digamma/trigamma/polygamma arguments (`s+a`, `n-s+b`, `n+a+b`) replace Beta's `(a, b)` (#166; see `docs/dev-log/plans/2026-08-02-166-betabinomial-kernel-design.md`).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L1501-L1511" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_gamma_relmat_laplace' href='#DRM._fit_gamma_relmat_laplace'><span class="jlbinding">DRM._fit_gamma_relmat_laplace</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_gamma_relmat_laplace(fam, y, Xμ, Xσ, C, labels, nmμ, nmσ, grp, g_tol; se)
```


Gamma sparse-Laplace fit with a general user-supplied PD covariance `C` on the mean random intercept (`relmat`/`animal`/`spatial(1 | grp)`), with the shape `α` (via the `sigma` slot, σ = 1/√α) a fixed nuisance parameter. Reuses the verified phylo nuisance spine via [`_general_cov_setup`](/reference/engine-internals#DRM._general_cov_setup); only the prior precision differs (`C⁻¹` vs the tree topology). Exact O(p) gradient carries over (#167).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L1373-L1381" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_nb2_relmat_laplace' href='#DRM._fit_nb2_relmat_laplace'><span class="jlbinding">DRM._fit_nb2_relmat_laplace</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_nb2_relmat_laplace(fam, y, Xμ, Xσ, C, labels, nmμ, nmσ, grp, g_tol; se)
```


NB2 sparse-Laplace fit with a general user-supplied PD covariance `C` on the mean random intercept (`relmat`/`animal`/`spatial(1 | grp)`), with the dispersion `θ` (the `sigma` slot) a fixed nuisance parameter. Reuses the verified phylo nuisance spine via [`_general_cov_setup`](/reference/engine-internals#DRM._general_cov_setup): the only difference from the phylo route is that the prior precision comes from `C⁻¹` instead of the tree topology. Exact O(p) gradient and Takahashi log-det derivatives carry over unchanged (#167).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L1276-L1285" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_poisson_crossed_laplace' href='#DRM._fit_poisson_crossed_laplace'><span class="jlbinding">DRM._fit_poisson_crossed_laplace</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_poisson_crossed_laplace(fam, y, Xμ, comps, nmμ, g_tol)
```


Internal engine-lane fitter for Poisson random-intercept GLMMs with one or more independent scalar random-effect components. `comps` is a vector of `(w, gidx, G, label)` tuples, matching the Gaussian multi-RE fitter.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L1830-L1836" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_poisson_phylo_laplace' href='#DRM._fit_poisson_phylo_laplace'><span class="jlbinding">DRM._fit_poisson_phylo_laplace</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_poisson_phylo_laplace(fam, y, Xμ, labels, tree, nmμ, grp, g_tol)
```


Internal sparse-Laplace fitter for `Poisson()` with a phylogenetic random intercept `phylo(1 | grp)` on the mean. The tree is represented by the root-conditioned augmented precision, so the latent state has one effect per non-root tree node and the mode/logdet computations stay sparse.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L458-L465" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_poisson_relmat_laplace' href='#DRM._fit_poisson_relmat_laplace'><span class="jlbinding">DRM._fit_poisson_relmat_laplace</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_poisson_relmat_laplace(fam, y, Xμ, C, labels, nmμ, grp, g_tol; se)
```


Poisson sparse-Laplace fit with a general user-supplied PD covariance `C` on the mean random intercept (`relmat`/`animal`/`spatial(1 | grp)`). Reuses the verified phylo Laplace spine via [`_general_cov_setup`](/reference/engine-internals#DRM._general_cov_setup): the only difference from the phylo route is that the prior precision comes from `C⁻¹` instead of the tree topology. Exact O(p) gradient and Takahashi log-det derivatives carry over unchanged.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L502-L511" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._fit_poisson_spatial_coord' href='#DRM._fit_poisson_spatial_coord'><span class="jlbinding">DRM._fit_poisson_spatial_coord</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_fit_poisson_spatial_coord(fam, y, Xμ, labels, coords, nmμ, grp, g_tol; se)
```


Poisson `spatial(1 | grp)` fit with a coordinate-based exponential-kernel spatial covariance `C(ρ) = exp(-d/ρ)` and the range `ρ` **estimated jointly** (#270). The site coordinates (`coords`, a `G×2` matrix, one row per group level in first-seen order) give the pairwise distances `d`; the random intercept is `b ~ N(0, σ_b² C(ρ))` on `log λ`. The outer parameter vector is `θ = [β_μ; log σ_b; log ρ]`, so `ρ` is a genuine hyperparameter whose gradient flows through `C(ρ)` into the Laplace marginal — not a fixed-range or profile-over-grid approximation.

The marginal is the Poisson Laplace approximation (same convention as the verified sparse general-covariance path), written in AD-traceable operations so ForwardDiff supplies the exact outer gradient and the covariance Hessian. Recovered blocks: `:mu` (fixed effects), `:resd` (`log σ_b`), `:range` (`log ρ`).

::: tip Note

The range `ρ` is only weakly identified from a single spatial realization; `:resd` (the spatial SD) and the fixed effects are the robustly recoverable pieces. For a precomputed spatial covariance, use `spatial(1 | grp)` with `K = …` instead (the verified O(p) sparse path).

:::


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/poisson.jl#L603-L624" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._poisson_crossed_laplace_fg' href='#DRM._poisson_crossed_laplace_fg'><span class="jlbinding">DRM._poisson_crossed_laplace_fg</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_poisson_crossed_laplace_fg(y, Xμ, gidx, G, hidx, Hh, lf, θ; grad, b0, newton_tol, newton_maxiter)
```


Module-level f/g evaluation of the Poisson crossed-random-intercepts Laplace marginal NLL at a single θ, used both by `_fit_poisson_crossed_intercepts_laplace` and by the standing FD-vs-analytic gradient gate (#165). Hoisting it out of the fit closure lets the gate drive a _controlled, tightly-converged, warm-started_ inner mode (the same recipe the q4 Q-gate / the Poisson-phylo gate use to reach ≤ 1e-6). Returns `(val[, grad], b, ok)`; on a non-PD inner solve `ok = false`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L1677-L1686" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM._poisson_phylo_laplace_fg' href='#DRM._poisson_phylo_laplace_fg'><span class="jlbinding">DRM._poisson_phylo_laplace_fg</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
_poisson_phylo_laplace_fg(y, Xμ, leaf_node, Q, logdetQ, lf, θ; grad, b0, newton_tol, newton_maxiter)
```


Module-level f/g evaluation of the Poisson phylogenetic-Laplace marginal NLL at a single θ, used both by `_fit_poisson_phylo_laplace` and by the standing FD-vs-analytic gradient gate (#165). Hoisting it out of the fit closure lets the gate drive a _controlled, tightly-converged, warm-started_ inner mode (the same recipe `marginal_and_exact_grad` / the q4 Q-gate use to reach ≤ 1e-6).

The marginal is

```
L(θ) = data(b̂) + ½ σ⁻² b̂'Q b̂ + q logσ − ½ logdet Q + ½ logdet H,
H = σ⁻² Q + diag(Σ_{i∈leaf} μ_i).
```


Because b̂ solves ∂(data+prior)/∂b = 0, the total θ-gradient is the explicit part (b̂ frozen) plus the implicit logdet correction through db̂/dθ = −H⁻¹ ∂²(data+prior)/∂b∂θ. For Poisson the data Hessian weight and its η-derivative coincide (d²ℓ = d³ℓ = μ), so a single μ drives both the logdet trace and the cross term — this is the family-specific third-derivative term the IFT introduces. Returns `(val[, grad], b, ok)`; on a non-PD inner solve `ok = false`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/sparse_laplace_glmm.jl#L362-L382" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Helpers referenced by source docstrings {#Helpers-referenced-by-source-docstrings}

These nonpublic helpers have no source docstrings; the descriptions below keep references from the documented kernels navigable without creating new APIs.

### _group_index {#_group_index}

Maps observation labels to integer group indices in first-seen order and returns the indices together with the number of distinct groups.

### _fit_phylo_mean_laplace_nuisance {#_fit_phylo_mean_laplace_nuisance}

Prepares a tree's root-conditioned precision and observation-to-leaf map, then delegates to the general-precision mean-effect Laplace fitter.

### _fit_crossed_mean_laplace_nuisance {#_fit_crossed_mean_laplace_nuisance}

Fits the crossed mean-effect Laplace objective for a supplied family and nuisance-parameter specification, using the prepared group indices.
