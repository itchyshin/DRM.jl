
# Model specification {#Model-specification}

::: tip Status — Reference

Mirrors drmTMB's [Model specification](https://itchyshin.github.io/drmTMB/reference/index.html) (13 items in drmTMB). A model is one [`bf`](/reference/model-specification#DRM.bf) formula bundle (one linear predictor per distributional parameter) plus a response family. All 13 drmTMB families are available.

:::

## Formula bundle {#Formula-bundle}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.bf' href='#DRM.bf'><span class="jlbinding">DRM.bf</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
bf(response_formula, dpar_formulas...)
drm_formula(response_formula, dpar_formulas...)
```


Bundle one formula per distributional parameter, exactly as drmTMB. The first formula `y ~ …` sets the response and the `μ` predictor; each later formula `param ~ …` (e.g. `sigma ~ …`) sets that parameter's predictor. `sigma` defaults to `~ 1` when omitted.

The secondary parameter on each formula's left-hand side must be one of `sigma, nu, zi, hu, zoi, coi`. Mirroring drmTMB, `bf` rejects reserved / mis-typed syntax with a clear error: `tau` (the scale is `sigma`), `mu` as a separate formula (μ comes from the response), the two-response parameters `mu1/mu2/sigma1/sigma2/rho12` in this positional form (use the keyword form), unknown parameter names, and a parameter given more than once.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_core.jl#L76-L91" target="_blank" rel="noreferrer">source</a></Badge>



```julia
bf(; mu1, mu2, sigma1=…, sigma2=…, nu=…, rho12=…)
```


Bivariate formula bundle, mirroring drmTMB. `mu1 = y1 ~ …` and `mu2 = y2 ~ …` set the two responses and their mean predictors; `sigma1`, `sigma2` (log σ) and `rho12` (atanh ρ) default to `~ 1`. For one-sided predictors give the parameter name as a placeholder LHS, e.g. `sigma1 = @formula(sigma1 ~ x)`.

`nu` is the shared degrees-of-freedom formula for the bivariate Student-t family (`drm(…, Student())`, drmTMB's `biv_student()`), on the `logm2` scale `ν = 2 + exp(η)`. It is **omitted entirely** unless supplied, so the Gaussian and lognormal bundles are unchanged. Under the exact bivariate-t density a single scalar mixing variable governs both margins, so `ν` is _structurally_ shared — there is no per-margin `nu1`/`nu2`.

Like the univariate form, `bf` rejects reserved / mis-typed syntax: a placeholder LHS that is not its own parameter name (e.g. `sigma1 = @formula(tau ~ x)` or a swapped `sigma1`/`sigma2`), and a two-column `cbind(…)` response on `mu1`/`mu2`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_bivariate.jl#L57-L76" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.DrmFormula' href='#DRM.DrmFormula'><span class="jlbinding">DRM.DrmFormula</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
DrmFormula
```


A bundle of one linear-predictor formula per distributional parameter, built by [`bf`](/reference/model-specification#DRM.bf). `response` is the response column; `forms` is ordered `:mu => rhs, :sigma => rhs, …`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_core.jl#L25-L31" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.BivariateDrmFormula' href='#DRM.BivariateDrmFormula'><span class="jlbinding">DRM.BivariateDrmFormula</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
BivariateDrmFormula
```


Two-response formula bundle (μ1, μ2, σ1, σ2, ρ12), built by the keyword form of [`bf`](/reference/model-specification#DRM.bf).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_bivariate.jl#L10-L15" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Response families {#Response-families}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.Gaussian' href='#DRM.Gaussian'><span class="jlbinding">DRM.Gaussian</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Gaussian()
```


Gaussian response family: identity link on the mean `μ`, log link on the scale `σ` (so `σ` coefficients act on `log σ`). Mirrors `drmTMB::gaussian()`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gaussian_core.jl#L17-L22" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Student' href='#DRM.Student'><span class="jlbinding">DRM.Student</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Student()
```


Student-t response family: identity link on the location `μ`, log link on the scale `σ`, and the degrees of freedom as `ν = 2 + exp(η)` (so `ν > 2` and the variance is always finite; `ν` coefficients act on `log(ν − 2)`). Note that `σ` is the scale, not the standard deviation: for `ν > 2`, `SD[y] = σ·sqrt(ν/(ν − 2))` (mirroring `drmTMB`). Robust sibling of [`Gaussian`](/reference/model-specification#DRM.Gaussian) — heavy tails downweight outliers, and `ν → ∞` tends to Gaussian. Mirrors `drmTMB`'s `student` family.

```julia
fit = drm(bf(y ~ x, sigma ~ 1, nu ~ 1), Student(); data = dat)
2 + exp(coef(fit, :nu)[1])  # estimated degrees of freedom (ν = 2 + exp(η))
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/student.jl#L11-L25" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Poisson' href='#DRM.Poisson'><span class="jlbinding">DRM.Poisson</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Poisson()
```


Poisson response family for counts: log link on the mean `μ` (so `μ` coefficients act on `log λ`). No scale parameter. Mirrors `drmTMB`'s `poisson` family.

::: tip Note

`DRM.Poisson` shadows `Distributions.Poisson`; if you need the distribution too (e.g. to simulate), qualify it as `Distributions.Poisson`.

:::

```julia
fit = drm(bf(y ~ x), Poisson(); data = dat)
fitted(fit)        # fitted counts λ = exp(Xβ̂), on the response scale

fit_phy = drm(bf(@formula(y ~ x + phylo(1 | species))), Poisson();
              data = dat, tree = tr, se = false)

# Experimental (#136 Arc 0): Poisson random-intercept variational (ELBO) marginal.
# Default remains Laplace (`marginal = :LA`). `loglik` on a VA fit is an ELBO.
fit_va = drm(bf(@formula(y ~ x + (1 | g))), Poisson(); data = dat, marginal = :VA)

# Opt-in Cox–Reid restricted estimation (#443 / #450). ML is the default.
fit_reml = drm(bf(@formula(y ~ x + (1 | g))), Poisson(); data = dat, method = :REML)
estimation_method(fit_reml)   # :REML

# Opt-in 1-D Liu–Pierce AGHQ for `(1 | g)` only (#448). Default `:LA` stays
# today's non-adaptive GHQ-32. k=1 ≡ 1-point Laplace plumbing, not a recovery
# headline. Capability row stays missing. `:REML` is not wired to `:AGHQ`.
fit_aghq = drm(bf(@formula(y ~ x + (1 | g))), Poisson();
               data = dat, marginal = :AGHQ, nAGQ = 5)
fit_aghq.marginal   # :AGHQ

fit_phy_reml = drm(bf(@formula(y ~ x + phylo(1 | species))), Poisson();
                   data = dat, tree = tr, se = false, method = :REML)
```


**Restricted (Cox–Reid) estimation**

`method = :REML` is **opt-in — ML remains the default**. It maximises the Cox–Reid adjusted profile likelihood `ℓ_ML − ½·log|I_ββ|` on two Poisson routes:
- a scalar random intercept `(1 | g)` integrated by GHQ-32 (#443)
  
- phylogenetic / `relmat` / `animal` / precomputed-spatial Laplace (`_fit_poisson_general_laplace`, #450)
  

On the Gaussian route this correction is exactly Patterson–Thompson REML, so the mechanism is anchored rather than ad hoc.

::: warning Probe Cell D is not a recovery result

A 16-tip / 12-seed Poisson phylo cell over-corrected under Cox–Reid (ML +8.18%, CR +17.41%). Do not read those percentages as a bias-sign headline or a reason to prefer `:REML` on trees. ADEMP on a larger tree is a follow-on. Evidence: `docs/dev-log/evidence/2026-08-18-cox-reid-scoping-probe.md`.

:::

::: warning It over-corrects when clusters are plentiful

On a Poisson `(1 | g)` cell with true `σ_b = 0.6` and 6 observations per cluster, ML was **−12.4%** at `G = 10` where Cox–Reid was **−1.8%** — but by `G = 40` ML was **+1.4%** and Cox–Reid **+4.4%**. Reach for it when clusters are few, not by habit. That asymmetry is why ML is the default.

:::

Crossed intercepts, correlated slopes `(1 + x | g)`, coordinate-spatial with estimated range `ρ`, fixed-effects-only, `zi`/`hu`, `marginal = :VA`, and `marginal = :AGHQ` still error on `method = :REML` rather than silently returning an ML fit. REML log-likelihoods are not comparable across different fixed-effect structures, so do not use them for model selection over `μ`. This slice does not flip a capability chip.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/poisson.jl#L7-L75" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.NegBinomial2' href='#DRM.NegBinomial2'><span class="jlbinding">DRM.NegBinomial2</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
NegBinomial2()
```


Negative-binomial (NB2) family for overdispersed counts: log link on the mean `μ`, and log link on the scale `σ` (the `sigma` formula slot, so `coef(fit, :sigma)` is `log σ`). The NB2 size is `θ = 1/σ² = exp(-2·coef(:sigma))`, matching the Gamma/Beta convention and `drmTMB` (`size = 1/σ²`). Var = `μ + μ²/θ`; as `θ → ∞` it tends to [`Poisson`](/reference/model-specification#DRM.Poisson). Mirrors `drmTMB`'s `nbinom2` family. Crossed random intercepts on the mean, such as `(1 | g) + (1 | h)`, use the sparse-Laplace engine when `sigma ~ 1`. A phylogenetic random intercept on the mean, `phylo(1 | species)`, also uses the sparse-Laplace engine; here a covariate dispersion formula `sigma ~ x` is supported (a per-observation log σ, so a per-observation size θ = 1/σ²; #164), while the crossed-intercept route still requires `sigma ~ 1`.

```julia
fit = drm(bf(y ~ x, sigma ~ 1), NegBinomial2(); data = dat)
fit = drm(bf(y ~ x + (1 | g) + (1 | h), sigma ~ 1), NegBinomial2(); data = dat)
fit_phy = drm(bf(@formula(y ~ x + phylo(1 | species)), @formula(sigma ~ 1)),
              NegBinomial2(); data = dat, tree = tr, se = false)
fit_disp = drm(bf(@formula(y ~ x + phylo(1 | species)), @formula(sigma ~ x)),
               NegBinomial2(); data = dat, tree = tr, se = false)  # log σ ~ x
# Coupled phylogenetic location–scale (#202): shared tag + phylo group on both axes.
fit_ls = drm(bf(@formula(y ~ x + (1 | p | phylo(species))),
                @formula(sigma ~ 1 + (1 | p | phylo(species)))),
             NegBinomial2(); data = dat, tree = tr, se = false)
exp(-2 * coef(fit, :sigma)[1])  # estimated size θ = 1/σ²

# Experimental (#136 Rung 1): NB2 random-intercept variational (ELBO) marginal.
# Requires `sigma ~ 1`. Default remains Laplace (`marginal = :LA`).
fit_va = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1)), NegBinomial2();
             data = dat, marginal = :VA)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/negbinomial.jl#L38-L71" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.TruncatedNegBinomial2' href='#DRM.TruncatedNegBinomial2'><span class="jlbinding">DRM.TruncatedNegBinomial2</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
TruncatedNegBinomial2()
```


Zero-truncated negative-binomial (NB2) family for strictly-positive counts (≥ 1) — litter sizes, group sizes given presence. Same parameterisation as [`NegBinomial2`](/reference/model-specification#DRM.NegBinomial2) (log-link mean `μ`, `log σ` in the `sigma` slot, size `θ = 1/σ²`) but conditioned on `y ≥ 1`: `P(k) = NB(k) / (1 − NB(0))`. Mirrors `drmTMB`'s `truncated_nbinom2`.

```julia
fit = drm(bf(y ~ x, sigma ~ 1), TruncatedNegBinomial2(); data = dat)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/negbinomial.jl#L396-L409" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Beta' href='#DRM.Beta'><span class="jlbinding">DRM.Beta</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Beta()
```


Beta response family for proportions in `(0,1)`: logit link on the mean `μ`, and the `sigma` slot carries `σ` with the precision mapping `φ = 1/σ²` (so `coef(fit, :sigma)` is `log σ`; recover precision as `exp(-2·log σ)`). Likelihood `Beta(μφ, (1-μ)φ)`. Mirrors `drmTMB`'s `beta_family`. Crossed random intercepts on the mean, such as `(1 | g) + (1 | h)`, use the sparse-Laplace engine when `sigma ~ 1`. A phylogenetic random intercept on the mean, `phylo(1 | species)`, also uses the sparse-Laplace engine, as do general user-supplied PD-covariance intercepts — `relmat(1 | id)` with `K = C`, the `animal(1 | id)` (`A = C`) and `spatial(1 | id)` (`K = C`) aliases.

::: tip Note

`DRM.Beta` shadows `Distributions.Beta`; qualify the latter if you need it.

:::

```julia
fit = drm(bf(y ~ x, sigma ~ 1), Beta(); data = dat)
fit = drm(bf(y ~ x + (1 | g) + (1 | h), sigma ~ 1), Beta(); data = dat)
fit_phy = drm(bf(@formula(y ~ x + phylo(1 | species)), @formula(sigma ~ 1)),
              Beta(); data = dat, tree = tr, se = false)
exp(-2 * coef(fit, :sigma)[1])     # estimated precision φ

# Experimental (#136 Rung 1): Beta random-intercept variational (ELBO) marginal.
# Requires `sigma ~ 1`. Default remains Laplace (`marginal = :LA`).
fit_va = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1)), Beta();
             data = dat, marginal = :VA)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/beta.jl#L9-L37" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.BetaBinomial' href='#DRM.BetaBinomial'><span class="jlbinding">DRM.BetaBinomial</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
BetaBinomial()
```


Beta-binomial response family — successes out of known trials with extra-binomial overdispersion. Logit link on the mean success probability `μ`; the `sigma` slot carries `σ` with precision `φ = 1/σ²` (so `coef(fit, :sigma)` is `log σ`). Likelihood `BetaBinomial(n, μφ, (1-μ)φ)`. Requires a two-column response via [`cbind`](/reference/model-specification#DRM.cbind). Mirrors `drmTMB`'s `beta_binomial`. Crossed random intercepts on the mean, such as `(1 | g) + (1 | h)`, use the sparse-Laplace engine when `sigma ~ 1`. A phylogenetic random intercept on the mean, `phylo(1 | species)`, also uses the sparse-Laplace engine (#166); both routes are constant-σ (overdispersion) only for now.

```julia
fit = drm(bf(cbind(successes, failures) ~ x, sigma ~ 1), BetaBinomial(); data = dat)
fit = drm(bf(cbind(successes, failures) ~ x + (1 | g) + (1 | h), sigma ~ 1), BetaBinomial(); data = dat)
fit_phy = drm(bf(@formula(cbind(successes, failures) ~ x + phylo(1 | species)), @formula(sigma ~ 1)),
              BetaBinomial(); data = dat, tree = tr, se = false)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/betabinomial.jl#L20-L39" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Binomial' href='#DRM.Binomial'><span class="jlbinding">DRM.Binomial</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Binomial()
```


Binomial response family — successes out of known trials (logistic regression). Logit link on the mean success probability `μ`; no scale/dispersion parameter (mean-only, like [`Poisson`](/reference/model-specification#DRM.Poisson)). Accepts either a two-column response via [`cbind`](/reference/model-specification#DRM.cbind) (`trials = successes + failures`) or a plain `0/1` Bernoulli vector. Likelihood `Binomial(n, μ)` with `μ = logistic(η)`. Mirrors `drmTMB`'s `binomial` family. A random intercept `(1 | g)` on the mean fits a logistic GLMM; crossed intercepts such as `(1 | g) + (1 | h)` use the sparse-Laplace engine. A phylogenetic random intercept on the mean, `phylo(1 | species)`, also uses the sparse-Laplace engine.

::: tip Note

`DRM.Binomial` shadows `Distributions.Binomial`; if you need the distribution too (e.g. to simulate), qualify it as `Distributions.Binomial`.

:::

```julia
fit = drm(bf(cbind(successes, failures) ~ x), Binomial(); data = dat)   # logistic regression
fit = drm(bf(y ~ x + (1 | g)), Binomial(); data = dat)                  # 0/1 logistic GLMM
fit = drm(bf(cbind(successes, failures) ~ x + (1 | g) + (1 | h)), Binomial(); data = dat)
fit_phy = drm(bf(@formula(cbind(successes, failures) ~ x + phylo(1 | species))),
              Binomial(); data = dat, tree = tr, se = false)
fitted(fit)        # fitted success probabilities μ̂ = logistic(Xβ̂)

# Experimental (#136 Rung 1): Binomial random-intercept variational (ELBO) marginal.
fit_va = drm(bf(@formula(y ~ x + (1 | g))), Binomial(); data = dat, marginal = :VA)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/binomial.jl#L12-L40" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Gamma' href='#DRM.Gamma'><span class="jlbinding">DRM.Gamma</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Gamma()
```


Gamma response family for positive continuous data: log link on the mean `μ`, and the `sigma` slot carries `σ` = the coefficient of variation, mapped to the shape `α = 1/σ²` (`coef(fit, :sigma)` is `log σ`; recover the shape as `exp(-2·log σ)`). Likelihood `Gamma(α, μ/α)`; variance `μ²σ²`. Mirrors `drmTMB`'s `Gamma` family. Crossed random intercepts on the mean, such as `(1 | g) + (1 | h)`, use the sparse-Laplace engine when `sigma ~ 1`. A phylogenetic random intercept on the mean, `phylo(1 | species)`, also uses the sparse-Laplace engine.

::: tip Note

`DRM.Gamma` shadows `Distributions.Gamma`; qualify the latter if you need it.

:::

```julia
fit = drm(bf(y ~ x, sigma ~ 1), Gamma(); data = dat)
fit = drm(bf(y ~ x + (1 | g) + (1 | h), sigma ~ 1), Gamma(); data = dat)
fit_phy = drm(bf(@formula(y ~ x + phylo(1 | species)), @formula(sigma ~ 1)),
              Gamma(); data = dat, tree = tr, se = false)
exp(-2 * coef(fit, :sigma)[1])     # estimated shape α

# Experimental (#136 Rung 1): Gamma random-intercept variational (ELBO) marginal.
# Requires `sigma ~ 1`. Default remains Laplace (`marginal = :LA`).
fit_va = drm(bf(@formula(y ~ x + (1 | g)), @formula(sigma ~ 1)), Gamma();
             data = dat, marginal = :VA)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/gamma.jl#L10-L36" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.LogNormal' href='#DRM.LogNormal'><span class="jlbinding">DRM.LogNormal</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
LogNormal()
```


LogNormal response family for positive continuous data: the mean formula `μ` is the **mean of `log y`** (identity link on the log scale), and `σ` (log link) is the **SD of `log y`**. The response-scale median is `exp(μ)`. Mirrors `drmTMB`'s `lognormal` family.

::: tip Note

`DRM.LogNormal` shadows `Distributions.LogNormal`; qualify the latter if needed.

:::

A random intercept `(1 | g)` or a correlated random intercept+slope `(1 + x | g)` may be placed on the log-mean `μ`; the group effect is integrated out by Gauss–Hermite quadrature (`re_sd(fit)[:g]` / `vc(fit)[:g]`).

```julia
fit = drm(bf(y ~ x, sigma ~ 1), LogNormal(); data = dat)
coef(fit, :mu)                 # on the log scale
exp(coef(fit, :sigma)[1])      # SD of log y
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/lognormal.jl#L11-L31" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.ZeroOneBeta' href='#DRM.ZeroOneBeta'><span class="jlbinding">DRM.ZeroOneBeta</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
ZeroOneBeta()
```


Zero-one-inflated beta family for proportions on the closed interval `[0,1]` (values may be exactly 0 or 1). Parameters: `mu` (logit; beta mean on the interior), `sigma` (log; precision `φ = 1/σ²`), `zoi` (logit; probability the value is a boundary 0/1), `coi` (logit; probability of 1 given a boundary). Mirrors `drmTMB`'s `zero_one_beta`. `fitted` returns the unconditional mean `(1-zoi)·μ + zoi·coi`.

```julia
fit = drm(bf(y ~ x, sigma ~ 1, zoi ~ 1, coi ~ 1), ZeroOneBeta(); data = dat)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/zeroonebeta.jl#L15-L28" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.Tweedie' href='#DRM.Tweedie'><span class="jlbinding">DRM.Tweedie</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
Tweedie()
```


Tweedie response family (compound Poisson–Gamma, power `1 < p < 2`) for semicontinuous data — an exact-zero mass plus a positive continuous part. Log link on the mean `μ`; `sigma` is the √dispersion (so `φ = σ²`, `coef(fit, :sigma)` is `log σ`); `nu` is the power `p` on a logit-`(1,2)` link (`p = 1 + logistic(coef(fit, :nu))`). `Var(y) = φ·μ^p`. Density via the Dunn–Smyth series. Mirrors `drmTMB`'s `tweedie`.

```julia
fit = drm(bf(y ~ x, sigma ~ 1, nu ~ 1), Tweedie(); data = dat)
exp(2 * coef(fit, :sigma)[1])               # dispersion φ
1 + 1 / (1 + exp(-coef(fit, :nu)[1]))       # power p ∈ (1,2)
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/tweedie.jl#L40-L55" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.CumulativeLogit' href='#DRM.CumulativeLogit'><span class="jlbinding">DRM.CumulativeLogit</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
CumulativeLogit()
```


Cumulative-logit (proportional-odds) ordinal family. The response is an ordered category coded `1, 2, …, K`. `Pr(y ≤ k) = logistic(θ_k − η)` with ordered cutpoints `θ_1 < … < θ_{K-1}`; the single linear predictor `η` comes from the `mu` formula **with its intercept dropped** (cutpoints absorb it). No scale parameter. `coef(fit, :mu)` are the slopes; `coef(fit, :cutpoints)` are the raw increment parameters (`θ_1 = δ_1`, `θ_k = θ_{k-1} + exp(δ_k)`). `fitted` returns the expected ordered-category score `Σ_k k·Pr(y=k)`. Mirrors `drmTMB`'s `cumulative_logit`.

```julia
fit = drm(bf(y ~ x), CumulativeLogit(); data = dat)   # y coded 1..K
```



<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/cumulative.jl#L9-L24" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Advanced family type {#Advanced-family-type}

`SkewNormal` is a Julia family type with its own docstring. Its presence here does not widen the supported-model matrix; consult the capability matrix before selecting a family and structure.

The source docstring below uses a shorthand formula sketch. For a call with prepared data `dat`, use explicit Julia formula objects:

```julia
fit = drm(bf(@formula(y ~ x), @formula(sigma ~ 1), @formula(nu ~ 1)),
          SkewNormal(); data = dat)
```

<details class='jldocstring custom-block' open>
<summary><a id='DRM.SkewNormal' href='#DRM.SkewNormal'><span class="jlbinding">DRM.SkewNormal</span></a> <Badge type="info" class="jlObjectType jlType" text="Type" /></summary>



```julia
SkewNormal()
```


Skew-normal response family for continuous, asymmetric data: identity link on the location `μ`, log link on the scale `σ` (the `sigma` slot), and identity link on the slant `ν` (the `nu` slot). The public parameterisation is the **moment** form mirroring `drmTMB`'s `skew_normal`: `μ` is the **mean** of `y`, `σ` is the **SD** of `y`, and `ν` is Azzalini's slant `α`. These are mapped internally to the location–scale–slant `(ξ, ω, α)` of the density `f(y) = 2·φ((y−ξ)/ω)·Φ(α(y−ξ)/ω)/ω`.

`ν = 0` recovers the symmetric [`Gaussian`](/reference/model-specification#DRM.Gaussian); `ν > 0` skews right, `ν < 0` skews left.

```julia
fit = drm(bf(y ~ x, sigma ~ 1, nu ~ 1), SkewNormal(); data = dat)
coef(fit, :mu)[1]           # mean of y (identity)
exp(coef(fit, :sigma)[1])   # SD of y
coef(fit, :nu)[1]           # estimated slant α (identity)
```


::: tip Note

Near `ν = 0` the model is (locally) symmetric Gaussian and the slant is only weakly identified — its standard error inflates and recovery is loose. The fitter starts `ν` at a small nonzero value seeded by the sample-skewness sign to break this symmetry.

:::


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/skewnormal.jl#L16-L42" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Two-column response {#Two-column-response}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.cbind' href='#DRM.cbind'><span class="jlbinding">DRM.cbind</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
cbind(successes, failures)
```


Formula marker for a two-column count response, e.g. `bf(cbind(successes, failures) ~ x, sigma ~ z)` with [`BetaBinomial`](/reference/model-specification#DRM.BetaBinomial). Trials are `successes + failures`. Mirrors drmTMB's `cbind(...)` response. Only inspected structurally on a formula left-hand side.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/betabinomial.jl#L10-L17" target="_blank" rel="noreferrer">source</a></Badge>

</details>

