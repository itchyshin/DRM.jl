
# Package {#Package}

::: tip Status — Reference

Mirrors drmTMB's [Package](https://itchyshin.github.io/drmTMB/reference/index.html) (1 item in drmTMB). The `DRM` module overview.

:::
<details class='jldocstring custom-block' open>
<summary><a id='DRM' href='#DRM'><span class="jlbinding">DRM</span></a> <Badge type="info" class="jlObjectType jlModule" text="Module" /></summary>



```julia
DRM
```


`DRM.jl` — a Julia engine for distributional regression models, the Julia twin of the R package **drmTMB**. Mirrors the gllvmTMB → GLLVM.jl move.

This v0.1.0 release migrates the verified `drm-julia-poc` engine for the **q=4 phylogenetic bivariate location–scale model (PLSM)** — the selling-point model of drmTMB (Nakagawa et al. 2025 MEE, Model 5). The marginal is a sparse **augmented-state Laplace approximation** with an **exact O(p) gradient** (implicit-function / TMB-style, via Takahashi selected inverse — never forms a dense p×p Σ_phy), optimised by LBFGS with a fast-path-then-robust mode-finder.

Verified results (see report/comparison-grid.md):
- Single fit (real q4_p100, same model as drmTMB): **1.14 s vs drmTMB 2.48 s (2.18×)**, logLik matches, converged.
  
- O(p) scaling (per-dimension-variance model, nrep=4 replicates): **p=10000 in ~113 s, k≈1.08** (near-perfect O(p)).
  
- Inference: Wald SEs valid for 16/17 params where drmTMB's Hessian is all-NaN; parametric bootstrap 60/60.
  

NOTE (see HANDOVER.md): the engine files were migrated as the poc's script-style includes (chain: fit_q4_sparse_tmb → fit_ml_q4 → sparse_em_fit → sparse_aug_plsm → sparse_phy / takahashi_selinv). Inference (Wald + profile + parametric bootstrap) is wired in `src/inference.jl`. **Public / included on tip:** opt-in REML (`src/reml_q4.jl`,`drm(method = :REML)`; restricted correction covers all four among-axis axes — see #11) and the conjugate-EM Gaussian phylo-mean solver (`src/location_only.jl`,`algorithm = :em` — see #12). **#13 decision gate FAIL (2026-08-01):** natural-gradient EM stalls vs sparse TMB on q4_p100 — do **not** expose `algorithm = :natgrad`; the reusable Fisher metric lives in `src/lc_metric.jl`. **Still experimental (not wired):** SQUAREM EM, trust-region & line-search E-steps, dense q=4 EM, warm-start fit variants, and the leftover `src/experimental/location_only.jl` / `fit_em_natgrad.jl` prototypes — do not treat that directory as the public REML / `:em` surface.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/DRM.jl#L1-L35" target="_blank" rel="noreferrer">source</a></Badge>

</details>

