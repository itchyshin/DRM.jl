
# Visualization {#Visualization}

::: tip Status — Reference

Mirrors drmTMB's [Visualization](https://itchyshin.github.io/drmTMB/reference/index.html) (3 in drmTMB). DRM.jl keeps the base package plotting-dependency-free: these return the _data_ a plot needs — a profile-deviance grid, a correlation summary — so any backend can render them. Drawing is optional via the **`DRMMakieExt`** package extension (Makie + AlgebraOfGraphics weakdeps); load a Makie backend and AlgebraOfGraphics to activate [`drm_figure`](/reference/visualization#DRM.drm_figure). Default CI does **not** draw figures — it only gates the method-less stub.

:::

## Plotting data providers {#Plotting-data-providers}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.profile_curve' href='#DRM.profile_curve'><span class="jlbinding">DRM.profile_curve</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
profile_curve(fit, k; npoints = 41, span = 3.0, level = 0.95) -> NamedTuple
```


1-D profile-likelihood curve for coefficient index `k`, the data needed for a profile diagnostic plot. At each grid value of `θ[k]`, all nuisance parameters are re-optimised, so the returned curve is a likelihood-ratio profile rather than a Wald/quadratic approximation.

Returns `(x, deviance, estimate, cutoff, k, param, coef, level)`:
- `x` — grid values for `θ[k]`, spanning `θ̂[k] ± span·se[k]` and including the MLE exactly;
  
- `deviance` — `2(ℓ̂ - ℓ_profile)` at each `x` value;
  
- `cutoff` — the `χ²₁(level)` reference line used by profile intervals.
  

Requires the fitted objective (`fit.nll`); the model must be fit through `drm`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/visualization.jl#L7-L22" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.parameter_surface' href='#DRM.parameter_surface'><span class="jlbinding">DRM.parameter_surface</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
parameter_surface(fit, k1, k2; npoints = 25, span = 3.0) -> NamedTuple
```


2-D profile-likelihood surface over two coefficients (global indices `k1`, `k2` into `coef(fit)`), the data behind drmTMB's `plot_parameter_surface`. At each grid node the remaining parameters are profiled out (re-optimised), so the surface is the genuine profile deviance `2(ℓ̂ − ℓ_profile(θ_{k1}, θ_{k2}))`, not a quadratic approximation.

Returns `(x, y, z, k1, k2)`:
- `x`, `y` — the grid coordinate vectors for `θ[k1]`, `θ[k2]` (length `npoints`), spanning `θ̂[k] ± span·se[k]`.
  
- `z` — `npoints × npoints` matrix of profile deviance (`z[i,j]` at `x[i], y[j]`); `0` at the MLE, rising away from it. `χ²₂` contours give joint confidence regions.
  

Requires the fitted objective (`fit.nll`); the model must be fit through `drm`.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/visualization.jl#L72-L88" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.corpairs_data' href='#DRM.corpairs_data'><span class="jlbinding">DRM.corpairs_data</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
corpairs_data(fit) -> NamedTuple
```


Summary of the fitted between-response residual correlation for plotting — the data behind drmTMB's `plot_corpairs`. Returns `(rho = …, constant = …)`:
- `rho` — the per-observation `ρ12 = tanh(Xρ·β̂_ρ)` vector for bivariate models; empty for univariate models (no between-response correlation).
  
- `constant` — `true` when `ρ12` does not vary across observations (`rho12 ~ 1`), in which case a single number `rho[1]` summarises it; `false` when it varies (`rho12 ~ x`) and the full vector / a covariate scatter is the right plot.
  


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/visualization.jl#L166-L176" target="_blank" rel="noreferrer">source</a></Badge>

</details>


## Drawing layer (optional Makie extension) {#Drawing-layer-optional-Makie-extension}
<details class='jldocstring custom-block' open>
<summary><a id='DRM.drm_figure' href='#DRM.drm_figure'><span class="jlbinding">DRM.drm_figure</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
drm_figure(data; kind = <inferred>, kwargs...)
```


Draw a DRM plotting-layer figure from a preparer `NamedTuple` ([`profile_curve`](/reference/visualization#DRM.profile_curve) / [`parameter_surface`](/reference/visualization#DRM.parameter_surface) / [`corpairs_data`](/reference/visualization#DRM.corpairs_data)). **STUB:** the drawing method is provided by the `DRMMakieExt` package extension, which activates only when a Makie backend and AlgebraOfGraphics are loaded (`using CairoMakie, AlgebraOfGraphics` / `using GLMakie, AlgebraOfGraphics`). Without them, calling this throws a `MethodError` asking you to load the plotting weak dependencies.

Supported `kind`s:
- `:profile` ← [`profile_curve`](/reference/visualization#DRM.profile_curve) — profile deviance with Florence's **Confidence Eye** (pale compatibility region where deviance ≤ cutoff, darker outline, hollow point estimate)
  
- `:parameter_surface` ← [`parameter_surface`](/reference/visualization#DRM.parameter_surface) — 2-D profile-deviance heatmap / surface
  
- `:corpairs` ← [`corpairs_data`](/reference/visualization#DRM.corpairs_data) — residual `ρ12` summary (constant point or per-observation scatter)
  

Drawing only — no estimation, no engine computation. Default CI does **not** load Makie; stub tests assert `isempty(methods(drm_figure))` without the weakdeps.


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/plotting_ext.jl#L7-L30" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.plot_profile' href='#DRM.plot_profile'><span class="jlbinding">DRM.plot_profile</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
plot_profile(fit, k; npoints = 41, span = 3.0, level = 0.95, kwargs...)
```


Thin drmTMB-named alias: [`profile_curve`](/reference/visualization#DRM.profile_curve) then [`drm_figure`](/reference/visualization#DRM.drm_figure) (`kind = :profile`). Requires Makie + AlgebraOfGraphics (via `DRMMakieExt`).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/plotting_ext.jl#L33-L38" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.plot_parameter_surface' href='#DRM.plot_parameter_surface'><span class="jlbinding">DRM.plot_parameter_surface</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
plot_parameter_surface(fit, k1, k2; npoints = 25, span = 3.0, kwargs...)
```


Thin drmTMB-named alias: [`parameter_surface`](/reference/visualization#DRM.parameter_surface) then [`drm_figure`](/reference/visualization#DRM.drm_figure) (`kind = :parameter_surface`). Requires Makie + AlgebraOfGraphics (via `DRMMakieExt`).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/plotting_ext.jl#L43-L48" target="_blank" rel="noreferrer">source</a></Badge>

</details>

<details class='jldocstring custom-block' open>
<summary><a id='DRM.plot_corpairs' href='#DRM.plot_corpairs'><span class="jlbinding">DRM.plot_corpairs</span></a> <Badge type="info" class="jlObjectType jlFunction" text="Function" /></summary>



```julia
plot_corpairs(fit; kwargs...)
```


Thin drmTMB-named alias: [`corpairs_data`](/reference/visualization#DRM.corpairs_data) then [`drm_figure`](/reference/visualization#DRM.drm_figure) (`kind = :corpairs`). Requires Makie + AlgebraOfGraphics (via `DRMMakieExt`).


<Badge type="info" class="source-link" text="source"><a href="https://github.com/itchyshin/DRM.jl/blob/c6ff8bd550488df68822c4c15a35ab4ddd291234/src/plotting_ext.jl#L53-L58" target="_blank" rel="noreferrer">source</a></Badge>

</details>


To draw locally (not in default CI):

```julia
using CairoMakie, AlgebraOfGraphics   # activates DRMMakieExt
pc = profile_curve(fit, 2)
fig = drm_figure(pc; kind = :profile)   # Confidence Eye on the profile interval
# or: plot_profile(fit, 2)
```

